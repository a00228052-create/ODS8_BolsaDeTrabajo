"""Flujos de cuentas locales con bases temporales; sin proveedores externos."""
import secrets
import tempfile
import time
import tkinter as tk
import unittest
from pathlib import Path
from tkinter import ttk
from unittest.mock import patch

from src.app.main import main, _construir_aplicacion
from src.app.win_form import open_win_form
from src.core import cuentas, datos


def descendientes(widget, clase):
    for hijo in widget.winfo_children():
        if isinstance(hijo, clase):
            yield hijo
        yield from descendientes(hijo, clase)


def boton(widget, texto):
    return next(w for w in descendientes(widget, ttk.Button) if w.cget("text") == texto)


class AccesoPerfilTests(unittest.TestCase):
    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory()
        self.invitado = Path(self.temporal.name)/"invitado.sqlite3"
        self.base_cuentas = Path(self.temporal.name)/"cuentas.sqlite3"
        self.parches = [patch.object(datos, "DB_path", self.invitado),
                        patch.object(cuentas, "DB_CUENTAS", self.base_cuentas)]
        for parche in self.parches:
            parche.start()
        self.clave = secrets.token_urlsafe(24)
        self.root = tk.Tk()
        self.root.withdraw()
        self.errores = []
        self.root.report_callback_exception = lambda tipo, error, traza: self.errores.append(str(error))
        with patch("src.app.main.tk.Tk", return_value=self.root), patch.object(self.root, "mainloop"):
            main()

    def tearDown(self):
        self.root.update()
        self.root.destroy()
        for parche in reversed(self.parches):
            parche.stop()
        self.temporal.cleanup()
        self.assertEqual(self.errores, [])

    def entrar(self, correo="persona@example.test"):
        usuario = cuentas.crear_cuenta("Persona de ejemplo", correo, self.clave, acepta=True)
        _construir_aplicacion(self.root, usuario)
        self.root.update()
        return usuario

    def solicitud(self):
        return datos.guardar_solicitud("Cliente de ejemplo", "demo@example.test", "Lugar ficticio",
            "Revisión de una fuga", "serv-plomeria", "1", acepta_politicas=True)

    def formulario(self):
        servicio = next(s for s in datos.obtener_servicios() if s["id"] == "serv-plomeria")
        trabajador = next(t for t in datos.obtener_trabajadores() if t["id"] == "1")
        return open_win_form(self.root, servicio, trabajador)

    def test_al_iniciar_muestra_acceso_sin_abrir_datos_del_invitado(self):
        self.assertTrue(hasattr(self.root, "acceso"))
        self.assertFalse(hasattr(self.root, "navegador"))
        self.assertIsNone(self.root.usuario)
        self.assertEqual(datos.DB_path, self.invitado)
        self.assertFalse(self.invitado.exists())
        self.assertFalse(self.base_cuentas.exists())

    def test_google_y_apple_no_fingen_una_sesion(self):
        for proveedor in ("Google", "Apple"):
            with patch("src.app.sesion.messagebox.showinfo") as aviso:
                boton(self.root.acceso, proveedor).invoke()
            aviso.assert_called_once()
            self.assertIsNone(self.root.usuario)
            self.assertFalse(hasattr(self.root, "navegador"))

    def test_crear_cuenta_desde_la_pantalla_abre_su_propia_base(self):
        acceso = self.root.acceso
        acceso.cambiar_modo()
        acceso.nombre.set("Persona de ejemplo")
        acceso.correo.set("persona@example.test")
        acceso.clave.set(self.clave)
        acceso.confirmacion.set(self.clave)
        acceso.acepta.set(True)
        acceso.enviar()
        limite = time.monotonic()+8
        while not hasattr(self.root, "navegador") and time.monotonic() < limite:
            self.root.update()
            time.sleep(.02)
        self.assertTrue(hasattr(self.root, "navegador"))
        self.assertEqual(self.root.usuario["correo"], "persona@example.test")
        self.assertEqual(datos.DB_path, cuentas.ruta_servicios(self.root.usuario["id"]))
        self.assertNotEqual(datos.DB_path, self.invitado)
        self.assertEqual(acceso.clave.get(), "")
        self.assertEqual(acceso.confirmacion.get(), "")

    def test_perfil_guarda_nombre_telefono_y_direccion(self):
        self.entrar()
        self.root.botones_menu["Mi perfil"].invoke()
        vista = self.root.navegador.actual
        vista.campos["nombre"].set("Nombre actualizado")
        vista.campos["telefono"].set("4771234567")
        vista.campos["domicilio"].set("Dirección ficticia para pruebas")
        boton(vista, "Guardar cambios").invoke()
        self.root.update()
        guardado = cuentas.iniciar_sesion("persona@example.test", self.clave)
        self.assertEqual(guardado["nombre"], "Nombre actualizado")
        self.assertEqual(guardado["telefono"], "4771234567")
        self.assertEqual(guardado["domicilio"], "Dirección ficticia para pruebas")
        self.assertEqual(self.root.usuario["nombre"], "Nombre actualizado")
        self.assertEqual(self.root.inicio.cliente.direccion.get(), "Dirección ficticia para pruebas")
        self.assertIs(self.root.navegador.actual, vista)
        self.root.inicio.cliente.direccion.set("Otra dirección elegida para esta solicitud")
        vista.campos["domicilio"].set("Nueva dirección de casa ficticia")
        boton(vista, "Guardar cambios").invoke()
        self.root.update()
        self.assertEqual(self.root.usuario["domicilio"], "Nueva dirección de casa ficticia")
        self.assertEqual(self.root.inicio.cliente.direccion.get(), "Otra dirección elegida para esta solicitud")

    def test_tema_guarda_preferencia_sin_perder_el_borrador(self):
        self.entrar()
        formulario = self.formulario()
        formulario.nombre.set("Mi borrador")
        formulario.descripcion.insert("1.0", "Descripción sin enviar")
        self.root.establecer_tema(True)
        self.root.update()
        self.assertEqual(formulario.nombre.get(), "Mi borrador")
        self.assertEqual(formulario.descripcion.get("1.0", "end").strip(), "Descripción sin enviar")
        self.assertFalse(formulario.acepta_politicas.get())
        self.assertEqual(self.root.navegador.actual.titulo, "Solicitar servicio")
        self.assertTrue(cuentas.iniciar_sesion("persona@example.test", self.clave)["ajustes"]["oscuro"])
        self.root.establecer_tema(False)
        self.assertEqual(formulario.nombre.get(), "Mi borrador")

    def test_ajustes_aplican_movimiento_y_avisos_y_se_guardan(self):
        self.entrar()
        self.root.botones_menu["Ajustes"].invoke()
        vista = self.root.navegador.actual
        casillas = {w.cget("text"):w for w in descendientes(vista, ttk.Checkbutton)}
        casillas["Reducir animaciones"].invoke()
        casillas["Mostrar avisos dentro de la app"].invoke()
        self.root.update()
        self.assertTrue(self.root._reducir_movimiento)
        self.assertFalse(self.root._avisos)
        guardado = cuentas.iniciar_sesion("persona@example.test", self.clave)["ajustes"]
        self.assertTrue(guardado["reducir_movimiento"])
        self.assertFalse(guardado["avisos"])

    def test_cerrar_sesion_revoca_gps_restaura_invitado_y_separa_cuentas(self):
        primera = self.entrar()
        sid = self.solicitud()
        base_primera = datos.DB_path
        self.root.botones_menu["Seguimiento"].invoke()
        gps = self.root.navegador.actual.mapa.servidor()
        self.assertIsNone(gps.server)  # No se abre listener ni se pide permiso al navegador.
        with patch.object(gps, "cerrar", wraps=gps.cerrar) as cerrar_gps:
            self.root.cerrar_sesion()
            cerrar_gps.assert_called_once()
        self.root.update()
        self.assertFalse(hasattr(self.root, "_ubicaciones"))
        self.assertFalse(hasattr(self.root, "navegador"))
        self.assertTrue(hasattr(self.root, "acceso"))
        self.assertIsNone(self.root.usuario)
        self.assertEqual(datos.DB_path, self.invitado)
        self.assertFalse(self.invitado.exists())
        self.entrar("otra@example.test")
        self.assertEqual(datos.obtener_solicitudes(), [])
        self.assertNotEqual(datos.DB_path, base_primera)
        self.root.cerrar_sesion()
        _construir_aplicacion(self.root, cuentas.iniciar_sesion(primera["correo"], self.clave))
        self.assertEqual([s["id"] for s in datos.obtener_solicitudes()], [sid])

    def test_cancelar_cierre_conserva_el_borrador_y_la_sesion(self):
        usuario = self.entrar()
        formulario = self.formulario()
        formulario.nombre.set("Solicitud sin enviar")
        with patch("src.app.main.messagebox.askyesno", return_value=False):
            self.root.cerrar_sesion()
        self.assertEqual(self.root.usuario["id"], usuario["id"])
        self.assertEqual(formulario.nombre.get(), "Solicitud sin enviar")
        self.assertIs(self.root.navegador.actual, formulario.ventana)


if __name__ == "__main__":
    unittest.main()
