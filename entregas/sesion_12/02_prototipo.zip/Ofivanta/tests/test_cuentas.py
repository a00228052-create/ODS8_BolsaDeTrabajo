import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from src.core import cuentas, datos, perfiles, politicas


class CuentasTests(unittest.TestCase):
    CLAVE = "Una frase larga solo para pruebas"

    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory()
        self.ruta = Path(self.temporal.name) / "cuentas.sqlite3"

    def tearDown(self):
        self.temporal.cleanup()

    def crear(self, correo="persona@example.test", acepta=True):
        return cuentas.crear_cuenta("Persona de ejemplo", correo, self.CLAVE, acepta, self.ruta)

    def entrar(self, correo="persona@example.test", clave=None):
        return cuentas.iniciar_sesion(correo, self.CLAVE if clave is None else clave, self.ruta)

    def test_crear_y_entrar_normaliza_el_correo_sin_exponer_la_clave(self):
        creada = self.crear("  Persona@Example.Test  ")
        acceso = self.entrar(" PERSONA@EXAMPLE.TEST ")
        self.assertEqual(creada["id"], acceso["id"])
        self.assertEqual(acceso["correo"], "persona@example.test")
        self.assertEqual(set(acceso), {"id", "correo", "nombre", "telefono", "domicilio", "ajustes"})

    def test_no_guarda_la_contrasena_y_usa_sal_distinta_por_cuenta(self):
        self.crear()
        self.crear("otra@example.test")
        with cuentas.conexion(self.ruta) as con:
            filas = con.execute("SELECT sal,clave,iteraciones FROM cuentas ORDER BY correo").fetchall()
        self.assertEqual(len(filas), 2)
        self.assertEqual(len(filas[0]["sal"]), 16)
        self.assertEqual(len(filas[0]["clave"]), 32)
        self.assertEqual(filas[0]["iteraciones"], 600_000)
        self.assertNotEqual(filas[0]["sal"], filas[1]["sal"])
        self.assertNotEqual(filas[0]["clave"], filas[1]["clave"])
        self.assertNotIn(self.CLAVE.encode(), self.ruta.read_bytes())

    def test_consentimiento_es_explicito_y_conserva_el_texto_aceptado(self):
        for acepta in (False, None, "sí", 1):
            with self.subTest(acepta=acepta), self.assertRaises(ValueError):
                self.crear(acepta=acepta)
        usuario = self.crear()
        with cuentas.conexion(self.ruta) as con:
            fila = con.execute("SELECT * FROM aceptaciones_cuenta WHERE usuario_id=?", (usuario["id"],)).fetchone()
            cantidad = con.execute("SELECT COUNT(*) FROM cuentas").fetchone()[0]
        self.assertEqual(cantidad, 1)
        self.assertEqual(fila["version"], politicas.VERSION)
        self.assertEqual(fila["huella"], politicas.huella())
        self.assertIn("Privacidad y ubicación", fila["contenido"])
        self.assertGreater(fila["fecha"], 0)

    def test_no_duplica_cuentas_por_mayusculas_o_espacios(self):
        self.crear()
        with self.assertRaises(ValueError):
            self.crear(" PERSONA@EXAMPLE.TEST ")
        self.assertEqual(self.entrar()["correo"], "persona@example.test")

    def test_rechaza_correos_con_controles_y_campos_fuera_de_limites(self):
        for correo in ("sin-correo", "a b@example.test", "a\x00b@example.test", "a\x7fb@example.test", "x"*250+"@example.test", None):
            with self.subTest(correo=repr(correo)[:35]), self.assertRaises(ValueError):
                cuentas.correo_valido(correo)
        for clave in ("corta", " "*16, "x"*129, None):
            with self.subTest(longitud=len(clave) if clave else None), self.assertRaises(ValueError):
                cuentas.validar_clave(clave)
        for nombre in ("A", "x"*71, "Nombre\nCon salto", None):
            with self.subTest(nombre=repr(nombre)[:20]), self.assertRaises(ValueError):
                cuentas.crear_cuenta(nombre, "persona@example.test", self.CLAVE, True, self.ruta)

    def test_acepta_frases_unicode_y_no_recorta_sus_espacios(self):
        clave = "  Una contraseña de demostración  "
        cuentas.crear_cuenta("María de Ejemplo", "unicode@example.test", clave, True, self.ruta)
        usuario = cuentas.iniciar_sesion("unicode@example.test", clave, self.ruta)
        self.assertEqual(usuario["nombre"], "María de Ejemplo")
        with self.assertRaises(ValueError):
            cuentas.iniciar_sesion("unicode@example.test", clave.strip(), self.ruta)

    def test_correo_desconocido_y_clave_incorrecta_no_revelan_la_cuenta(self):
        self.crear()
        errores = []
        for correo in ("persona@example.test", "desconocida@example.test"):
            with self.assertRaises(ValueError) as error:
                self.entrar(correo, "otra frase de contraseña")
            errores.append(str(error.exception))
        self.assertEqual(errores[0], errores[1])

    def test_bloqueo_persiste_y_caduca_despues_de_quince_minutos(self):
        self.crear()
        reloj = 1_900_000_000
        with patch("src.core.cuentas.time.time", return_value=reloj):
            for _ in range(5):
                with self.assertRaisesRegex(ValueError, "no coinciden"):
                    self.entrar(clave="otra frase de contraseña")
            with self.assertRaisesRegex(ValueError, "15 minutos"):
                self.entrar()
            with cuentas.conexion(self.ruta) as con:
                fila = con.execute("SELECT bloqueada_hasta,fallos FROM cuentas").fetchone()
            self.assertEqual(fila["bloqueada_hasta"], reloj+900)
            self.assertEqual(fila["fallos"], 0)
        with patch("src.core.cuentas.time.time", return_value=reloj+901):
            self.assertEqual(self.entrar()["correo"], "persona@example.test")

    def test_acceso_correcto_reinicia_los_intentos_fallidos(self):
        self.crear()
        with self.assertRaises(ValueError):
            self.entrar(clave="otra frase de contraseña")
        self.entrar()
        with cuentas.conexion(self.ruta) as con:
            fila = con.execute("SELECT fallos,bloqueada_hasta FROM cuentas").fetchone()
        self.assertEqual(tuple(fila), (0, 0))

    def test_perfil_persiste_sin_cambiar_la_clave_o_el_correo(self):
        usuario = self.crear()
        perfil = cuentas.guardar_perfil(usuario["id"], "Nombre de ejemplo", "+52 (477) 123-4567", "Casa ficticia 24", self.ruta)
        self.assertEqual(perfil["nombre"], "Nombre de ejemplo")
        self.assertEqual(perfil["domicilio"], "Casa ficticia 24")
        self.assertEqual(self.entrar()["telefono"], "+52 (477) 123-4567")
        self.assertEqual(self.entrar()["correo"], usuario["correo"])
        for telefono in ("123", "teléfono privado", "1"*16):
            with self.subTest(telefono=telefono), self.assertRaises(ValueError):
                cuentas.guardar_perfil(usuario["id"], "Nombre válido", telefono, "", self.ruta)
        with self.assertRaises(ValueError):
            cuentas.guardar_perfil("inexistente", "Nombre válido", "", "", self.ruta)

    def test_ajustes_se_guardan_por_cuenta_y_solo_aceptan_booleanos(self):
        primera = self.crear()
        self.crear("otra@example.test")
        cuentas.guardar_ajustes(primera["id"], {"oscuro": True, "reducir_movimiento": True, "avisos": False}, self.ruta)
        self.assertEqual(self.entrar()["ajustes"], {"oscuro": True, "reducir_movimiento": True, "avisos": False})
        self.assertEqual(self.entrar("otra@example.test")["ajustes"], cuentas.AJUSTES)
        for ajustes in ({"oscuro": "sí"}, {"avisos": 1}, {"ajuste_nuevo": True}, None):
            with self.subTest(ajustes=ajustes), self.assertRaises(ValueError):
                cuentas.guardar_ajustes(primera["id"], ajustes, self.ruta)

    def test_ajustes_danados_recuperan_valores_seguros(self):
        usuario = self.crear()
        for bruto in ("[]", "no es JSON", '{"oscuro":"sí","avisos":null}'):
            with cuentas.conexion(self.ruta) as con:
                con.execute("UPDATE cuentas SET ajustes=? WHERE id=?", (bruto, usuario["id"]))
            self.assertEqual(self.entrar()["ajustes"], cuentas.AJUSTES)

    def test_rutas_de_servicio_no_usan_correo_y_rechazan_recorridos_ajenos(self):
        usuario = self.crear()
        ruta = cuentas.ruta_servicios(usuario["id"], self.ruta)
        self.assertEqual(ruta.parent.name, usuario["id"])
        self.assertEqual(ruta.parents[2], self.ruta.parent)
        self.assertNotIn(usuario["correo"], str(ruta))
        for identificador in ("../../otra-base", "/tmp/otra-base", "inexistente"):
            with self.subTest(identificador=identificador), self.assertRaises(ValueError):
                cuentas.ruta_servicios(identificador, self.ruta)

    def test_servicios_cuenta_e_invitado_no_comparten_solicitudes(self):
        primera = self.crear()
        segunda = self.crear("otra@example.test")
        ruta_a = cuentas.ruta_servicios(primera["id"], self.ruta)
        ruta_b = cuentas.ruta_servicios(segunda["id"], self.ruta)
        invitado = Path(self.temporal.name) / "invitado.sqlite3"
        sid = datos.guardar_solicitud("Cliente ejemplo", "demo@example.test", "Casa ficticia", "Revisar una fuga",
                                      "serv-plomeria", "1", db_path=ruta_a, acepta_politicas=True)
        self.assertEqual([s["id"] for s in datos.obtener_solicitudes(ruta_a)], [sid])
        self.assertEqual(datos.obtener_solicitudes(ruta_b), [])
        self.assertEqual(datos.obtener_solicitudes(invitado), [])

    def test_exportar_o_borrar_servicios_no_elimina_la_cuenta(self):
        usuario = self.crear()
        ruta = cuentas.ruta_servicios(usuario["id"], self.ruta)
        datos.guardar_solicitud("Cliente ejemplo", "demo@example.test", "Casa ficticia", "Revisar una fuga",
                               "serv-plomeria", "1", db_path=ruta, acepta_politicas=True)
        exportado = perfiles.exportar_datos(ruta)
        self.assertEqual(len(exportado["solicitudes"]), 1)
        self.assertNotIn("cuentas", exportado)
        self.assertNotIn("aceptaciones_cuenta", exportado)
        perfiles.borrar_datos("BORRAR", ruta)
        self.assertEqual(datos.obtener_solicitudes(ruta), [])
        self.assertEqual(self.entrar()["id"], usuario["id"])


if __name__ == "__main__":
    unittest.main()
