import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch
from src.app.main import main
from src.app.win_list import abrir_perfil
from src.app.win_table import abrir_valoracion
from src.app.win_home import abrir_centro_ayuda,abrir_reporte
from src.app.win_form import open_win_form
from src.core import datos,perfiles


class PantallasTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.parche=patch.object(datos,'DB_path',Path(self.tmp.name)/'base.sqlite3');self.parche.start()
        self.root=tk.Tk();self.root.withdraw();self.errores=[]
        self.root.report_callback_exception=lambda tipo,error,traza:self.errores.append(str(error))
        with patch('src.app.main.tk.Tk',return_value=self.root),patch.object(self.root,'mainloop'):main(requerir_sesion=False)
    def tearDown(self):
        self.root.update();self.root.destroy();self.parche.stop();self.tmp.cleanup()
        self.assertEqual(self.errores,[])
    def solicitud(self):
        return datos.guardar_solicitud('Cliente ejemplo','demo@example.test','Lugar ficticio','Revisar fuga',
                                       'serv-plomeria','1',acepta_politicas=True)

    def test_perfil_ayuda_y_reporte_no_crean_ventanas_extra(self):
        for abrir in (lambda:abrir_perfil(self.root,'1'),lambda:abrir_centro_ayuda(self.root),lambda:abrir_reporte(self.root,trabajador_id='1')):
            abrir();self.root.update()
        self.assertEqual([w for w in self.root.winfo_children() if isinstance(w,tk.Toplevel)],[])

    def test_mapa_esta_en_el_modulo_canvas_sin_pedir_gps(self):
        with patch('src.app.win_canvas.webbrowser.open') as navegador:
            self.root.botones_menu['Mapa en vivo'].invoke();self.root.update()
        vista=self.root.navegador.actual
        self.assertEqual(vista.titulo,'Seguimiento')
        self.assertTrue(hasattr(vista,'mapa'))
        self.assertFalse(hasattr(self.root,'_ubicaciones'))
        navegador.assert_not_called()
        vista.mapa.mexico()
        self.assertEqual(vista.mapa.zoom,4)
        self.assertEqual(vista.mapa.centro,(23.63,-102.55))

    def test_formulario_no_marca_casillas_y_conserva_borrador_al_leer(self):
        servicio=next(s for s in datos.obtener_servicios() if s['id']=='serv-plomeria')
        trabajador=next(t for t in datos.obtener_trabajadores() if t['id']=='1')
        form=open_win_form(self.root,servicio,trabajador)
        self.assertFalse(form.acepta_politicas.get());self.assertFalse(form.mayor_edad.get())
        form.nombre.set('Borrador que se conserva')
        abrir_centro_ayuda(self.root,'privacidad');self.root.navegador.volver()
        self.assertIs(self.root.navegador.actual,form.ventana)
        self.assertEqual(form.nombre.get(),'Borrador que se conserva')

    def test_validacion_rechaza_campos_llenos_sin_consentimiento(self):
        servicio=next(s for s in datos.obtener_servicios() if s['id']=='serv-plomeria')
        trabajador=next(t for t in datos.obtener_trabajadores() if t['id']=='1')
        form=open_win_form(self.root,servicio,trabajador)
        form.nombre.set('Cliente ejemplo');form.contacto.set('demo@example.test');form.domicilio.set('Lugar ficticio')
        form.descripcion.insert('1.0','Revisar una fuga')
        with patch('src.app.ui.messagebox.showerror'):
            self.assertIsNone(form._validar())
        form.acepta_politicas.set(True)
        with patch('src.app.ui.messagebox.showerror'):self.assertIsNone(form._validar())
        form.mayor_edad.set(True)
        self.assertTrue(form._validar()['acepta_politicas'])

    def test_valorar_antes_de_terminar_no_abre_formulario(self):
        sid=self.solicitud()
        with patch('src.app.win_table.messagebox.showinfo'):
            self.assertIsNone(abrir_valoracion(self.root,sid))

    def test_valorar_trabajo_terminado_no_preselecciona_cinco_estrellas(self):
        sid=self.solicitud();q=datos.registrar_cotizacion(sid,500,True,'Revisión de ejemplo')
        datos.aceptar_cotizacion(q);datos.actualizar_estado(sid,'en_proceso');datos.actualizar_estado(sid,'completada')
        vista=abrir_valoracion(self.root,sid)
        self.assertEqual(vista.estrellas.get(),0)
        self.assertEqual(vista.comentario.get('1.0','end').strip(),'')

    def test_guardar_opinion_desde_su_boton_actualiza_el_perfil(self):
        sid=self.solicitud();q=datos.registrar_cotizacion(sid,500,True,'Revisión de ejemplo')
        datos.aceptar_cotizacion(q);datos.actualizar_estado(sid,'en_proceso');datos.actualizar_estado(sid,'completada')
        vista=abrir_valoracion(self.root,sid)
        vista.estrellas.set(3);vista.comentario.insert('1.0','Llegó tarde pero resolvió la fuga.')
        def buscar(widget):
            for hijo in widget.winfo_children():
                if hijo.winfo_class()=='TButton' and hijo.cget('text')=='Guardar opinión':return hijo
                encontrado=buscar(hijo)
                if encontrado is not None:return encontrado
        with patch('src.app.win_table.messagebox.askyesno',return_value=True):buscar(vista).invoke()
        self.root.update()
        resenas=[r for r in perfiles.obtener_perfil('1')['resenas'] if not r['ejemplo']]
        self.assertEqual(len(resenas),1)
        self.assertEqual(resenas[0]['estrellas'],3)
        self.assertEqual(resenas[0]['solicitud_id'],sid)

    def test_guardar_reporte_desde_su_boton_conserva_la_solicitud(self):
        sid=self.solicitud();vista=abrir_reporte(self.root,solicitud_id=sid)
        def hijos(widget):
            for hijo in widget.winfo_children():
                yield hijo
                yield from hijos(hijo)
        descripcion=next(w for w in hijos(vista) if isinstance(w,tk.Text))
        descripcion.insert('1.0','Quiero aclarar los materiales de esta solicitud.')
        boton=next(w for w in hijos(vista) if w.winfo_class()=='TButton' and w.cget('text')=='Guardar reporte local')
        with patch('src.app.win_home.messagebox.showinfo'):boton.invoke()
        self.root.update()
        reportes=perfiles.obtener_reportes()
        self.assertEqual(len(reportes),1)
        self.assertEqual(reportes[0]['solicitud_id'],sid)
        self.assertEqual(reportes[0]['estado'],'Guardado local')


if __name__=='__main__':unittest.main()
