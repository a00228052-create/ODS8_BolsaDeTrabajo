import tempfile
import unittest
from pathlib import Path

from src.core import datos
from src.core.catalogo import SERVICIOS, TRABAJADORES


class CatalogoAmpliadoTests(unittest.TestCase):
    def test_identificadores_y_nombres_de_oficios_son_unicos(self):
        self.assertEqual(len({s[0] for s in SERVICIOS}), len(SERVICIOS))
        self.assertEqual(len({s[1] for s in SERVICIOS}), len(SERVICIOS))
        self.assertTrue(all(s[0].startswith("serv-") and s[1] and s[2] for s in SERVICIOS))

    def test_perfiles_referencian_oficios_existentes(self):
        servicios = {s[0] for s in SERVICIOS}
        self.assertEqual(len({t[0] for t in TRABAJADORES}), len(TRABAJADORES))
        self.assertEqual({t[5] for t in TRABAJADORES}, servicios)
        for trabajador in TRABAJADORES:
            with self.subTest(trabajador=trabajador[0]):
                self.assertEqual(len(trabajador), 6)
                self.assertTrue(trabajador[1] and trabajador[2] and trabajador[3])
                self.assertIs(type(trabajador[4]), bool)

    def test_conserva_los_identificadores_originales(self):
        self.assertTrue({"serv-plomeria", "serv-electricidad", "serv-limpieza",
                         "serv-reparaciones", "serv-pintura", "serv-carpinteria",
                         "serv-jardineria", "serv-cerrajeria"}.issubset({s[0] for s in SERVICIOS}))
        originales = {t[0]: t for t in TRABAJADORES if t[0] in {str(i) for i in range(1, 11)}}
        self.assertEqual(len(originales), 10)
        self.assertEqual(originales["1"][1], "Ana López")
        self.assertEqual(originales["1"][5], "serv-plomeria")
        self.assertFalse(originales["4"][4])

    def test_carga_nuevos_oficios_y_perfiles_sin_duplicarlos(self):
        with tempfile.TemporaryDirectory() as carpeta:
            ruta = Path(carpeta) / "catalogo.sqlite3"
            datos.inicializar_base(ruta)
            datos.inicializar_base(ruta)
            self.assertEqual(len(datos.obtener_servicios(ruta)), len(SERVICIOS))
            self.assertEqual(len(datos.obtener_trabajadores(db_path=ruta)), len(TRABAJADORES))
            for oficio in ("serv-internet", "serv-paneles-solares", "serv-fumigacion"):
                trabajadores = datos.obtener_trabajadores(oficio, db_path=ruta)
                self.assertTrue(trabajadores)
                self.assertTrue(all(t["servicio_id"] == oficio for t in trabajadores))


if __name__ == "__main__":
    unittest.main()
