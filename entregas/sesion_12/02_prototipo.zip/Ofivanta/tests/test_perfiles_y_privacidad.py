import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from src.core import datos, perfiles, politicas


class PerfilesTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.parche=patch.object(datos,'DB_path',Path(self.tmp.name)/'base.sqlite3');self.parche.start()
    def tearDown(self):self.parche.stop();self.tmp.cleanup()
    def solicitud(self,acepta=True):
        return datos.guardar_solicitud('Cliente prueba','demo@example.test','Casa de ejemplo','Revisar fuga',
                                       'serv-plomeria','1',acepta_politicas=acepta)
    def completar(self,sid):
        q=datos.registrar_cotizacion(sid,500,True,'Incluye revisión y materiales de ejemplo')
        datos.aceptar_cotizacion(q);datos.actualizar_estado(sid,'en_proceso');datos.actualizar_estado(sid,'completada')

    def test_opiniones_de_ejemplo_separadas_y_no_duplicadas(self):
        a=perfiles.obtener_perfil('1');b=perfiles.obtener_perfil('1')
        self.assertEqual(len(a['resenas']),len(b['resenas']))
        self.assertEqual(a['valoraciones']['ejemplo']['promedio'],4.5)
        self.assertNotIn('local',a['valoraciones'])
        self.assertTrue(a['es_ejemplo'])

    def test_opinion_se_vincula_al_trabajador_de_la_solicitud(self):
        sid=self.solicitud();self.completar(sid)
        perfiles.guardar_resena(sid,2,'El horario podría haber sido más claro.')
        p=perfiles.obtener_perfil('1')
        self.assertEqual(p['valoraciones']['local'],{'cantidad':1,'promedio':2.0})
        self.assertEqual(p['valoraciones']['ejemplo']['promedio'],4.5)
        self.assertNotIn('local',perfiles.obtener_perfil('2')['valoraciones'])

    def test_no_permite_duplicar_una_opinion(self):
        sid=self.solicitud();self.completar(sid)
        perfiles.guardar_resena(sid,5,'Explicó lo que incluía el servicio.')
        with self.assertRaises(ValueError):perfiles.guardar_resena(sid,1,'Otro comentario sobre la misma solicitud.')

    def test_no_permite_opinar_sin_servicio_finalizado(self):
        sid=self.solicitud()
        for identificador in (sid,'inexistente'):
            with self.subTest(identificador=identificador),self.assertRaises(ValueError):
                perfiles.guardar_resena(identificador,5,'Comentario de prueba')

    def test_valida_estrellas_y_no_acepta_booleanos(self):
        sid=self.solicitud();self.completar(sid)
        for estrellas in (0,6,True,3.5,'5'):
            with self.subTest(estrellas=estrellas),self.assertRaises(ValueError):perfiles.guardar_resena(sid,estrellas,'Comentario válido')

    def test_evitar_contactos_en_opiniones_publicas(self):
        for texto in ('Escríbeme al correo uno@example.test','Mi teléfono es 477 123 4567','Hola\x00 mundo','a','x'*1501):
            with self.subTest(texto=texto[:30]),self.assertRaises(ValueError):perfiles.validar_opinion(texto)

    def test_reportar_no_borra_automaticamente_la_critica(self):
        sid=self.solicitud();self.completar(sid)
        rid=perfiles.guardar_resena(sid,1,'El trabajo no cumplió lo acordado.')
        perfiles.guardar_reporte('Opinión inapropiada','Solicito revisar este comentario.',resena_id=rid)
        self.assertEqual(perfiles.obtener_perfil('1')['valoraciones']['local']['promedio'],1)
        self.assertEqual(perfiles.obtener_reportes()[0]['estado'],'Guardado local')

    def test_reporte_con_relacion_incorrecta_no_se_guarda(self):
        rid=perfiles.obtener_perfil('1')['resenas'][0]['id']
        with self.assertRaises(ValueError):perfiles.guardar_reporte('Otro','Una descripción suficiente.',trabajador_id='2',resena_id=rid)
        self.assertEqual(perfiles.obtener_reportes(),[])

    def test_sin_aceptacion_no_se_crea_solicitud(self):
        with self.assertRaises(ValueError):self.solicitud(False)
        self.assertEqual(datos.obtener_solicitudes(),[])

    def test_aceptacion_conserva_version_huella_y_texto(self):
        sid=self.solicitud()
        with datos.conexion() as con:
            a=con.execute('SELECT * FROM aceptaciones WHERE solicitud_id=?',(sid,)).fetchone()
            d=con.execute('SELECT * FROM documentos_legales WHERE huella=?',(a['huella'],)).fetchone()
        self.assertEqual(a['version'],politicas.VERSION)
        self.assertEqual(a['huella'],politicas.huella())
        self.assertIn('Privacidad y ubicación',d['contenido'])

    def test_actualizar_catalogo_no_altera_solicitudes(self):
        sid=self.solicitud()
        for _ in range(3):perfiles.preparar()
        self.assertEqual(datos.obtener_solicitud(sid)['descripcion'],'Revisar fuga')

    def test_borrar_exige_confirmacion_y_no_elimina_el_catalogo(self):
        sid=self.solicitud();self.completar(sid)
        perfiles.guardar_resena(sid,4,'La reparación quedó como acordamos.')
        perfiles.guardar_reporte('Otro','Reporte de prueba con contenido suficiente.',solicitud_id=sid)
        with self.assertRaises(ValueError):perfiles.borrar_datos('sí')
        self.assertIsNotNone(datos.obtener_solicitud(sid))
        perfiles.borrar_datos('BORRAR')
        self.assertEqual(datos.obtener_solicitudes(),[])
        self.assertEqual(perfiles.obtener_reportes(),[])
        self.assertEqual(len(datos.obtener_trabajadores()),len(datos.TRABAJADORES))
        self.assertNotIn('local',perfiles.obtener_perfil('1')['valoraciones'])

    def test_exportacion_incluye_politica_aceptada(self):
        self.solicitud()
        exportado=perfiles.exportar_datos()
        self.assertEqual(len(exportado['solicitudes']),1)
        self.assertEqual(len(exportado['aceptaciones']),1)
        self.assertEqual(exportado['documentos_legales'][0]['huella'],exportado['aceptaciones'][0]['huella'])

    def test_marco_nacional_tiene_32_estados(self):
        self.assertEqual(len(set(politicas.ESTADOS_MEXICO)),32)
        self.assertIn('Ciudad de México',politicas.ESTADOS_MEXICO)
        self.assertIn('Yucatán',politicas.ESTADOS_MEXICO)


if __name__=='__main__':unittest.main()
