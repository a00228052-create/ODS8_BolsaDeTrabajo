import io
import json
import tempfile
import struct
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.parse import urlsplit,parse_qs
from urllib.request import Request,urlopen
from src.core import datos,mapa,ubicaciones


class UbicacionesTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.ruta=Path(self.tmp.name)/'base.sqlite3'
        self.parche=patch.object(datos,'DB_path',self.ruta);self.parche.start()
        self.sid=datos.guardar_solicitud('Persona de ejemplo','demo@example.test','Casa de ejemplo','Revisar fuga',
                                         'serv-plomeria','1',acepta_politicas=True)
        self.servicio=ubicaciones.ServicioUbicaciones(self.ruta)
    def tearDown(self):self.servicio.cerrar();self.parche.stop();self.tmp.cleanup()
    def confirmar(self):
        q=datos.registrar_cotizacion(self.sid,500,True,'Condiciones de ejemplo')
        datos.aceptar_cotizacion(q)
    def sesion(self,rol='cliente'):
        self.confirmar()
        url=self.servicio.crear_sesion(self.sid,rol)
        partes=urlsplit(url)
        self.base=partes.scheme+'://'+partes.netloc
        self.token=parse_qs(partes.fragment)['sesion'][0]
        return self.token
    def punto(self):return {'latitud':21.122,'longitud':-101.68,'precision':35,'medida_en':time.time()}
    def request(self,ruta,contenido=None,token=None,origen=None,host=None):
        headers={'X-Ofivanta-Sesion':self.token if token is None else token}
        if host:headers['Host']=host
        bruto=None
        if contenido is not None:
            headers.update({'Content-Type':'application/json','Origin':self.base if origen is None else origen})
            bruto=json.dumps(contenido).encode()
        return urlopen(Request(self.base+ruta,data=bruto,headers=headers),timeout=4)

    def test_solicitud_pendiente_no_admite_gps(self):
        with self.assertRaises(ValueError):self.servicio.crear_sesion(self.sid,'cliente')
        self.assertIsNone(self.servicio.server)

    def test_token_en_fragmento_y_solo_escucha_en_loopback(self):
        self.sesion()
        self.assertEqual(self.servicio.server.server_address[0],'127.0.0.1')
        self.assertNotIn('?',self.base)
        self.assertGreaterEqual(len(self.token),40)
        with self.request('/api/sesion') as r:
            self.assertEqual(json.load(r)['rol'],'cliente')
            self.assertIn("frame-ancestors 'none'",r.headers['Content-Security-Policy'])

    def test_ubicacion_solo_corresponde_a_su_sesion(self):
        self.sesion('prestador')
        punto=self.punto();punto['solicitud_id']='otra-solicitud';punto['rol']='cliente'
        with self.request('/api/posicion',punto):pass
        posiciones=self.servicio.posiciones(self.sid)
        self.assertEqual(set(posiciones),{'prestador'})
        self.assertEqual(posiciones['prestador']['latitud'],21.122)
        self.assertEqual(self.servicio.posiciones('otra-solicitud'),{})

    def test_sin_token_sin_origen_o_con_host_ajeno_no_escribe(self):
        self.sesion()
        variantes=[dict(token='incorrecto'),dict(origen='https://otra-web.example'),dict(host='otra-web.example')]
        for variante in variantes:
            with self.subTest(variante=variante),self.assertRaises(HTTPError):self.request('/api/posicion',self.punto(),**variante)
        self.assertEqual(self.servicio.posiciones(self.sid),{})

    def test_no_acepta_posiciones_antiguas_no_finitas_o_imposibles(self):
        self.sesion()
        for cambios in ({'latitud':100},{'longitud':200},{'latitud':float('nan')},{'precision':-1},{'medida_en':time.time()-1000},{'latitud':True}):
            punto=self.punto();punto.update(cambios)
            with self.subTest(cambios=cambios),self.assertRaises(HTTPError):self.request('/api/posicion',punto)

    def test_detener_retiro_inmediato_y_no_puede_reutilizar_token(self):
        self.sesion()
        with self.request('/api/posicion',self.punto()):pass
        with self.request('/api/detener',{}):pass
        self.assertEqual(self.servicio.posiciones(self.sid),{})
        with self.assertRaises(HTTPError):self.request('/api/posicion',self.punto())

    def test_caducidad_del_punto_y_fin_del_servicio(self):
        self.sesion()
        self.servicio.actualizar(self.token,self.punto())
        self.servicio.puntos[(self.sid,'cliente')]['medida_en']=time.time()-100
        self.assertEqual(self.servicio.posiciones(self.sid),{})
        self.servicio.actualizar(self.token,self.punto())
        datos.actualizar_estado(self.sid,'en_proceso');datos.actualizar_estado(self.sid,'completada')
        self.assertEqual(self.servicio.posiciones(self.sid),{})
        with self.assertRaises(ValueError):self.servicio.actualizar(self.token,self.punto())

    def test_ubicacion_no_crea_historial_en_la_base(self):
        self.sesion();self.servicio.actualizar(self.token,self.punto());self.servicio.revocar_todo()
        with datos.conexion() as con:
            tablas={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertNotIn('ubicaciones',tablas)
        self.assertEqual(self.servicio.puntos,{})
        self.assertEqual(self.servicio.sesiones,{})

    def test_archivos_fuera_de_la_lista_no_se_sirven(self):
        self.sesion()
        for ruta in ('/../core/datos.py','/datos.sqlite3','/api/sesion?token=incorrecto'):
            if ruta.startswith('/api'):continue
            with self.subTest(ruta=ruta),self.assertRaises(HTTPError):self.request(ruta)


class MapaTests(unittest.TestCase):
    def test_coordenadas_del_pais_se_proyectan_y_recuperan(self):
        for lat,lon in [(21.122,-101.68),(19.43,-99.13),(32.51,-117.04),(20.96,-89.59)]:
            for zoom in (5,13,18):
                x,y=mapa.proyectar(lat,lon,zoom)
                a,b=mapa.coordenadas(x,y,zoom)
                self.assertAlmostEqual(a,lat,places=5);self.assertAlmostEqual(b,lon,places=5)

    def test_cache_respeta_max_age_y_no_repite_descarga(self):
        class Respuesta(io.BytesIO):
            headers={'Cache-Control':'max-age=604800','ETag':'"prueba"'}
        with tempfile.TemporaryDirectory() as tmp:
            cache=mapa.CacheMapa(tmp)
            png=b'\x89PNG\r\n\x1a\n'+b'\x00\x00\x00\x0dIHDR'+struct.pack('>II',256,256)+b'prueba'
            with patch('src.core.mapa.urlopen',return_value=Respuesta(png)) as abrir:
                a=cache.obtener(5,3,6);b=cache.obtener(5,3,6)
            self.assertEqual(a,b);abrir.assert_called_once()
            peticion=abrir.call_args.args[0]
            self.assertEqual(peticion.full_url,'https://tile.openstreetmap.org/5/3/6.png')
            self.assertIn('Ofivanta',peticion.headers['User-agent'])

    def test_coordenadas_fuera_del_rango_no_generan_descargas(self):
        with tempfile.TemporaryDirectory() as tmp,patch('src.core.mapa.urlopen') as abrir:
            cache=mapa.CacheMapa(tmp)
            for xyz in ((1,0,0),(5,-1,0),(5,0,100),(19,1,1)):
                with self.subTest(xyz=xyz),self.assertRaises(ValueError):cache.obtener(*xyz)
            abrir.assert_not_called()

    def test_no_carga_imagenes_de_dimensiones_peligrosas(self):
        png=b'\x89PNG\r\n\x1a\n'+b'\x00\x00\x00\x0dIHDR'+struct.pack('>II',20000,20000)
        with self.assertRaises(ValueError):mapa.validar_png(png)

    def test_cache_danada_se_recupera_con_una_descarga(self):
        class Respuesta(io.BytesIO):
            headers={'Cache-Control':'max-age=604800'}
        png=b'\x89PNG\r\n\x1a\n'+b'\x00\x00\x00\x0dIHDR'+struct.pack('>II',256,256)+b'prueba'
        with tempfile.TemporaryDirectory() as tmp:
            cache=mapa.CacheMapa(tmp)
            Path(tmp,'5_3_6.png').write_bytes(b'archivo incompleto')
            Path(tmp,'5_3_6.json').write_text('[]',encoding='utf-8')
            with patch('src.core.mapa.urlopen',return_value=Respuesta(png)) as abrir:
                self.assertEqual(cache.obtener(5,3,6),png)
            abrir.assert_called_once()


if __name__=='__main__':unittest.main()
