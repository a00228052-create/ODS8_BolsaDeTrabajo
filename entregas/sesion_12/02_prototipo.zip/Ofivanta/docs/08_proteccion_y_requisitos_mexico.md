Ofivanta. Protección y requisitos antes de ofrecer servicios en México

20 de noviembre de 2026

La aplicación conserva la estructura del profesor y funciona como un prototipo local. Las condiciones de la app no la vuelven inmune a demandas, daños, multas o delitos. Este documento organiza los riesgos y lo que falta revisar. No es una certificación de cumplimiento ni un contrato comercial listo para publicar.

La base federal cubre todo México. La lista de estados de la app permite consultar este alcance nacional, pero no acredita una revisión individual de los 32 códigos civiles, reglamentos de construcción o permisos municipales. Antes de activar un oficio en una ciudad, habrá que revisar su legislación local y los requisitos de ese trabajo.

1. Datos personales y GPS

El registro y el formulario presentan las condiciones y la privacidad. Conservan la versión, la huella del texto y la fecha de aceptación. La ubicación es opcional, requiere permiso del navegador y solo corresponde al dispositivo que lo autoriza. El puente funciona en 127.0.0.1, con sesiones temporales, comprobación de origen y sin publicar el servicio a Internet. Las posiciones caducan en 90 segundos sin una medición reciente y no forman un historial en la base.

Ya hay cuentas locales con correo y contraseña, pero el correo y la identidad no se verifican. Google y Apple aparecen como opciones aún no disponibles y no conectan cuentas de esos proveedores. No se envían correos ni se sincronizan usuarios entre dispositivos. La contraseña se guarda como una derivación PBKDF2 con sal aleatoria y no como texto. El perfil permite guardar nombre, teléfono y dirección de casa; los ajustes guardan el tema, la reducción de movimiento y los avisos locales.

Cada cuenta abre su propia base de servicios. El modo invitado abre otra base, compartida por quienes elijan ese modo en la computadora. Esta separación se aplica al recorrido de la app: los archivos y sus respaldos no están cifrados, y quien tenga acceso a ellos podría leerlos o modificarlos. Una contraseña local no protege frente a ese acceso al sistema ni equivale a permisos de servidor.

Exportar y borrar desde Ayuda y seguridad solo corresponde a los servicios de la cuenta abierta o del modo invitado. La herramienta no incluye ni elimina la cuenta de acceso, su perfil, ajustes, derivación de contraseña o aceptación del registro. Tampoco elimina otras bases, exportaciones o respaldos. Todavía falta un procedimiento completo para exportar o eliminar los datos de la cuenta. Por eso deben usarse datos ficticios.

Antes de trabajar con personas reales hacen falta un responsable identificado, domicilio y contacto, aviso completo, procedimientos ARCO, conservación justificada, control de acceso, cifrado, respuesta a incidentes y revisión de proveedores. Las funciones locales actuales no sustituyen esos procedimientos. Base: [LFPDPPP vigente](https://www.diputados.gob.mx/LeyesBiblio/pdf/LFPDPPP.pdf).

2. Precio, contratos y cancelaciones

La app muestra el importe de cada propuesta, sus materiales y condiciones antes de aceptar. Mantiene el porcentaje de comisión original y no renueva Pro automáticamente. En el prototipo no hay pagos ni penalizaciones. El cliente puede cancelar antes de iniciar y registrar un desacuerdo después.

Para una operación comercial deben documentarse visitas, anticipos, reprogramación, cambios de alcance, materiales, inasistencia, devoluciones y garantías. Hay que identificar a las partes y ofrecer un canal de reclamación real. No procede una cláusula que elimine en bloque derechos del consumidor o toda responsabilidad. Base: [LFPC](https://www.diputados.gob.mx/LeyesBiblio/pdf/LFPC.pdf).

La NOM-174-SCFI-2007 incluye reglas de información y contratos para determinados servicios. En su ámbito, los contratos de adhesión de reparación o mantenimiento de los tipos previstos, incluido mantenimiento de inmuebles y sus muebles, requieren revisar el registro ante Profeco. La aceptación de esta demostración no reemplaza un contrato registrado. Fuentes: [estado vigente de la norma](https://platiica.economia.gob.mx/normalizacion/nom-174-scfi-2007/) y [texto en el DOF](https://dof.gob.mx/normasOficiales/2845/SEECO2/SEECO2.htm).

3. Daños, accidentes y trabajo peligroso

Una reparación puede causar lesiones, incendio, daño al inmueble o pérdida de bienes. Antes de operar se necesitan criterios para admitir oficios, comprobar formación y permisos, documentar el alcance del trabajo y resolver incidentes. Deben revisarse seguros con coberturas, exclusiones y límites reales. La app no presenta a nadie como asegurado o certificado.

Los reportes del prototipo solo quedan en la computadora. No prometen vigilancia, indemnización ni respuesta remota. Ante peligro inmediato en México corresponde llamar al [911](https://www.gob.mx/911/es/articulos/que-es-el-911emergencias?idiom=es).

4. Prestadores y obligaciones laborales

No basta con llamar independiente al trabajador. El modelo real de asignación, supervisión y remuneración debe revisarse frente a la Ley Federal del Trabajo, incluido el capítulo de plataformas digitales cuando resulte aplicable. También deben revisarse seguridad social, condiciones de seguridad, revisión de decisiones y atención a quejas de los prestadores. Base: [LFT, capítulo IX Bis](https://www.diputados.gob.mx/LeyesBiblio/pdf/LFT.pdf).

5. Pagos e impuestos

El proyecto no debe recibir dinero de clientes hasta definir quién cobra, cómo se factura, qué pasa con anticipos y contracargos y qué obligaciones fiscales corresponden. La comisión de 10 % o 7 % no calcula impuestos ni prueba la utilidad del negocio. Un servicio real debería usar un proveedor de pagos y evitar guardar datos de tarjeta. El tratamiento de ingresos, facturación y retenciones necesita revisión fiscal. Referencias: [SAT sobre plataformas](https://www.gob.mx/sat/prensa/brindan-sat-y-stps-certeza-juridica-a-trabajadores-de-plataformas-digitales-033-2025?idiom=es) y [RMF 2026](https://www.sat.gob.mx/minisitio/NormatividadRMFyRGCE/documentos2026/rmf/rmf/RMF_2026-DOF-28122025.pdf).

6. Estrellas, fraude y reputación

Las opiniones de ejemplo aparecen separadas de las vinculadas a solicitudes locales. Una solicitud finalizada admite una opinión, y el trabajador se obtiene de esa solicitud. Se bloquean teléfonos y correos en comentarios, aunque eso no detecta todos los datos sensibles. Reportar una crítica no la borra automáticamente.

Antes de publicar harán falta cuentas verificadas, controles contra suplantación y reseñas falsas, revisión humana, respuesta del prestador y apelación. Debe existir un procedimiento para atender amenazas, acoso, discriminación y denuncias. Una buena calificación no garantiza seguridad.

7. Nombre, mapa y proveedores

Ofivanta usa su propia identidad visual. No se afirma que el nombre esté libre o registrado. Antes de invertir en publicidad debe revisarse la marca y la clase de servicios ante el [IMPI](https://www.gob.mx/impi/documentos/registro-de-marcas).

El mapa conserva la atribución a OpenStreetMap y descarga únicamente el área visible con caché. Sus servidores públicos no tienen una garantía de disponibilidad. Antes de escalar habrá que elegir un proveedor adecuado y revisar sus términos y privacidad. Fuente: [política de uso de mosaicos](https://operations.osmfoundation.org/policies/tiles/).

Antes de abrir al público

El equipo debe completar la identidad del operador y sus canales reales, revisar contratos con asesoría mexicana, confirmar permisos por oficio y localidad, definir la relación con prestadores y resolver impuestos y seguros. También necesita un servidor, cuentas verificadas y permisos por usuario, atención completa de derechos de datos, monitoreo de seguridad, atención de incidentes y un proveedor de pagos. El GPS actual no conecta dispositivos remotos y los reportes no llegan a un centro de atención. Las cuentas locales no resuelven esos pendientes ni se presentan como un sistema comercial terminado.
