Ofivanta. Cambios en la aplicación

20 de noviembre de 2026

La idea de Ofivanta es que una persona encuentre ayuda para un trabajo en su casa. Puede buscar un oficio, elegir a un trabajador y explicar lo que necesita antes de revisar una cotización.

Se mantuvieron main.py y las cinco ventanas del profesor. El inicio tiene el logo de una casa dentro de una O, un fondo azul con degradado y botones redondeados.

![Inicio](capturas/12_inicio.png)

Antes se abrían varias ventanas y se amontonaban. Ahora todo aparece en la ventana principal. El menú queda visible y Volver permite regresar sin perder los filtros o lo que se estaba escribiendo. Si ya hay un formulario empezado y se elige otro trabajador, aparece una pregunta antes de cambiarlo.

En Buscar servicio se puede filtrar por oficio, nombre, zona y disponibilidad. Al seleccionar a alguien aparecen sus datos. También se pueden guardar favoritos y abrir el perfil completo.

![Buscar servicio](capturas/12_catalogo.png)

El perfil muestra el oficio, la zona, la disponibilidad y una descripción del trabajador. Por ahora todos son ficticios y lo dicen claramente. No se presentan como personas verificadas o aseguradas.

![Perfil del trabajador](capturas/12_perfil.png)

Las estrellas y los comentarios tienen su propia sección. Las opiniones de ejemplo se separan de las vinculadas a solicitudes de esta computadora. Solo se permite una opinión por solicitud finalizada. El reporte de una crítica no la borra automáticamente.

![Opiniones](capturas/12_opiniones.png)

El formulario recibe al trabajador elegido. Pide nombre, contacto, domicilio, fecha y una descripción del trabajo. La fecha y el horario son preferencias que después debe confirmar el trabajador. Antes de enviar se leen las condiciones y la privacidad. Las casillas empiezan desmarcadas y la solicitud conserva la versión de los textos aceptados.

![Formulario](capturas/11_formulario_detalle.png)

Después de enviar, la solicitud aparece en Mis solicitudes. Desde ahí se consultan los detalles y se acepta una cotización. En Seguimiento se ve si está pendiente, cotizada, confirmada, en proceso o finalizada. También se puede cancelar antes de iniciar el trabajo.

![Mis solicitudes](capturas/11_solicitudes.png)

![Detalle de solicitud](capturas/11_cotizaciones.png)

![Seguimiento](capturas/11_seguimiento.png)

Mapa en vivo usa OpenStreetMap dentro de la misma ventana. Se puede arrastrar, acercar y volver a la vista de México. Si falla Internet, las demás secciones siguen disponibles.

Compartir mi ubicación abre el navegador para pedir permiso al usuario. Solo se admite en una solicitud confirmada o en proceso. El GPS empieza apagado, se puede detener y las posiciones dejan de mostrarse cuando no hay una medición reciente. No se guarda un historial del recorrido. El botón de prestador sirve para probar otro rol con el mismo dispositivo; todavía no conecta teléfonos de trabajadores remotos.

El punto naranja de la captura es un recorrido ficticio. No representa a una persona real ni calcula su tiempo de llegada.

![Mapa con recorrido de ejemplo](capturas/12_mapa.png)

Ayuda y seguridad reúne privacidad, condiciones, cancelaciones, reglas de prestadores y reportes. Un problema reportado queda en esta computadora y no avisa a una central ni a emergencias. También se pueden exportar o borrar los datos locales con confirmación.

![Privacidad y ayuda](capturas/12_privacidad.png)

La base legal considera todo México. Incluye datos personales, protección al consumidor, contratos, trabajo en plataformas y obligaciones fiscales. Los permisos del oficio y las reglas del estado y municipio necesitan una revisión aparte antes de ofrecer servicios reales. Las condiciones no eliminan toda responsabilidad por daños. Los pendientes y las fuentes oficiales están en [Protección y requisitos en México](08_proteccion_y_requisitos_mexico.md).

Para generar ingresos se propone una comisión por trabajo terminado y un plan opcional para trabajadores. Básico cobra el 10 % sin mensualidad. Pro cobra el 7 % en nuevas cotizaciones y $149 por 30 días. Incluye agenda y resumen de ganancias. El porcentaje se guarda en cada cotización para que cambiar de plan no modifique lo que ya se ofreció.

Por ejemplo, con 20 trabajos de $500, Básico dejaría $9,000 después de la comisión. Pro dejaría $9,151 después de la comisión y la cuota. La calculadora permite comparar otros casos. Estas cantidades no descuentan materiales, impuestos ni otros gastos.

![Planes](capturas/11_planes.png)

![Agenda](capturas/11_agenda.png)

El apartado de ingresos suma las comisiones de trabajos finalizados y las cuotas Pro de la demostración.

![Ingresos](capturas/11_ingresos.png)

Pasaron 89 pruebas. Se revisaron búsqueda, guardado, cotizaciones, planes, opiniones, reportes, aceptación de condiciones, permisos de ubicación y navegación. También se abrieron las pantallas para comprobar su diseño. Las capturas usan datos ficticios y bases temporales separadas de los datos de uso. Las imágenes con prefijo 11 corresponden al avance anterior de las secciones que se conservaron; las 12 muestran los nuevos perfiles, opiniones, mapa y ayuda.

Esta versión funciona de forma local, con perfiles ficticios y sin cobros. Para ofrecer el servicio a personas reales todavía hacen falta cuentas y permisos por usuario, un servidor compartido, conexión entre dispositivos, atención de incidentes y un sistema de pagos. También faltan la identidad del operador, los contratos comerciales y la revisión profesional de seguros, impuestos y requisitos por localidad.
