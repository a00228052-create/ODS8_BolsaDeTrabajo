Ofivanta. Nuevo Inicio, cuentas y ajustes

20 de noviembre de 2026

El Inicio ahora se centra en pedir un servicio. Arriba se elige el oficio, se escribe la dirección y se decide entre Ahora y Programar. Después se revisa a un profesional. Al abrir un formulario nuevo se conservan la dirección y las preferencias; un borrador que ya estaba empezado no se reemplaza automáticamente.

El catálogo tiene 20 oficios y 40 perfiles ficticios de varias ciudades de México. Las categorías usan iconos y referencias de precio marcadas como ejemplo. Las tarjetas muestran nombre, oficio, zona, opiniones y trabajos locales, con botones para ver el perfil, contratar y guardar un favorito. La disponibilidad pertenece al catálogo de prueba. La llegada se acuerda al cotizar: no hay una ubicación o un tiempo de llegada calculados para esos perfiles.

Si hay una solicitud activa, el Inicio permite retomar su seguimiento. Si no hay ninguna, muestra un acceso claro para encontrar un profesional. Las métricas indican profesionales disponibles en el catálogo, solicitudes abiertas, trabajos finalizados y favoritos. No se presentan como actividad de un negocio real. Cualquier estado de carga usado para demostrar el diseño es visual; no significa que se esté buscando a personas conectadas a un servidor.

El diseño conserva el azul de Ofivanta, con tarjetas redondeadas, iconos consistentes y espaciado más claro. Se puede cambiar entre modo claro y oscuro y reducir las animaciones. Los componentes se reutilizan en las pantallas de acceso, perfil y ajustes. La fuente Inter se carga para la app, sin instalarla en Windows; si el sistema no la reconoce se usa Segoe UI. Las licencias y procedencias están en [assets/fonts](../assets/fonts/FUENTE.txt) y [assets/lucide](../assets/lucide/FUENTE.txt).

Crear cuenta e iniciar sesión funcionan localmente con correo y contraseña. El correo no se verifica. La contraseña no se guarda como texto: se deriva con PBKDF2 y una sal distinta para cada cuenta. Tras varios intentos fallidos se aplica una espera antes de volver a entrar. No hay recuperación de contraseña por correo ni sincronización entre dispositivos.

Google y Apple todavía no inician sesión. Para conectarlos se necesita registrar y configurar el proyecto con cada proveedor y probar su flujo real de autorización. No se deben pedir sus contraseñas dentro de Ofivanta. Las referencias son [OAuth para aplicaciones de escritorio de Google](https://developers.google.com/identity/protocols/oauth2/native-app) y [Sign in with Apple](https://developer.apple.com/documentation/signinwithapple/configuring-your-webpage-for-sign-in-with-apple).

Cada cuenta abre su propia base de servicios en una carpeta con un identificador UUID. El modo invitado utiliza otra base, compartida por quienes elijan ese modo en la computadora. Los archivos no están cifrados: esta separación dentro de la app no protege contra alguien que pueda leer los archivos del equipo.

Mi perfil guarda nombre, teléfono y dirección de casa. Ajustes guarda la apariencia, la reducción de movimiento y los avisos locales. Exportar o borrar desde Ayuda y seguridad solo afecta a los servicios de la cuenta abierta o del modo invitado. La cuenta, el perfil, sus ajustes y los respaldos siguen existiendo. Esta herramienta todavía no cubre una exportación o eliminación completa de los datos de la cuenta.

Se mantienen las cinco ventanas del profesor y Python con tkinter. main.py conecta el recorrido, diseno.py comparte los componentes, inicio_cliente.py organiza el Inicio y sesion.py contiene acceso, perfil y ajustes. No se migró el proyecto a React o Electron.

Los trabajadores, precios y recorridos animados son ejemplos. No se ofrecen verificaciones de identidad, una garantía general, soporte 24/7, pagos reales o seguimiento de teléfonos remotos. Los pendientes para un servicio comercial están en [la revisión legal](08_proteccion_y_requisitos_mexico.md).

Las capturas de esta actualización se añadirán cuando termine la revisión visual. Los archivos previstos son 13_inicio_claro.png, 13_inicio_oscuro.png, 13_acceso.png, 13_perfil.png y 13_ajustes.png, dentro de docs/capturas.
