# Ofivanta

Ofivanta es una aplicación escolar para encontrar ayuda en casa. Tiene 20 oficios y 40 perfiles ficticios, con ejemplos de distintas ciudades de México. Puedes elegir a un profesional, explicar el trabajo y revisar una cotización antes de confirmar.

Está hecha con Python y tkinter y conserva los cinco archivos del profesor. El Inicio tiene solicitud rápida, categorías con iconos, tarjetas de profesionales, favoritos y seguimiento. También hay modo claro y oscuro, perfil y ajustes. Funciona en una computadora y no realiza cobros.

Para abrirla necesitas Python 3.10 o posterior con tkinter. Abre la carpeta del proyecto en VS Code y ejecuta:

```text
python -m src.app.main
```

En Windows también puedes abrir iniciar_ofivanta.bat. No necesitas instalar paquetes adicionales.

Al abrir puedes crear una cuenta local con tu correo y una contraseña, iniciar sesión o explorar como invitado. El correo no se verifica. Los botones de Google y Apple todavía no conectan con esos proveedores.

Para probar el recorrido:

1. En Inicio, elige un oficio, escribe la dirección y selecciona Ahora o Programar.
2. Pulsa Solicitar servicio, revisa un perfil y elige al profesional. La dirección y la fecha pasan al formulario nuevo.
3. Describe el trabajo, lee las condiciones y la privacidad y confirma el envío.
4. En Seguimiento, activa la simulación de prestador y crea una cotización de ejemplo. Acéptala desde Mis solicitudes.
5. Simula el inicio y el final del trabajo en Seguimiento. Después puedes dejar una opinión desde Mis solicitudes.

Las pantallas se muestran dentro de la misma ventana. Puedes cambiar de sección desde el menú lateral o usar Volver. Los filtros y el formulario sin enviar se conservan al regresar.

Mi perfil permite cambiar tu nombre, teléfono y dirección de casa. Ajustes permite cambiar el tema, reducir las animaciones y elegir si quieres avisos dentro de la app. Los avisos no llegan a otros dispositivos.

Las cuentas se guardan en data/cuentas.sqlite3. Cada una tiene sus servicios en data/perfiles/<id>/ofivanta.sqlite3; el identificador es un UUID. El modo invitado usa data/ofivanta.sqlite3, compartida por quienes entren como invitados en ese equipo. Estas bases no se suben al repositorio. Las contraseñas se derivan con PBKDF2 y una sal por cuenta; los archivos locales no están cifrados. Usa datos de ejemplo. Para otras rutas están OFIVANTA_CUENTAS_PATH y OFIVANTA_DB_PATH.

Se conservan win_home.py, win_form.py, win_list.py, win_table.py y win_canvas.py en src/app. main.py los conecta. diseno.py reúne los componentes del nuevo Inicio; inicio_cliente.py y sesion.py organizan sus pantallas. src/core maneja los datos y las cuentas. No hace falta cambiar a React o Electron para ejecutar esta versión.

La idea de ingresos es cobrar una comisión por los trabajos terminados. Básico usa el 10 % sin mensualidad. Pro usa el 7 % en nuevas cotizaciones y una cuota de ejemplo de $149 por 30 días. Incluye agenda y resumen por trabajador. Todo se simula; no hay pagos ni renovaciones automáticas.

Las opiniones ficticias dicen De ejemplo y su promedio se muestra separado. Al finalizar una solicitud local se puede escribir una opinión por trabajo. Los precios de las categorías son referencias de demostración, no cotizaciones. No se anuncian identidades verificadas, llegadas calculadas, una garantía general ni soporte 24/7.

Mapa en vivo está dentro de Seguimiento. Permite explorar México con OpenStreetMap, acercar y arrastrar el mapa. Necesita Internet para cargar las imágenes. Compartir mi ubicación abre un permiso del navegador para el GPS de este dispositivo y una solicitud confirmada o en proceso. El permiso empieza apagado y se puede revocar. El recorrido animado de ejemplo se identifica como simulación. No hay una red de teléfonos de trabajadores conectados ni tiempos de llegada calculados.

Ayuda y seguridad contiene condiciones, privacidad, cancelaciones y reportes locales. Permite exportar o borrar los servicios de la cuenta abierta o del modo invitado, con confirmación. Eso no exporta ni elimina la cuenta, el perfil, los ajustes o los respaldos. [La revisión legal](docs/08_proteccion_y_requisitos_mexico.md) explica el marco federal de México y lo que falta antes de operar comercialmente.

El nuevo Inicio y las cuentas se explican en [este avance](docs/09_inicio_cuentas_y_ajustes.md). La [documentación anterior](docs/07_interfaz_y_modelo_ingresos.md) conserva los cambios de navegación y el modelo de ingresos. Inter y Lucide se incluyen con sus [licencias de fuente](assets/fonts/OFL.txt) e [iconos](assets/lucide/LICENSE.txt).

Para ejecutar las pruebas:

```text
python -m unittest discover -s tests -v
```

Las pruebas revisan cuentas, búsqueda, formularios, guardado, cotizaciones, opiniones, consentimiento, permisos de ubicación y navegación. Usan bases temporales y necesitan una sesión de escritorio con tkinter. No activan el GPS real de la computadora.
