"""Seguimiento del trabajo y controles de simulación del prestador."""
import tkinter as tk
import base64
import math
import time
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from tkinter import ttk, messagebox
from ..core import datos, mapa as mosaicos
from ..core.ubicaciones import ServicioUbicaciones
from .ui import cerrar_vista, crear_ventana, encabezado, tarjeta, etiqueta, aviso_error, notificar_cambio, fecha_legible, fecha_corta, dinero, FONDO, VERDE, GRIS, TEXTO, BORDE


def open_win_canvas(parent,solicitud_id=None):
    win=crear_ventana(parent,"Seguimiento",1060,760)
    if isinstance(win,tk.Toplevel):win.minsize(960,700)
    pestanas=ttk.Notebook(win);pestanas.pack(fill='both',expand=True,padx=12,pady=12)
    avance=ttk.Frame(pestanas);area_mapa=ttk.Frame(pestanas)
    pestanas.add(avance,text='Avance del servicio');pestanas.add(area_mapa,text='Mapa en vivo')
    frame=ttk.Frame(avance,padding=22);frame.pack(fill="both",expand=True)
    acciones=ttk.Frame(frame);acciones.pack(side="bottom",fill="x")
    simulacion=tk.BooleanVar(value=False)
    ttk.Checkbutton(frame,text="Activar simulación de prestador (solo datos de ejemplo)",variable=simulacion,
        command=lambda:dibujar()).pack(side="bottom",anchor="w",pady=(14,6))
    encabezado(frame,"Seguimiento de tu servicio","Consulta el avance y los movimientos de cada solicitud.")
    selector=ttk.Frame(frame);selector.pack(fill="x",pady=(0,14))
    ttk.Label(selector,text="Solicitud").pack(side="left",padx=(0,10))
    combo=ttk.Combobox(selector,state="readonly");combo.pack(side="left",fill="x",expand=True)
    ttk.Button(selector,text="Actualizar",command=lambda:actualizar()).pack(side="left",padx=(8,0))
    resumen=ttk.Label(frame,text="",style="Subtitle.TLabel");resumen.pack(anchor="w")
    siguiente=ttk.Label(frame,text="",style="Accent.TLabel",wraplength=940)
    siguiente.pack(anchor="w",pady=(8,0))
    canvas=tk.Canvas(frame,height=130,bg=FONDO,highlightthickness=0)
    canvas.pack(fill="x",pady=(12,10))
    texto=ttk.Label(frame,text="",style="Muted.TLabel",wraplength=850)
    texto.pack(anchor="w",pady=(0,14))
    ttk.Label(frame,text="Movimientos de la solicitud",style="Subtitle.TLabel").pack(anchor="w",pady=(0,8))
    lista_movimientos=ttk.Frame(frame)
    lista_movimientos.pack(fill="both",expand=True)
    historial=ttk.Treeview(lista_movimientos,columns=("fecha","detalle"),show="headings",height=5)
    historial.heading("fecha",text="Fecha");historial.heading("detalle",text="Movimiento")
    historial.column("fecha",width=160,minwidth=140,stretch=False);historial.column("detalle",width=650)
    historial.pack(side="left",fill="both",expand=True)
    barra=ttk.Scrollbar(lista_movimientos,orient="vertical",command=historial.yview)
    barra.pack(side="right",fill="y")
    historial.configure(yscrollcommand=barra.set)
    solicitudes={};actual={}
    seleccion_id=[solicitud_id]

    def dibujar(event=None):
        canvas.delete("all")
        if not actual:
            canvas.create_text(20,55,text="Crea una solicitud para ver su seguimiento.",anchor="w",fill=GRIS,font=("Segoe UI",12))
        elif actual["estado"]=="cancelada":
            canvas.create_rectangle(12,12,max(100,canvas.winfo_width()-12),108,fill="#FCEEEF",outline="")
            canvas.create_text(30,42,text="Solicitud cancelada",anchor="w",fill="#A73A45",font=("Segoe UI",16,"bold"))
            canvas.create_text(30,75,text="Este servicio ya no continuará. Puedes buscar otro trabajador.",anchor="w",fill=GRIS)
        else:
            paso=datos.ORDEN_ESTADOS.index(actual["estado"])
            ancho=max(canvas.winfo_width(),650);espacio=(ancho-100)/4
            canvas.create_line(50,42,ancho-50,42,fill=BORDE,width=4)
            if paso:canvas.create_line(50,42,50+paso*espacio,42,fill=VERDE,width=4)
            for i,estado in enumerate(datos.ORDEN_ESTADOS):
                x=50+i*espacio;hecho=i<=paso
                canvas.create_oval(x-18,24,x+18,60,fill=VERDE if hecho else "white",outline=VERDE if hecho else BORDE,width=2)
                canvas.create_text(x,42,text=str(i+1),fill="white" if hecho else GRIS,font=("Segoe UI",11,"bold"))
                canvas.create_text(x,86,text=datos.ESTADOS[estado],width=130,fill=TEXTO if hecho else GRIS,font=("Segoe UI",10))
        estado=actual.get("estado")
        cotizar_btn.state(["!disabled"] if simulacion.get() and estado in ("pendiente","cotizada") else ["disabled"])
        iniciar_btn.state(["!disabled"] if simulacion.get() and estado=="cotizacion_aceptada" else ["disabled"])
        finalizar_btn.state(["!disabled"] if simulacion.get() and estado=="en_proceso" else ["disabled"])

    def actualizar(event=None):
        anterior=combo.get()
        try:registros=datos.obtener_solicitudes()
        except (OSError,datos.sqlite3.Error) as error:aviso_error(win,error);return
        solicitudes.clear()
        for s in registros:solicitudes[f"#{s['numero']} · {s['servicio']} · {s['estado_texto']}"]=s["id"]
        combo.configure(values=list(solicitudes))
        etiqueta_actual=next((k for k,v in solicitudes.items() if v==seleccion_id[0]),None)
        if etiqueta_actual:combo.set(etiqueta_actual)
        elif anterior in solicitudes:combo.set(anterior)
        elif solicitudes:combo.current(0)
        else:combo.set("")
        elegir()

    def elegir(event=None):
        identificador=solicitudes.get(combo.get())
        seleccion_id[0]=identificador
        actual.clear()
        for fila in historial.get_children():historial.delete(fila)
        if identificador:
            s=datos.obtener_solicitud(identificador)
            if s:actual.update(s)
        if actual:
            resumen.configure(text=f"{actual['servicio']} con {actual['trabajador']} · {actual['estado_texto']}")
            instrucciones={"pendiente":"Siguiente paso: espera una cotización del trabajador.",
                "cotizada":"Siguiente paso: abre Mis solicitudes y revisa la cotización.",
                "cotizacion_aceptada":"Cotización aceptada. Falta acordar e iniciar el trabajo.",
                "en_proceso":"El trabajo está en proceso. Aquí verás cuando finalice.",
                "completada":"Trabajo finalizado. El historial y la cotización quedan disponibles.",
                "cancelada":"Solicitud cancelada. Puedes buscar otro servicio."}
            siguiente.configure(text=instrucciones[actual['estado']])
            descripcion=actual['descripcion']
            if len(descripcion)>180:descripcion=descripcion[:177]+"..."
            texto.configure(text=f"{fecha_corta(actual['fecha'])} · {actual['horario']} · Prioridad: {actual['urgencia']} · {actual['zona']}\n{descripcion}")
            for movimiento in actual["movimientos"]:
                historial.insert("","end",values=(fecha_legible(movimiento["fecha"]),movimiento["detalle"]))
            historial.yview_moveto(1)
        else:
            resumen.configure(text="Todavía no hay solicitudes")
            siguiente.configure(text="Primero elige a un trabajador en Buscar servicio.")
            texto.configure(text="Busca un servicio y envía una solicitud para comenzar.")
        dibujar()

    def cambiar(nuevo_estado):
        if not actual or not simulacion.get():return
        if not messagebox.askyesno("Simular avance",f"¿Marcar como {datos.ESTADOS[nuevo_estado]} en este prototipo?",parent=win.winfo_toplevel()):return
        try:datos.actualizar_estado(actual["id"],nuevo_estado)
        except (ValueError,OSError,datos.sqlite3.Error) as error:aviso_error(win,error);return
        actualizar();notificar_cambio(win)

    def cotizar():
        if not actual or not simulacion.get():return
        identificador=actual["id"]
        plan=datos.obtener_plan(actual["trabajador_id"])
        porcentaje=datos.COMISION_PRO_PORCENTAJE if plan["plan"]=="pro" else datos.COMISION_PORCENTAJE
        cot=crear_ventana(win,"Cotización de ejemplo",740,650)
        if isinstance(cot,tk.Toplevel):cot.minsize(700,600)
        box=ttk.Frame(cot,padding=22);box.pack(fill="both",expand=True)
        pie=ttk.Frame(box);pie.pack(side="bottom",fill="x")
        encabezado(box,"Cotización de ejemplo","Simula la propuesta de un prestador. No se realiza un cobro.")
        ttk.Label(box,text="Importe en pesos mexicanos").pack(anchor="w")
        importe=ttk.Entry(box);importe.pack(fill="x",pady=(5,12));importe.focus_set()
        reparto=ttk.Label(box,text=f"Comisión del plan {'Pro' if plan['plan']=='pro' else 'Básico'}: {porcentaje} %. Se descuenta del total acordado.",style="Small.TLabel",wraplength=640)
        reparto.pack(anchor="w",pady=(0,12))
        def calcular_reparto(event=None):
            try:
                d=datos.desglosar_importe(importe.get(),porcentaje)
                reparto.configure(text=f"Ofivanta ({d['porcentaje']} %): {dinero(d['comision'])} · Neto trabajador: {dinero(d['neto'])}. "
                    "Simulación; no incluye otros gastos del trabajador.")
            except ValueError:reparto.configure(text="Escribe el importe para ver el reparto de ejemplo.")
        importe.bind("<KeyRelease>",calcular_reparto)
        materiales=tk.BooleanVar(value=False)
        ttk.Checkbutton(box,text="El importe incluye materiales",variable=materiales).pack(anchor="w",pady=(0,12))
        ttk.Label(box,text="Condiciones y alcance del trabajo").pack(anchor="w")
        condiciones=tk.Text(box,height=5,wrap="word",font=("Segoe UI",10),relief="solid",bd=1,padx=8,pady=8)
        condiciones.pack(fill="both",expand=True,pady=(5,14))
        def guardar():
            try:datos.registrar_cotizacion(identificador,importe.get(),materiales.get(),condiciones.get("1.0","end").strip())
            except (ValueError,OSError,datos.sqlite3.Error) as error:aviso_error(cot,error);return
            cerrar_vista(cot);actualizar();notificar_cambio(win)
        ttk.Button(pie,text="Guardar cotización",style="Primary.TButton",command=guardar).pack(side="left")
        ttk.Button(pie,text="Cerrar",command=lambda:cerrar_vista(cot)).pack(side="right")

    cotizar_btn=ttk.Button(acciones,text="Crear cotización",command=cotizar);cotizar_btn.pack(side="left")
    iniciar_btn=ttk.Button(acciones,text="Iniciar servicio",command=lambda:cambiar("en_proceso"));iniciar_btn.pack(side="left",padx=8)
    finalizar_btn=ttk.Button(acciones,text="Finalizar servicio",command=lambda:cambiar("completada"));finalizar_btn.pack(side="left")
    ttk.Button(acciones,text="Cerrar",command=lambda:cerrar_vista(win)).pack(side="right")
    combo.bind("<<ComboboxSelected>>",elegir);canvas.bind("<Configure>",dibujar)
    win.bind("<<DatosActualizados>>",actualizar)
    win.actualizar=actualizar;win.canvas=canvas
    mapa=MapaServicio(area_mapa,lambda:dict(actual),lambda:pestanas.select(avance))
    win.mapa=mapa
    win.ver_mapa=lambda:pestanas.select(area_mapa)
    win.ver_avance=lambda:pestanas.select(avance)
    def cambiar_pestana(event=None):
        es_mapa=pestanas.select()==str(area_mapa)
        if es_mapa:mapa.activar()
        nav=getattr(win._root(),'navegador',None)
        if nav and nav.actual is win and nav.al_cambiar:nav.al_cambiar('Mapa en vivo' if es_mapa else 'Seguimiento')
    pestanas.bind('<<NotebookTabChanged>>',cambiar_pestana)
    reloj=[None]
    def refrescar():
        if win.winfo_viewable():actualizar()
        reloj[0]=win.after(4000,refrescar)
    def cerrar_reloj(event):
        if event.widget is win and reloj[0]:
            win.after_cancel(reloj[0]);reloj[0]=None
    win.bind('<Destroy>',cerrar_reloj,add='+')
    reloj[0]=win.after(4000,refrescar)
    actualizar();return win


class MapaServicio:
    def __init__(self,parent,solicitud,elegir):
        self.parent=parent;self.solicitud=solicitud
        self.centro=(21.122,-101.68);self.zoom=13
        self.imagenes={};self.pendientes={};self.fallos={};self.cerrado=False
        self.ejecutor=ThreadPoolExecutor(max_workers=2,thread_name_prefix='mapa_ofivanta')
        self.cache=mosaicos.CacheMapa(datos.DB_path.parent/'cache_mapa')
        self.conectado=False;self.puntos={};self.arrastre=None;self.arrastre_real=False
        self.ultimo=None;self.paso=0;self.dibujado=None
        cabecera=ttk.Frame(parent,padding=(16,12));cabecera.pack(fill='x')
        ttk.Label(cabecera,text='Mapa del servicio',style='Subtitle.TLabel').pack(anchor='w')
        self.detalle=ttk.Label(cabecera,text='',style='Muted.TLabel',wraplength=900);self.detalle.pack(anchor='w',pady=(5,8))
        acciones=ttk.Frame(cabecera);acciones.pack(fill='x')
        ttk.Button(acciones,text='Elegir solicitud',command=elegir).pack(side='left')
        ttk.Button(acciones,text='Compartir mi ubicación',style='Primary.TButton',command=lambda:self.compartir('cliente')).pack(side='left',padx=8)
        ttk.Button(acciones,text='GPS de prestador demo',command=lambda:self.compartir('prestador')).pack(side='left')
        ttk.Button(acciones,text='Detener GPS',command=self.detener).pack(side='right')
        opciones=ttk.Frame(parent,padding=(16,0,16,8));opciones.pack(fill='x')
        ttk.Button(opciones,text='+',width=3,command=lambda:self.cambiar_zoom(1)).pack(side='left')
        ttk.Button(opciones,text='−',width=3,command=lambda:self.cambiar_zoom(-1)).pack(side='left',padx=4)
        ttk.Button(opciones,text='México',command=self.mexico).pack(side='left',padx=4)
        ttk.Button(opciones,text='Centrar GPS',command=self.centrar).pack(side='left',padx=4)
        self.demo=tk.BooleanVar(value=False)
        ttk.Checkbutton(opciones,text='Recorrido de ejemplo',variable=self.demo,command=self.cambiar_demo).pack(side='right')
        self.lienzo=tk.Canvas(parent,bg='#E9EFF7',highlightthickness=0,height=300)
        self.lienzo.pack(fill='both',expand=True,padx=16)
        self.lienzo.bind('<Configure>',lambda e:self.programar())
        self.lienzo.bind('<ButtonPress-1>',self.iniciar_arrastre)
        self.lienzo.bind('<B1-Motion>',self.arrastrar)
        self.lienzo.bind('<ButtonRelease-1>',self.terminar_arrastre)
        self.lienzo.bind('<MouseWheel>',lambda e:self.rueda(e))
        self.estado=ttk.Label(parent,text='Arrastra el mapa o usa + y − para acercarte.',style='Small.TLabel',wraplength=950)
        self.estado.pack(anchor='w',padx=16,pady=(6,0))
        pie=ttk.Frame(parent,padding=(16,5,16,10));pie.pack(fill='x')
        credito=ttk.Label(pie,text=mosaicos.ATRIBUCION,foreground='#2563EB',cursor='hand2')
        credito.pack(anchor='w');credito.bind('<Button-1>',lambda e:webbrowser.open('https://www.openstreetmap.org/copyright'))
        ttk.Label(pie,text='El mapa consulta OpenStreetMap. GPS opcional de este dispositivo, con permiso del navegador. Sin rutas ni tiempos de llegada garantizados.',
                  style='Small.TLabel',wraplength=980).pack(anchor='w')
        parent.bind('<Destroy>',self.cerrar,add='+')
        self.reloj=parent.after(150,self.refrescar)

    def servidor(self):
        raiz=self.parent._root()
        if not hasattr(raiz,'_ubicaciones'):
            raiz._ubicaciones=ServicioUbicaciones()
            servidor = raiz._ubicaciones
            def cerrar(event):
                if event.widget is raiz:servidor.cerrar()
            raiz.bind('<Destroy>',cerrar,add='+')
        return raiz._ubicaciones

    def activar(self):
        self.conectado=True;self.programar()

    def compartir(self,rol):
        s=self.solicitud()
        if not s:
            messagebox.showinfo('Primero una solicitud','Elige una solicitud confirmada o en proceso para compartir ubicación.',parent=self.parent.winfo_toplevel());return
        try:url=self.servidor().crear_sesion(s['id'],rol)
        except (ValueError,OSError,datos.sqlite3.Error) as error:aviso_error(self.parent,error);return
        if not webbrowser.open(url):
            messagebox.showinfo('Abre el navegador','No se pudo abrir el navegador. Inténtalo de nuevo desde la app.',parent=self.parent.winfo_toplevel())

    def detener(self):
        self.servidor().revocar_todo();self.puntos={};self.demo.set(False);self.programar()
        self.estado.configure(text='Ubicación detenida y retirada. Los permisos del navegador se administran en su configuración.')

    def centrar(self):
        if not self.puntos:
            self.estado.configure(text='Todavía no hay GPS reciente. Pulsa Compartir mi ubicación y autoriza el navegador.');return
        punto=next(iter(self.puntos.values()));self.centro=(punto['latitud'],punto['longitud']);self.zoom=15;self.programar()

    def mexico(self):self.centro=(23.63,-102.55);self.zoom=4;self.programar()
    def cambiar_demo(self):
        if self.demo.get():
            self.servidor().revocar_todo();self.puntos={};self.centro=(21.122,-101.68);self.zoom=14
        self.programar()
    def cambiar_zoom(self,cambio):self.zoom=max(2,min(18,self.zoom+cambio));self.programar()
    def rueda(self,event):self.cambiar_zoom(1 if event.delta>0 else -1);return 'break'
    def iniciar_arrastre(self,event):self.arrastre=(event.x,event.y,*mosaicos.proyectar(*self.centro,self.zoom))
    def arrastrar(self,event):
        if not self.arrastre:return
        x,y,cx,cy=self.arrastre
        limite=256*2**self.zoom
        self.centro=mosaicos.coordenadas(cx-(event.x-x),max(1,min(limite-1,cy-(event.y-y))),self.zoom)
        self.programar()
    def terminar_arrastre(self,event):self.arrastre=None

    def programar(self):
        if self.cerrado:return
        if self.dibujado:self.parent.after_cancel(self.dibujado)
        self.dibujado=self.parent.after(90,self.dibujar)

    def refrescar(self):
        if self.cerrado:return
        cambios=False
        for clave,futuro in list(self.pendientes.items()):
            if futuro.done():
                self.pendientes.pop(clave)
                try:
                    imagen=tk.PhotoImage(master=self.lienzo,data=base64.b64encode(futuro.result()).decode('ascii'))
                    self.imagenes[clave]=imagen
                except Exception:self.fallos[clave]=time.monotonic()+30
                cambios=True
        if self.parent.winfo_viewable():
            s=self.solicitud()
            self.detalle.configure(text=f"#{s['numero']} · {s['servicio']} con {s['trabajador']} · {s['estado_texto']}" if s else 'Puedes explorar México. Para GPS, elige una solicitud confirmada o en proceso.')
            servidor=getattr(self.parent._root(),'_ubicaciones',None)
            try:nuevos=servidor.posiciones(s.get('id')) if servidor and s else {}
            except (OSError,datos.sqlite3.Error):
                nuevos={};self.estado.configure(text='No se pudo consultar el seguimiento. Inténtalo de nuevo.')
            if nuevos!=self.puntos:self.puntos=nuevos;cambios=True
            if nuevos and self.demo.get():self.demo.set(False)
            if self.demo.get():self.paso+=.12;cambios=True
            if self.conectado and not self.imagenes:cambios=True
        if cambios:self.programar()
        self.reloj=self.parent.after(450,self.refrescar)

    def dibujar(self):
        self.dibujado=None
        if self.cerrado or not self.parent.winfo_viewable():return
        canvas=self.lienzo;canvas.delete('all')
        ancho,alto=canvas.winfo_width(),canvas.winfo_height()
        if ancho<60 or alto<60:return
        cx,cy=mosaicos.proyectar(*self.centro,self.zoom)
        x0,y0=cx-ancho/2,cy-alto/2
        visibles=set()
        if self.conectado:
            for tx in range(math.floor(x0/256),math.floor((x0+ancho)/256)+1):
                for ty in range(math.floor(y0/256),math.floor((y0+alto)/256)+1):
                    if not 0<=ty<2**self.zoom:continue
                    clave=(self.zoom,tx%(2**self.zoom),ty);visibles.add(clave)
                    px,py=tx*256-x0,ty*256-y0
                    if clave in self.imagenes:canvas.create_image(px,py,image=self.imagenes[clave],anchor='nw')
                    else:
                        canvas.create_rectangle(px,py,px+256,py+256,fill='#E9EFF7',outline='#D9E4F0')
                        if clave not in self.pendientes and len(self.pendientes)<10 and self.fallos.get(clave,0)<=time.monotonic():
                            self.pendientes[clave]=self.ejecutor.submit(self.cache.obtener,*clave)
        if len(self.imagenes)>60:self.imagenes={k:v for k,v in self.imagenes.items() if k in visibles}
        def pin(lat,lon,color,texto):
            x,y=mosaicos.proyectar(lat,lon,self.zoom);x-=x0;y-=y0
            canvas.create_oval(x-13,y-13,x+13,y+13,fill=color,outline='white',width=3)
            canvas.create_text(x,y-30,text=texto,fill='#111827',font=('Segoe UI',10,'bold'),width=220)
        for rol,punto in self.puntos.items():
            pin(punto['latitud'],punto['longitud'],'#2563EB' if rol=='cliente' else '#059669','GPS cliente' if rol=='cliente' else 'GPS dispositivo prestador demo')
        if self.demo.get():
            pin(21.122+math.sin(self.paso)*.006,-101.68+math.cos(self.paso)*.006,'#D97706','Recorrido ficticio de ejemplo')
            self.estado.configure(text='SIMULACIÓN: este punto animado no es un trabajador real ni una ruta calculada.')
        elif self.puntos:
            precisiones=' · '.join(f"{rol}: ±{round(p['precision'])} m" for rol,p in self.puntos.items())
            self.estado.configure(text='GPS reciente de este dispositivo. '+precisiones+'. Centra el mapa para verlo.')
        elif visibles and not any(k in self.imagenes for k in visibles) and any(k in self.fallos for k in visibles):
            self.estado.configure(text='No se pudo cargar OpenStreetMap. Comprueba Internet; las solicitudes siguen disponibles.')
            canvas.create_text(ancho/2,alto/2,text='Sin conexión al mapa\nPuedes seguir usando las demás secciones.',fill=GRIS,font=('Segoe UI',14),justify='center')
        else:self.estado.configure(text='Sin ubicación compartida o sin actualización reciente. Arrastra el mapa para explorar.')

    def cerrar(self,event):
        if event.widget is not self.parent:return
        self.cerrado=True
        if self.reloj:self.parent.after_cancel(self.reloj)
        if self.dibujado:self.parent.after_cancel(self.dibujado)
        self.ejecutor.shutdown(wait=False,cancel_futures=True)
