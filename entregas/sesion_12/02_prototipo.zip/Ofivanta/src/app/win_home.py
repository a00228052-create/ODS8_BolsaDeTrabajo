"""Inicio del cliente y demostración del modelo de negocio del equipo."""
import tkinter as tk
from tkinter import ttk, messagebox
from ..core import datos
from .ui import (
    crear_ventana, tarjeta, etiqueta, aviso_error, notificar_cambio,
    dinero, fecha_corta, cargar_logo, dibujar_degradado, ACENTO, FONDO, TEXTO, GRIS, VERDE, AZUL,
)


def construir_inicio(parent, abrir_catalogo, abrir_solicitudes, abrir_seguimiento, mostrar_pestanas=True):
    frame = ttk.Frame(parent, padding=24)
    pestanas = ttk.Frame(frame)
    if mostrar_pestanas:
        pestanas.pack(fill="x", pady=(0, 18))
    from .inicio_cliente import InicioCliente
    cliente = InicioCliente(frame, abrir_catalogo, abrir_solicitudes, abrir_seguimiento)
    negocio = ttk.Frame(frame)
    vistas = {"cliente": cliente, "negocio": negocio}
    botones_vista = {}

    def mostrar_vista(nombre="cliente"):
        for clave, vista in vistas.items():
            vista.pack_forget()
            botones_vista[clave].configure(
                style="Active.Tab.TButton" if clave == nombre else "Tab.TButton")
        vistas[nombre].pack(fill="both", expand=True)

    for clave, texto in [("cliente", "Para tu hogar"), ("negocio", "Planes e ingresos")]:
        boton = ttk.Button(pestanas, text=texto, style="Tab.TButton",
                           command=lambda valor=clave: mostrar_vista(valor))
        boton.pack(side="left", padx=(0, 8))
        botones_vista[clave] = boton

    # El apartado del prestador permanece dentro de win_home.py.
    ttk.Label(negocio, text="Planes y ganancias", style="Title.TLabel").pack(anchor="w")
    ttk.Label(negocio, text="Comisión por servicio y plan opcional. Demostración sin cobros.",
              style="Muted.TLabel").pack(anchor="w", pady=(5, 16))
    apartados = ttk.Notebook(negocio)
    apartados.pack(fill="both", expand=True)
    pagina_planes = ttk.Frame(apartados, padding=16)
    pagina_agenda = ttk.Frame(apartados, padding=16)
    pagina_ingresos = ttk.Frame(apartados, padding=16)
    for pagina, nombre in [(pagina_planes, "Planes"), (pagina_agenda, "Mi agenda"), (pagina_ingresos, "Ingresos")]:
        apartados.add(pagina, text=nombre)
    aviso = tarjeta(pagina_planes, padx=14, pady=12)
    aviso.pack(fill="x", pady=(0, 16))
    nota = etiqueta(aviso, "DEMO: Básico 10 %; Pro 7 % + $149 por 30 días. Importes de ejemplo.\n"
                    "No se solicita tarjeta, no se cobra y no hay renovación automática.", color=VERDE)
    nota.configure(wraplength=790)
    nota.pack(anchor="w")
    planes = ttk.Frame(pagina_planes)
    planes.pack(fill="x", pady=(0, 18))
    for i, (nombre, precio, descripcion) in enumerate([
        ("Básico", "$0 de mensualidad", "Recibe solicitudes y envía cotizaciones.\nComisión del 10 % al finalizar un servicio."),
        ("Pro", "$149 / 30 días de ejemplo", "Incluye agenda por trabajador y resumen de ganancias.\nComisión reducida al 7 % en nuevas cotizaciones."),
    ]):
        planes.columnconfigure(i, weight=1, uniform="planes")
        card = tarjeta(planes, padx=18, pady=16)
        card.grid(row=0, column=i, sticky="nsew", padx=(0, 12 if i == 0 else 0))
        etiqueta(card, nombre, grande=True, color=VERDE).pack(anchor="w")
        etiqueta(card, precio, grande=True).pack(anchor="w", pady=(6, 10))
        detalle = etiqueta(card, descripcion, color=GRIS)
        detalle.configure(wraplength=335)
        detalle.pack(anchor="w")

    calculadora = tarjeta(pagina_planes, padx=16, pady=14)
    calculadora.pack(fill="x", pady=(0, 18))
    etiqueta(calculadora, "Compara cuánto te quedaría", grande=True).pack(anchor="w")
    fila_calculo = tk.Frame(calculadora, bg="white")
    fila_calculo.pack(fill="x", pady=(10, 6))
    etiqueta(fila_calculo, "Importe MXN").pack(side="left", padx=(0, 8))
    importe = tk.StringVar(value="500")
    importe_entry = ttk.Entry(fila_calculo, textvariable=importe, width=14)
    importe_entry.pack(side="left", padx=(0, 10))
    etiqueta(fila_calculo, "Trabajos / 30 días").pack(side="left",padx=(8,8))
    cantidad=tk.StringVar(value="20")
    ttk.Spinbox(fila_calculo,from_=0,to=10000,textvariable=cantidad,width=6).pack(side="left",padx=(0,10))
    resultado = etiqueta(calculadora, "", color=VERDE)
    resultado.configure(wraplength=790)
    resultado.pack(anchor="w", pady=(5, 0))

    def calcular():
        try:
            r=datos.comparar_planes(importe.get(),cantidad.get())
        except ValueError as error:
            resultado.configure(text=str(error),fg="#A73A45")
            return
        comparacion=(f"Pro dejaría {dinero(r['diferencia'])} más en este ejemplo." if r['diferencia']>=0 else
                     f"Básico dejaría {dinero(-r['diferencia'])} más en este ejemplo.")
        resultado.configure(text=f"Volumen de servicios: {dinero(r['volumen'])} MXN\n"
                            f"Básico: comisión {dinero(r['comision_basica'])}; neto {dinero(r['neto_basico'])}.\n"
                            f"Pro: comisión {dinero(r['comision_pro'])} + cuota {dinero(r['cuota_pro'])}; neto {dinero(r['neto_pro'])}.\n"
                            f"{comparacion}",fg=VERDE)

    ttk.Button(fila_calculo, text="Calcular reparto", command=calcular).pack(side="right")
    importe_entry.bind("<Return>", lambda evento: calcular())
    calcular()
    aclaracion = etiqueta(calculadora, "La comisión se descuenta del importe acordado; el cliente no paga una cuota extra. "
                          "El neto no descuenta materiales, impuestos ni otros gastos.", color=GRIS)
    aclaracion.configure(wraplength=790, font=("Segoe UI", 9))
    aclaracion.pack(anchor="w", pady=(8, 0))

    ttk.Button(pagina_planes, text="Probar Pro en Mi agenda", style="Primary.TButton",
               command=lambda: apartados.select(pagina_agenda)).pack(anchor="w", pady=(0, 6))
    ttk.Label(pagina_agenda, text="Elige un trabajador de ejemplo", style="Subtitle.TLabel").pack(anchor="w", pady=(0, 10))
    selector = ttk.Frame(pagina_agenda)
    selector.pack(fill="x", pady=(0, 10))
    proveedor = ttk.Combobox(selector, state="readonly")
    proveedor.pack(side="left", fill="x", expand=True, padx=(0, 10))
    trabajadores = {t["id"]: t for t in datos.obtener_trabajadores()}
    por_nombre = {t["nombre"]: t["id"] for t in trabajadores.values()}
    proveedor.configure(values=list(por_nombre))
    proveedor.current(0)
    estado_plan = ttk.Label(pagina_agenda, text="", style="Accent.TLabel")
    estado_plan.pack(anchor="w", pady=(0, 8))
    acciones = ttk.Frame(selector)
    acciones.pack(side="right")
    ganancias = ttk.Label(pagina_agenda, text="", style="Muted.TLabel", wraplength=800)
    ganancias.pack(anchor="w", pady=(0, 12))
    lista = ttk.Frame(pagina_agenda)
    lista.pack(fill="x")
    agenda = ttk.Treeview(lista, columns=("fecha", "horario", "servicio", "estado"), show="headings", height=4)
    for columna, titulo, ancho in [("fecha", "Fecha deseada", 125), ("horario", "Horario preferido", 185),
                                   ("servicio", "Servicio", 180), ("estado", "Estado", 140)]:
        agenda.heading(columna, text=titulo)
        agenda.column(columna, width=ancho, minwidth=95)
    agenda.pack(side="left", fill="both", expand=True)
    barra = ttk.Scrollbar(lista, orient="vertical", command=agenda.yview)
    barra.pack(side="right", fill="y")
    agenda.configure(yscrollcommand=barra.set)
    nota_agenda = ttk.Label(pagina_agenda, text="", style="Small.TLabel")
    nota_agenda.pack(anchor="w", pady=(8, 0))

    def actualizar_prestador(event=None):
        trabajador_id = por_nombre.get(proveedor.get())
        if not trabajador_id:
            return
        plan = datos.obtener_plan(trabajador_id)
        for fila in agenda.get_children():
            agenda.delete(fila)
        pro = plan["plan"] == "pro"
        estado_plan.configure(text=f"Plan Pro de ejemplo · vence el {fecha_corta(plan['vence'])}" if pro else "Plan Básico · sin mensualidad")
        activar_btn.state(["disabled"] if pro else ["!disabled"])
        cancelar_btn.state(["!disabled"] if pro else ["disabled"])
        if pro:
            resumen_trabajador = datos.resumen_negocio(trabajador_id)
            ganancias.configure(text=f"Trabajos finalizados: {resumen_trabajador['servicios_finalizados']}   /   "
                                f"Neto por servicios: {dinero(resumen_trabajador['neto_trabajadores'])}   /   "
                                f"Suscripciones simuladas: {dinero(resumen_trabajador['suscripciones'])}")
            pendientes = datos.obtener_agenda(trabajador_id)
            for s in pendientes:
                agenda.insert("", "end", iid=s["id"], values=(fecha_corta(s["fecha"]), s["horario"], s["servicio"], s["estado_texto"]))
            nota_agenda.configure(text="Agenda de solicitudes abiertas. La fecha y el horario están por acordar con el cliente."
                                 if pendientes else "No tienes solicitudes abiertas. Las próximas aparecerán aquí.")
        else:
            ganancias.configure(text="La agenda y el resumen por trabajador se habilitan con el plan Pro de ejemplo.")
            nota_agenda.configure(text="Puedes activar la demostración sin pagar ni introducir datos bancarios.")

    def cambiar_plan(activar):
        trabajador_id = por_nombre[proveedor.get()]
        mensaje = ("¿Activar Pro de ejemplo para este trabajador?\n"
                   "Cada periodo de 30 días registra $149 simulados. Reactivar un periodo vigente no lo duplica. "
                   "No hay cargo ni renovación automática." if activar else
                   "¿Volver a Básico en esta demostración? Se conserva el historial del periodo simulado.")
        if not messagebox.askyesno("Simulación de plan", mensaje, parent=frame.winfo_toplevel()):
            return
        try:
            if activar:
                datos.activar_plan_pro(trabajador_id)
            else:
                datos.cancelar_plan_pro(trabajador_id)
        except (ValueError, OSError, datos.sqlite3.Error) as error:
            aviso_error(frame.winfo_toplevel(), error)
            return
        actualizar()
        notificar_cambio(frame)

    activar_btn = ttk.Button(acciones, text="Simular Pro", style="Primary.TButton", command=lambda: cambiar_plan(True))
    activar_btn.pack(side="left", padx=(0, 8))
    cancelar_btn = ttk.Button(acciones, text="Volver a Básico", command=lambda: cambiar_plan(False))
    cancelar_btn.pack(side="left")
    proveedor.bind("<<ComboboxSelected>>", actualizar_prestador)

    def ver_agenda():
        if not agenda.selection():
            messagebox.showwarning("Elige una solicitud", "Selecciona una fila de la agenda.", parent=frame.winfo_toplevel())
            return
        from .win_table import abrir_detalles
        abrir_detalles(frame.winfo_toplevel(), agenda.selection()[0])

    ttk.Button(pagina_agenda, text="Abrir solicitud de la agenda", command=ver_agenda).pack(anchor="w", pady=(10, 18))
    ttk.Label(pagina_ingresos, text="Resumen del negocio · acumulado simulado", style="Subtitle.TLabel").pack(anchor="w", pady=(0, 10))
    resumen_negocio = tarjeta(pagina_ingresos, padx=16, pady=14)
    resumen_negocio.pack(fill="x")
    ingresos = etiqueta(resumen_negocio, "", grande=True, color=VERDE)
    ingresos.configure(wraplength=790)
    ingresos.pack(anchor="w")
    detalle_ingresos = etiqueta(resumen_negocio, "", color=GRIS)
    detalle_ingresos.configure(wraplength=790)
    detalle_ingresos.pack(anchor="w", pady=(6, 0))
    nota_ingresos = etiqueta(resumen_negocio, "Solo se cuentan comisiones de servicios finalizados y periodos Pro activados. "
                            "Son registros de demostración, no dinero recibido.", color=GRIS)
    nota_ingresos.configure(wraplength=790, font=("Segoe UI", 9))
    nota_ingresos.pack(anchor="w", pady=(8, 0))
    grafica=tk.Canvas(resumen_negocio,height=190,bg="white",highlightthickness=0)
    grafica.pack(fill="x",pady=(18,0))
    ultimo_resumen={}

    def dibujar_ingresos(event=None):
        grafica.delete("all")
        ancho=max(600,grafica.winfo_width())
        maximo=max(ultimo_resumen.get("comisiones",0),ultimo_resumen.get("suscripciones",0),1)
        for i,(clave,titulo,color) in enumerate([("comisiones","Comisiones",TEXTO),("suscripciones","Planes Pro",VERDE)]):
            y=30+i*60
            valor=ultimo_resumen.get(clave,0)
            grafica.create_text(0,y+12,text=titulo,anchor="w",fill=TEXTO,font=("Segoe UI",10))
            grafica.create_rectangle(130,y,ancho-130,y+24,fill=FONDO,outline="")
            if valor:
                grafica.create_rectangle(130,y,130+(ancho-260)*valor/maximo,y+24,fill=color,outline="")
            grafica.create_text(ancho-5,y+12,text=dinero(valor),anchor="e",fill=TEXTO,font=("Segoe UI",10,"bold"))
        grafica.create_text(0,160,text="Acumulado de la demostración. No representa pagos recibidos.",anchor="w",fill=GRIS,font=("Segoe UI",9))

    grafica.bind("<Configure>",dibujar_ingresos)

    def actualizar(event=None):
        cliente.actualizar()
        actualizar_prestador()
        r = datos.resumen_negocio()
        ultimo_resumen.clear()
        ultimo_resumen.update(r)
        dibujar_ingresos()
        ingresos.configure(text=f"Ofivanta: {dinero(r['total_ofivanta'])} MXN simulados")
        detalle_ingresos.configure(text=f"Comisiones: {dinero(r['comisiones'])}   /   Planes Pro: {dinero(r['suscripciones'])}\n"
                                  f"Servicios finalizados: {r['servicios_finalizados']}   /   Planes activos: {r['planes_activos']}")

    frame.cliente = cliente
    frame.apartados = apartados
    frame.actualizar = actualizar
    frame.mostrar_vista = mostrar_vista
    frame.proveedor_combo = proveedor
    frame.agenda = agenda
    frame.importe_simulador = importe
    mostrar_vista()
    actualizar()
    return frame


def open_win_home(parent):
    win = crear_ventana(parent, "Inicio", 1100, 740)
    from .win_list import open_win_list
    from .win_table import open_win_table
    from .win_canvas import open_win_canvas
    canvas = tk.Canvas(win, bg=FONDO, highlightthickness=0)
    barra = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=barra.set)
    barra.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    frame = construir_inicio(canvas, lambda categoria=None: open_win_list(win, categoria),
                             lambda: open_win_table(win), lambda: open_win_canvas(win))
    elemento = canvas.create_window((0, 0), window=frame, anchor="nw")
    frame.bind("<Configure>", lambda evento: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.bind("<Configure>", lambda evento: canvas.itemconfigure(elemento, width=evento.width))
    win.bind("<MouseWheel>", lambda evento: canvas.yview_scroll(-1 if evento.delta > 0 else 1, "units"))
    win.bind("<<DatosActualizados>>", frame.actualizar)
    return win


def abrir_centro_ayuda(parent,seccion='seguridad'):
    import json
    from tkinter import filedialog,simpledialog
    from tkinter.scrolledtext import ScrolledText
    from ..core import politicas,perfiles
    from .ui import cerrar_vista,encabezado
    win=crear_ventana(parent,'Ayuda y seguridad',1060,760)
    frame=ttk.Frame(win,padding=22);frame.pack(fill='both',expand=True)
    encabezado(frame,'Ayuda y seguridad','Reglas claras para clientes y prestadores. Marco federal de México y revisión local por oficio.')
    acciones=ttk.Frame(frame);acciones.pack(fill='x',pady=(0,12))
    ttk.Button(acciones,text='Registrar un problema',style='Primary.TButton',command=lambda:abrir_reporte(win)).pack(side='left')
    ttk.Button(acciones,text='Ver reportes locales',command=lambda:ver_reportes()).pack(side='left',padx=8)
    ttk.Button(acciones,text='Cerrar',command=lambda:cerrar_vista(win)).pack(side='right')
    lugar=ttk.Frame(frame);lugar.pack(fill='x',pady=(0,12))
    ttk.Label(lugar,text='Entidad de consulta').pack(side='left',padx=(0,10))
    estado=ttk.Combobox(lugar,values=politicas.ESTADOS_MEXICO,state='readonly',width=24)
    estado.set('Guanajuato');estado.pack(side='left')
    ttk.Label(lugar,text='Las reglas federales cubren las 32 entidades. Los requisitos locales varían.',style='Small.TLabel',wraplength=520).pack(side='left',padx=12)
    pie=ttk.Frame(frame);pie.pack(side='bottom',fill='x',pady=(10,0))
    ttk.Button(pie,text='Exportar datos locales',command=lambda:exportar()).pack(side='left')
    ttk.Button(pie,text='Borrar datos locales',style='Danger.TButton',command=lambda:borrar()).pack(side='left',padx=8)
    ttk.Label(pie,text='Versión '+politicas.VERSION,style='Small.TLabel').pack(side='right')
    cuerpo=ttk.Frame(frame);cuerpo.pack(fill='both',expand=True)
    opciones=tk.Listbox(cuerpo,font=('Segoe UI',10),width=27,activestyle='none',relief='flat',bg='white',exportselection=False,selectbackground='#DBEAFE',selectforeground='#111827')
    opciones.pack(side='left',fill='y',padx=(0,14))
    texto=ScrolledText(cuerpo,wrap='word',font=('Segoe UI',11),relief='flat',padx=16,pady=14)
    texto.pack(side='left',fill='both',expand=True)
    claves=list(politicas.DOCUMENTOS)
    for titulo,_ in politicas.DOCUMENTOS.values():opciones.insert('end',titulo)
    def escribir(valor):
        texto.configure(state='normal');texto.delete('1.0','end');texto.insert('1.0',valor);texto.configure(state='disabled')
    def elegir(event=None):
        seleccion=opciones.curselection()
        if not seleccion:return
        titulo,contenido=politicas.DOCUMENTOS[claves[seleccion[0]]]
        nota=f"\n\nPara {estado.get()}: revisa también las reglas del municipio y los permisos del oficio. Esta selección no acredita una revisión de su legislación local."
        escribir(titulo+'\n\n'+contenido+nota)
    def ver_reportes():
        try:reportes=perfiles.obtener_reportes()
        except (OSError,datos.sqlite3.Error) as error:aviso_error(win,error);return
        texto_reportes='Reportes guardados en esta computadora\n\nNo se enviaron a una central de atención. Si hay peligro inmediato, llama al 911.\n\n'
        texto_reportes+='\n\n'.join(f"#{r['id'][:8].upper()} · {r['motivo']}\n{r['estado']}\n{r['descripcion']}" for r in reportes) if reportes else 'Todavía no hay reportes.'
        escribir(texto_reportes)
    def exportar():
        if not messagebox.askyesno('Exportar datos','El archivo contiene los servicios de la cuenta abierta o del modo invitado, incluidos contactos y domicilios. No incluye los datos de acceso ni el perfil. Guárdalo en un lugar privado. ¿Continuar?',parent=win.winfo_toplevel()):return
        ruta=filedialog.asksaveasfilename(parent=win.winfo_toplevel(),initialfile='ofivanta_datos_locales.json',defaultextension='.json',filetypes=[('Archivo JSON','*.json')])
        if not ruta:return
        try:
            with open(ruta,'w',encoding='utf-8') as archivo:json.dump(perfiles.exportar_datos(),archivo,ensure_ascii=False,indent=2)
        except (OSError,datos.sqlite3.Error) as error:aviso_error(win,error);return
        messagebox.showinfo('Datos exportados','Guarda este archivo de forma privada. No lo subas al repositorio.',parent=win.winfo_toplevel())
    def borrar():
        confirmacion=simpledialog.askstring('Borrar datos de servicios','Escribe BORRAR para eliminar los servicios de la cuenta abierta o del modo invitado. No se borran la cuenta, el perfil, otras cuentas ni los respaldos.',parent=win.winfo_toplevel())
        if confirmacion is None:return
        if confirmacion!='BORRAR':aviso_error(win,ValueError('No se borró nada. La confirmación debe ser BORRAR.'));return
        if not messagebox.askyesno('Confirmar eliminación','¿Eliminar los datos locales indicados? Esta acción no tiene deshacer dentro de la app.',parent=win.winfo_toplevel()):return
        try:
            perfiles.borrar_datos(confirmacion)
            servidor=getattr(win._root(),'_ubicaciones',None)
            if servidor:servidor.revocar_todo()
        except (ValueError,OSError,datos.sqlite3.Error) as error:aviso_error(win,error);return
        notificar_cambio(win);escribir('Los datos locales indicados se eliminaron. El catálogo de ejemplo sigue disponible. Las exportaciones y copias de seguridad no cambian.')
    opciones.bind('<<ListboxSelect>>',elegir);estado.bind('<<ComboboxSelected>>',elegir)
    opciones.selection_set(claves.index(seccion) if seccion in claves else 0);elegir()
    win.ver_reportes=ver_reportes
    return win


def abrir_reporte(parent,solicitud_id=None,trabajador_id=None,resena_id=None):
    from ..core import politicas,perfiles
    from tkinter.scrolledtext import ScrolledText
    from .ui import cerrar_vista,encabezado
    win=crear_ventana(parent,'Registrar un problema',900,700)
    frame=ttk.Frame(win,padding=22);frame.pack(fill='both',expand=True)
    encabezado(frame,'Registrar un problema','Este reporte se guarda en la computadora. No se envía automáticamente a soporte ni a emergencias.')
    ttk.Label(frame,text='Si existe peligro inmediato en México, llama al 911. No esperes una respuesta de esta app.',style='Accent.TLabel',wraplength=850).pack(anchor='w',pady=(0,16))
    if solicitud_id:ttk.Label(frame,text='Solicitud #'+solicitud_id[:8].upper()).pack(anchor='w',pady=(0,12))
    ttk.Label(frame,text='Motivo').pack(anchor='w')
    motivo=ttk.Combobox(frame,values=politicas.MOTIVOS,state='readonly');motivo.current(5 if resena_id else 0);motivo.pack(fill='x',pady=(6,16))
    ttk.Label(frame,text='Describe lo ocurrido. No incluyas contraseñas, tarjetas o datos sensibles.').pack(anchor='w')
    descripcion=ScrolledText(frame,height=7,wrap='word',font=('Segoe UI',11));descripcion.pack(fill='both',expand=True,pady=10)
    pie=ttk.Frame(frame);pie.pack(fill='x',pady=(10,0))
    def guardar():
        try:rid=perfiles.guardar_reporte(motivo.get(),descripcion.get('1.0','end').strip(),solicitud_id,trabajador_id,resena_id)
        except (ValueError,OSError,datos.sqlite3.Error) as error:aviso_error(win,error);return
        notificar_cambio(win)
        messagebox.showinfo('Reporte guardado localmente','Folio #'+rid[:8].upper()+'. Quedó en esta computadora; nadie lo recibió de forma remota. Puedes verlo en Ayuda y seguridad.',parent=win.winfo_toplevel())
        cerrar_vista(win)
    ttk.Button(pie,text='Guardar reporte local',style='Primary.TButton',command=guardar).pack(side='left')
    ttk.Button(pie,text='Cancelar',command=lambda:cerrar_vista(win)).pack(side='right')
    return win
