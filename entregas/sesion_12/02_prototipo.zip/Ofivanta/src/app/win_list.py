"""Ventana 3: buscar un oficio y elegir un trabajador."""
import tkinter as tk
from tkinter import ttk, messagebox
from tkinter.scrolledtext import ScrolledText
from ..core.servicios import obtener_servicios
from ..core.trabajadores import obtener_trabajadores
from ..core import datos, perfiles
from .win_form import open_win_form
from .ui import cerrar_vista, crear_ventana, encabezado, tarjeta, etiqueta, aviso_error, notificar_cambio, GRIS, VERDE, TEXTO


def open_win_list(parent, categoria=None):
    win = crear_ventana(parent, "Buscar servicio", 1100, 740)
    if isinstance(win,tk.Toplevel):win.minsize(980, 640)
    frame = ttk.Frame(win, padding=22)
    frame.pack(fill="both", expand=True)
    encabezado(frame, "Buscar servicio", "1. Elige un oficio    2. Toca un trabajador    3. Solicita el servicio")
    filtros = ttk.Frame(frame)
    filtros.pack(fill="x", pady=(0, 10))
    ttk.Label(filtros, text="Oficio").grid(row=0, column=0, sticky="w", pady=(0, 5))
    filtro = ttk.Combobox(filtros, state="readonly", width=22)
    filtro.grid(row=1, column=0, sticky="ew", padx=(0, 12))
    ttk.Label(filtros, text="Nombre, oficio o zona").grid(row=0, column=1, sticky="w", pady=(0, 5))
    busqueda = tk.StringVar()
    entrada = ttk.Entry(filtros, textvariable=busqueda)
    entrada.grid(row=1, column=1, sticky="ew", padx=(0, 12))
    filtros.columnconfigure(1, weight=1)
    solo_disponibles = tk.BooleanVar(value=False)
    ttk.Checkbutton(filtros, text="Solo disponibles", variable=solo_disponibles,
                    command=lambda: cargar_lista()).grid(row=1, column=2, sticky="w")
    opciones = ttk.Frame(frame)
    def mas_filtros():
        if opciones.winfo_manager():
            opciones.pack_forget()
            mas_btn.configure(text="Más filtros")
        else:
            opciones.pack(fill="x",pady=(0,14),before=cuerpo)
            mas_btn.configure(text="Menos filtros")
    mas_btn=ttk.Button(filtros,text="Más filtros",command=mas_filtros)
    mas_btn.grid(row=0,column=2,sticky="e",pady=(0,5))
    favoritos = tk.BooleanVar(value=False)
    ttk.Checkbutton(opciones, text="Mis favoritos", variable=favoritos,
                    command=lambda: cargar_lista()).pack(side="left")
    ttk.Label(opciones, text="Ordenar por", style="Small.TLabel").pack(side="left", padx=(20, 8))
    orden = ttk.Combobox(opciones, state="readonly", values=["Nombre", "Disponibilidad", "Opiniones locales"], width=18)
    orden.current(0)
    orden.pack(side="left")
    ttk.Button(opciones, text="Restablecer filtros", command=lambda: restablecer()).pack(side="right")

    botones = ttk.Frame(frame)
    botones.pack(side="bottom", fill="x")
    cantidad = ttk.Label(frame, text="", style="Small.TLabel")
    cantidad.pack(side="bottom", anchor="w", pady=12)
    cuerpo = ttk.Frame(frame)
    cuerpo.pack(fill="both", expand=True)
    listado = ttk.Frame(cuerpo)
    listado.pack(side="left", fill="both", expand=True, padx=(0, 16))
    tabla = ttk.Treeview(listado, columns=("nombre", "oficio", "zona", "disponibilidad", "valoracion"),
                         show="headings", selectmode="browse", height=8)
    for columna, titulo, ancho in zip(("nombre", "oficio", "zona", "disponibilidad", "valoracion"),
        ("Trabajador", "Oficio", "Zona", "Disponible", "Estrellas"), (145, 110, 115, 105, 105)):
        tabla.heading(columna, text=titulo)
        tabla.column(columna, width=ancho, minwidth=80)
    tabla.tag_configure("no_disponible", foreground="#8B6570")
    barra = ttk.Scrollbar(listado, orient="vertical", command=tabla.yview)
    tabla.configure(yscrollcommand=barra.set)
    tabla.pack(side="left", fill="both", expand=True)
    barra.pack(side="right", fill="y")
    perfil = tarjeta(cuerpo, padx=16, pady=16, width=270)
    perfil.pack(side="right", fill="y")
    perfil.pack_propagate(False)
    nombre = etiqueta(perfil, "Elige un trabajador", grande=True)
    nombre.configure(wraplength=230)
    nombre.pack(anchor="w")
    disponibilidad = etiqueta(perfil, "", color=VERDE)
    disponibilidad.pack(anchor="w", pady=(8, 10))
    valoracion=etiqueta(perfil,"",color="#9A6700")
    valoracion.configure(wraplength=230)
    valoracion.pack(anchor="w",pady=(0,10))
    nota = etiqueta(perfil, "Perfil ficticio. Identidad sin verificar.", color=GRIS)
    nota.configure(wraplength=230, font=("Segoe UI", 9))
    nota.pack(side="bottom", anchor="w", pady=(10, 0))
    favorito_btn = ttk.Button(perfil, text="Guardar favorito", command=lambda: cambiar_favorito())
    favorito_btn.pack(side="bottom", fill="x")
    perfil_btn=ttk.Button(perfil,text="Ver perfil y opiniones",command=lambda:ver_perfil())
    perfil_btn.pack(side="bottom",fill="x",pady=(0,8))
    detalle = ScrolledText(perfil, height=5, wrap="word", relief="flat", bg="white", fg=TEXTO,
                       font=("Segoe UI", 10), cursor="arrow", borderwidth=0)
    detalle.pack(fill="both", expand=True, pady=(0, 10))

    servicios = obtener_servicios()
    por_nombre = {s["nombre"]: s for s in servicios}
    filtro.configure(values=["Todos los oficios"] + list(por_nombre))
    filtro.current(0)
    registros = {}
    calificaciones={}

    def obtener_seleccion():
        seleccion = tabla.selection()
        return registros.get(seleccion[0]) if seleccion else None

    def mostrar_detalles(event=None):
        trabajador = obtener_seleccion()
        nombre.configure(text=trabajador["nombre"] if trabajador else "Elige un trabajador")
        disponibilidad.configure(text=("Disponible" if trabajador["disponible"] else "No disponible") if trabajador else "",
                                   fg=VERDE if not trabajador or trabajador["disponible"] else "#A04449")
        texto = (f"{trabajador['servicio']}\nZona: {trabajador['zona']}\n\n{trabajador['descripcion']}" if trabajador else
                 "Selecciona una fila para revisar el oficio, la zona y la descripción del trabajador.")
        detalle.configure(state="normal")
        detalle.delete("1.0", "end")
        detalle.insert("1.0", texto)
        detalle.configure(state="disabled")
        favorito_btn.configure(text="Quitar favorito" if trabajador and trabajador["favorito"] else "Guardar favorito")
        favorito_btn.state(["!disabled"] if trabajador else ["disabled"])
        perfil_btn.state(["!disabled"] if trabajador else ["disabled"])
        r=calificaciones.get(trabajador['id'],{}) if trabajador else {}
        partes=[]
        if 'local' in r:partes.append(f"{r['local']['promedio']:.1f} ★ local")
        if 'ejemplo' in r:partes.append(f"{r['ejemplo']['promedio']:.1f} ★ ejemplo")
        valoracion.configure(text=' · '.join(partes))

    def cargar_lista(event=None):
        anterior = tabla.selection()
        servicio = por_nombre.get(filtro.get())
        try:
            trabajadores = obtener_trabajadores(
                servicio["id"] if servicio else None, busqueda.get(),
                solo_disponibles=solo_disponibles.get(), solo_favoritos=favoritos.get(),
                orden="disponibilidad" if orden.get() == "Disponibilidad" else "nombre")
            calificaciones.clear()
            calificaciones.update(perfiles.resumenes())
            if orden.get()=="Opiniones locales":
                trabajadores.sort(key=lambda t:-calificaciones.get(t['id'],{}).get('local',{}).get('promedio',0))
        except (OSError, datos.sqlite3.Error) as error:
            aviso_error(win, error)
            return
        for fila in tabla.get_children():
            tabla.delete(fila)
        registros.clear()
        for trabajador in trabajadores:
            clave = f"{trabajador['id']}|{trabajador['servicio_id']}"
            registros[clave] = trabajador
            r=calificaciones.get(trabajador['id'],{})
            origen='local' if 'local' in r else 'ejemplo'
            estrellas=f"{r[origen]['promedio']:.1f} ★ {'local' if origen=='local' else 'demo'}" if origen in r else 'Sin opiniones'
            tabla.insert("", "end", iid=clave,
                         values=(trabajador["nombre"], trabajador["servicio"], trabajador["zona"],
                                 "Sí" if trabajador["disponible"] else "No", estrellas),
                         tags=() if trabajador["disponible"] else ("no_disponible",))
        if anterior and tabla.exists(anterior[0]):
            tabla.selection_set(anterior[0])
        cantidad.configure(text=f"{len(trabajadores)} resultados · Los favoritos se guardan en esta computadora." if trabajadores
                           else "Sin resultados. Cambia la búsqueda o restablece los filtros.")
        mostrar_detalles()

    def seleccionar_trabajador():
        if not obtener_seleccion():
            messagebox.showwarning("Elige un trabajador", "Primero selecciona una fila de la tabla.", parent=win.winfo_toplevel())
            return
        mostrar_detalles()
        detalle.focus_set()

    def ver_perfil():
        trabajador=obtener_seleccion()
        if trabajador:abrir_perfil(win,trabajador['id'],trabajador['servicio_id'])

    def solicitar_servicio():
        trabajador = obtener_seleccion()
        if not trabajador:
            messagebox.showwarning("Elige un trabajador", "Primero selecciona una fila de la tabla.", parent=win.winfo_toplevel())
            return
        if not trabajador["disponible"]:
            messagebox.showwarning("No disponible", "Este trabajador no está disponible. Elige otro.", parent=win.winfo_toplevel())
            return
        servicio = next(s for s in servicios if s["id"] == trabajador["servicio_id"])
        def mostrar_solicitud(identificador):
            raiz=win._root()
            if hasattr(raiz,"ver_solicitud"):
                raiz.ver_solicitud(identificador)
            else:
                from .win_table import open_win_table
                historial=open_win_table(raiz)
                historial.tabla.selection_set(identificador)
                historial.tabla.see(identificador)
        open_win_form(win, servicio=servicio.copy(), trabajador=trabajador.copy(),on_submit=mostrar_solicitud)

    def cambiar_favorito():
        trabajador = obtener_seleccion()
        if not trabajador:
            return
        try:
            datos.alternar_favorito(trabajador["id"])
        except (ValueError, OSError, datos.sqlite3.Error) as error:
            aviso_error(win, error)
            return
        cargar_lista()
        notificar_cambio(win)

    def seleccionar_categoria(valor):
        for servicio in servicios:
            if valor in (servicio["id"], servicio["nombre"], servicio["id"].removeprefix("serv-")):
                filtro.set(servicio["nombre"])
                cargar_lista()
                return
        filtro.current(0)
        cargar_lista()

    def restablecer():
        filtro.current(0)
        solo_disponibles.set(False)
        favoritos.set(False)
        orden.current(0)
        busqueda.set("")
        cargar_lista()
        opciones.pack_forget()
        mas_btn.configure(text="Más filtros")

    def buscar(texto):
        restablecer()
        busqueda.set(texto)
        entrada.focus_set()

    ttk.Button(botones, text="Seleccionar trabajador", command=seleccionar_trabajador).pack(side="left")
    ttk.Button(botones, text="Solicitar servicio", style="Primary.TButton", command=solicitar_servicio).pack(side="left", padx=8)
    ttk.Button(botones, text="Cerrar", command=lambda:cerrar_vista(win)).pack(side="right")
    filtro.bind("<<ComboboxSelected>>", cargar_lista)
    orden.bind("<<ComboboxSelected>>", cargar_lista)
    busqueda.trace_add("write", lambda *_: cargar_lista())
    tabla.bind("<<TreeviewSelect>>", mostrar_detalles)
    tabla.bind("<Double-1>", lambda evento: ver_perfil())
    win.bind("<<DatosActualizados>>", cargar_lista)
    win.seleccionar_categoria = seleccionar_categoria
    win.tabla = tabla
    win.actualizar = cargar_lista
    win.buscar = buscar
    def ver_favoritos():
        favoritos.set(True)
        cargar_lista()
    win.ver_favoritos = ver_favoritos
    seleccionar_categoria(categoria)
    return win


def abrir_perfil(parent,trabajador_id,servicio_id=None):
    from .ui import area_desplazable
    from .win_home import abrir_reporte
    perfil=perfiles.obtener_perfil(trabajador_id)
    win=crear_ventana(parent,"Perfil del trabajador",1040,780)
    frame=ttk.Frame(win,padding=22);frame.pack(fill="both",expand=True)
    encabezado(frame,perfil['nombre'],f"{', '.join(perfil['oficios'])} · {perfil['zona']} · Perfil de ejemplo")
    pie=ttk.Frame(frame);pie.pack(side='bottom',fill='x',pady=(10,0))
    def solicitar():
        trabajadores=datos.obtener_trabajadores(servicio_id)
        trabajador=next((t for t in trabajadores if t['id']==str(trabajador_id)),None)
        if not trabajador or not trabajador['disponible']:
            messagebox.showwarning('No disponible','Este trabajador no está disponible. Elige otro.',parent=win.winfo_toplevel());return
        servicio=next(s for s in datos.obtener_servicios() if s['id']==trabajador['servicio_id'])
        callback=getattr(win._root(),'ver_solicitud',None)
        open_win_form(win,servicio,trabajador,on_submit=callback)
    ttk.Button(pie,text='Solicitar servicio',style='Primary.TButton',command=solicitar).pack(side='left')
    ttk.Button(pie,text='Reportar perfil',command=lambda:abrir_reporte(win,trabajador_id=str(trabajador_id))).pack(side='left',padx=8)
    ttk.Button(pie,text='Cerrar',command=lambda:cerrar_vista(win)).pack(side='right')
    pestanas=ttk.Notebook(frame);pestanas.pack(fill='both',expand=True)
    acerca=ttk.Frame(pestanas,padding=18);opiniones=ttk.Frame(pestanas,padding=18)
    pestanas.add(acerca,text='Perfil');pestanas.add(opiniones,text='Opiniones')
    contenido,canvas=area_desplazable(acerca)
    win.scroll_canvas=canvas
    avatar=tk.Canvas(contenido,width=90,height=90,bg='#F5F7FB',highlightthickness=0)
    avatar.pack(anchor='w',pady=(0,12));avatar.create_oval(2,2,88,88,fill='#DBEAFE',outline='')
    iniciales=''.join(p[0] for p in perfil['nombre'].split()[:2])
    avatar.create_text(45,45,text=iniciales,fill='#2563EB',font=('Segoe UI',24,'bold'))
    ttk.Label(contenido,text='Disponible para recibir solicitudes' if perfil['disponible'] else 'Sin disponibilidad por ahora',style='Accent.TLabel').pack(anchor='w')
    ttk.Label(contenido,text=perfiles.texto_valoracion(perfil['valoraciones']),style='Subtitle.TLabel',wraplength=850).pack(anchor='w',pady=12)
    textos=[perfil['descripcion'],f"Experiencia declarada de ejemplo: {perfil['experiencia']} años.",
            f"Servicios finalizados en esta instalación: {perfil['trabajos_locales']} (no son compras verificadas).",
            perfil['verificacion']+'. No hay una póliza de seguro acreditada.',
            'Antes de contratar, acuerda alcance, materiales, precio y horario. Las estrellas no sustituyen permisos o formación para trabajos peligrosos.']
    for texto in textos:ttk.Label(contenido,text=texto,wraplength=850,style='Muted.TLabel').pack(anchor='w',fill='x',pady=9)
    ttk.Label(opiniones,text='Las opiniones de ejemplo y las solicitudes locales se muestran por separado.',style='Muted.TLabel',wraplength=850).pack(anchor='w',pady=(0,12))
    tabla=ttk.Treeview(opiniones,columns=('estrellas','origen','autor'),show='headings',height=4,selectmode='browse')
    for campo,titulo in [('estrellas','Calificación'),('origen','Origen'),('autor','Autor')]:tabla.heading(campo,text=titulo)
    tabla.pack(fill='both',expand=True)
    texto=ScrolledText(opiniones,height=4,wrap='word',font=('Segoe UI',10));texto.pack(fill='x',pady=12)
    resenas={r['id']:r for r in perfil['resenas']}
    for r in resenas.values():tabla.insert('','end',iid=r['id'],values=('★'*r['estrellas']+'☆'*(5-r['estrellas']), 'De ejemplo' if r['ejemplo'] else 'Solicitud local',r['alias']))
    def elegir(event=None):
        seleccion=tabla.selection();r=resenas.get(seleccion[0]) if seleccion else None
        texto.configure(state='normal');texto.delete('1.0','end');texto.insert('1.0',r['comentario'] if r else 'Este perfil todavía no tiene opiniones.');texto.configure(state='disabled')
    def reportar_opinion():
        seleccion=tabla.selection()
        if not seleccion:messagebox.showinfo('Elige una opinión','Selecciona una opinión para reportarla.',parent=win.winfo_toplevel());return
        abrir_reporte(win,trabajador_id=str(trabajador_id),resena_id=seleccion[0])
    ttk.Button(opiniones,text='Reportar opinión',command=reportar_opinion).pack(anchor='w')
    tabla.bind('<<TreeviewSelect>>',elegir)
    if resenas:tabla.selection_set(next(iter(resenas)))
    elegir()
    return win
