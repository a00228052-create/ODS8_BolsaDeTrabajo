"""Menú principal de Ofivanta y navegación entre sus cinco secciones."""
import sys
import tkinter as tk
from tkinter import ttk, messagebox
from .ui import aplicar_estilo, aplicar_tema, cargar_logo, Navegador, AZUL, FONDO
from .diseno import Boton, Texto, fuente, icono, marco, paleta
from .win_home import construir_inicio, abrir_centro_ayuda
from .win_list import open_win_list
from .win_form import open_win_form
from .win_table import open_win_table
from .win_canvas import open_win_canvas
from ..core import datos, cuentas


def main(requerir_sesion=True):
    if sys.platform == "win32":
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except (AttributeError, OSError):
            pass
    root = tk.Tk()
    root.title("Ofivanta | Bienvenido")
    ancho = min(1380, root.winfo_screenwidth() - 80)
    alto = min(900, root.winfo_screenheight() - 90)
    root.geometry(f"{ancho}x{alto}")
    root.minsize(min(1040, ancho), min(720, alto))
    root._base_invitado = datos.DB_path
    root._modo_oscuro = False
    root._avisos = True
    root._reducir_movimiento = False
    root.configure(bg=FONDO)
    aplicar_estilo(root)
    aplicar_tema(root, False)
    icono = cargar_logo(root, 32)
    if icono is not None:
        root.iconphoto(True, icono)
        root._icono = icono
    if requerir_sesion:
        _mostrar_acceso(root)
    else:
        _construir_aplicacion(root)
    root.mainloop()
    return root


def _mostrar_acceso(root):
    """Termina la sesión de esta ventana y vuelve al acceso sin exponer otra base."""
    from .sesion import Acceso
    servidor = getattr(root, "_ubicaciones", None)
    if servidor is not None:
        servidor.cerrar()
        del root._ubicaciones
    for evento in ("<<DatosActualizados>>", "<MouseWheel>", "<Control-k>"):
        root.unbind(evento)
    root.configure(menu="")
    for hijo in root.winfo_children():
        hijo.destroy()
    for atributo in ("navegador", "inicio", "_solicitud_rapida", "botones_menu", "scroll_inicio",
                     "actualizar_usuario", "establecer_tema", "actualizar_badge", "ver_solicitud", "cerrar_sesion"):
        if hasattr(root, atributo):
            delattr(root, atributo)
    root.usuario = None
    datos.DB_path = root._base_invitado
    root.title("Ofivanta | Bienvenido")
    root.acceso = Acceso(root, lambda usuario: _construir_aplicacion(root, usuario))
    aplicar_tema(root, root._modo_oscuro)


def _construir_aplicacion(root, usuario=None):
    for hijo in root.winfo_children():
        hijo.destroy()
    if hasattr(root,"acceso"):
        del root.acceso
    root.usuario = usuario
    ajustes = usuario["ajustes"] if usuario else cuentas.AJUSTES
    root._avisos = ajustes["avisos"]
    root._reducir_movimiento = ajustes["reducir_movimiento"]
    datos.DB_path = cuentas.ruta_servicios(usuario["id"]) if usuario else root._base_invitado
    aplicar_tema(root, ajustes["oscuro"])
    root.title("Ofivanta | Tu hogar, en buenas manos")
    try:
        datos.inicializar_base()
    except (OSError, datos.sqlite3.Error):
        messagebox.showerror("No se pudo iniciar Ofivanta", "No pudimos abrir tus datos. Inténtalo de nuevo.", parent=root)
        _mostrar_acceso(root)
        return

    lateral = marco(root, "nav", width=225, padx=14, pady=18)
    lateral.pack(side="left", fill="y")
    lateral.pack_propagate(False)
    cuerpo = ttk.Frame(root)
    cuerpo.pack(side="left", fill="both", expand=True)
    cabecera = ttk.Frame(cuerpo, padding=(22, 12))
    cabecera.pack(fill="x")
    volver_btn = ttk.Button(cabecera, text="Volver", command=lambda: root.navegador.volver())
    volver_btn.pack(side="left", padx=(0, 16))
    ubicacion = ttk.Label(cabecera, text="Inicio", style="Accent.TLabel")
    ubicacion.pack(side="left")
    contenedor = ttk.Frame(cuerpo)
    contenedor.pack(fill="both", expand=True)
    botones_menu = {}
    ventanas = {}
    root._vista_inicio = "cliente"

    def actualizar_navegacion(titulo):
        nombre = titulo
        if titulo == "Inicio" and root._vista_inicio == "negocio":
            nombre = "Planes e ingresos"
        ubicacion.configure(text=nombre)
        volver_btn.state(["!disabled"] if len(root.navegador.historial) > 1 else ["disabled"])
        grupo = {"Solicitar servicio": "Buscar servicio", "Perfil del trabajador":"Buscar servicio",
                 "Detalle de solicitud": "Mis solicitudes", "Valorar servicio":"Mis solicitudes",
                 "Registrar un problema":"Ayuda y seguridad", "Cotización de ejemplo": "Seguimiento"}.get(nombre, nombre)
        for texto, boton in botones_menu.items():
            boton.configure(style="Selected.Sidebar.TButton" if texto == grupo else "Sidebar.TButton")
            root._adaptar_boton(boton)

    root.navegador = Navegador(contenedor, actualizar_navegacion)

    def abrir(nombre, funcion, *args):
        anterior = ventanas.get(nombre)
        if anterior is not None and anterior.winfo_exists():
            if args and args[0] is not None and hasattr(anterior, "seleccionar_categoria"):
                anterior.seleccionar_categoria(args[0])
            elif hasattr(anterior, "actualizar"):
                anterior.actualizar()
            root.navegador.mostrar(anterior)
            return anterior
        vista = funcion(root, *args)
        if hasattr(vista, "ventana"):
            vista = vista.ventana
        ventanas[nombre] = vista
        return vista

    def catalogo(categoria=None):
        return abrir("catalogo", open_win_list, categoria)

    def solicitudes():
        return abrir("solicitudes", open_win_table)

    def seguimiento():
        vista=abrir("seguimiento", open_win_canvas)
        vista.ver_avance()
        return vista

    def mapa_en_vivo():
        vista=seguimiento()
        vista.ver_mapa()
        return vista

    def inicio(vista="cliente"):
        root._vista_inicio = vista
        home.mostrar_vista(vista)
        root.navegador.mostrar(pagina_inicio)
        scroll.yview_moveto(0)

    def ver_solicitud(identificador):
        historial = solicitudes()
        historial.actualizar()
        historial.tabla.selection_set(identificador)
        historial.tabla.see(identificador)

    root.ver_solicitud = ver_solicitud
    def cerrar_sesion():
        formulario = root.navegador.paginas.get("Solicitar servicio")
        if formulario is not None and hasattr(formulario, "formulario"):
            form = formulario.formulario
            borrador = any(v.get().strip() for v in (form.nombre, form.contacto, form.domicilio)) or form.descripcion.get("1.0", "end").strip()
            if borrador and not messagebox.askyesno("Cerrar sesión", "Hay una solicitud sin enviar. ¿Salir y descartar ese borrador?", parent=root):
                return
        _mostrar_acceso(root)
    root.cerrar_sesion = cerrar_sesion
    marca = marco(lateral, "nav")
    marca.pack(fill="x", pady=(0, 16))
    logo = cargar_logo(root, 42)
    if logo is not None:
        imagen = tk.Canvas(marca, width=46, height=46, bg=paleta(root)["nav"], highlightthickness=0)
        imagen.create_oval(0, 0, 45, 45, fill="white", outline="")
        imagen.create_image(23, 23, image=logo)
        imagen.image = logo
        imagen.pack(side="left", padx=(0, 7))
    Texto(marca, "Ofivanta", 18, "#FFFFFF", negrita=True).pack(side="left")
    from .sesion import abrir_perfil_usuario, abrir_ajustes
    imagenes_menu = {"Inicio":"house", "Buscar servicio":"search", "Mis solicitudes":"clipboard-list",
                     "Seguimiento":"route", "Mapa en vivo":"map-pin", "Planes e ingresos":"wallet",
                     "Ayuda y seguridad":"shield", "Mi perfil":"user-round", "Ajustes":"sun"}
    for texto, accion in [("Inicio", inicio), ("Buscar servicio", catalogo), ("Mis solicitudes", solicitudes),
                           ("Seguimiento", seguimiento), ("Mapa en vivo",mapa_en_vivo),
                           ("Planes e ingresos", lambda: inicio("negocio")),
                           ("Ayuda y seguridad",lambda:abrir("ayuda",abrir_centro_ayuda)),
                           ("Mi perfil",lambda:abrir("perfil",abrir_perfil_usuario)),
                           ("Ajustes",lambda:abrir("ajustes",abrir_ajustes))]:
        boton = ttk.Button(lateral, text=texto, command=accion, image=icono(root,imagenes_menu[texto],24),
                           compound="left", style="Sidebar.TButton", cursor="hand2")
        boton.pack(fill="x", pady=3)
        botones_menu[texto] = boton
    perfil_pie = marco(lateral,"nav")
    perfil_pie.pack(side="bottom",fill="x",pady=(8,0))
    identidad = marco(perfil_pie,"nav")
    identidad.pack(fill="x")
    avatar = tk.Canvas(identidad,width=36,height=36,bg=paleta(root)['nav'],highlightthickness=0)
    avatar.pack(side="left",padx=(0,8))
    avatar.create_oval(1,1,35,35,fill='#2563EB',outline='')
    iniciales = avatar.create_text(18,18,text='TU',fill='white',font=fuente(root,10,True))
    datos_perfil = marco(identidad,"nav")
    datos_perfil.pack(side="left",fill="x",expand=True)
    nombre_usuario = Texto(datos_perfil,"",10,"#FFFFFF",negrita=True,wraplength=145)
    nombre_usuario.pack(anchor="w",pady=(0,4))
    Texto(datos_perfil,"Cuenta local" if usuario else "Modo invitado",9,"#B8CAE9").pack(anchor="w")
    ttk.Button(perfil_pie,text="Cerrar sesión" if usuario else "Entrar",command=cerrar_sesion,
               style="Sidebar.TButton").pack(fill="x",pady=(8,0))
    tema_btn = Boton(cabecera,"Oscuro",lambda:root.establecer_tema(not root._modo_oscuro),principal=True)
    tema_btn.pack(side="right",padx=(8,0))
    notificaciones = Boton(cabecera,"Avisos",solicitudes,principal=True,icon="bell")
    notificaciones.pack(side="right",padx=(8,0))
    Boton(cabecera,"Mi perfil",lambda:abrir("perfil",abrir_perfil_usuario)).pack(side="right")
    badge = tk.Label(lateral,text="",bg="#2563EB",fg="white",font=fuente(root,8,True),padx=5,pady=2)
    badge.bind("<Button-1>",lambda evento:seguimiento())
    root._numero_badge = 0
    def actualizar_badge(cantidad):
        root._numero_badge = cantidad
        mostrar = cantidad>0 and root._avisos
        if mostrar:
            badge.configure(text=str(cantidad) if cantidad<100 else "99+")
            badge.place(in_=botones_menu["Seguimiento"],relx=1,rely=.5,x=-10,anchor="e")
        else:
            badge.place_forget()
        notificaciones.configure(text=f"Avisos · {cantidad}" if mostrar else "Avisos")
    root.actualizar_badge = actualizar_badge

    pagina_inicio = root.navegador.crear("Inicio")
    scroll = tk.Canvas(pagina_inicio, bg=paleta(root)["bg"], highlightthickness=0)
    scroll._color_fondo = "bg"
    barra = ttk.Scrollbar(pagina_inicio, orient="vertical", command=scroll.yview)
    scroll.configure(yscrollcommand=barra.set)
    barra.pack(side="right", fill="y")
    scroll.pack(side="left", fill="both", expand=True)
    pagina_inicio.scroll_canvas = scroll
    home = construir_inicio(scroll, catalogo, solicitudes, seguimiento, mostrar_pestanas=False)
    contenido = scroll.create_window((0, 0), window=home, anchor="nw")
    home.bind("<Configure>", lambda evento: scroll.configure(scrollregion=scroll.bbox("all")))
    scroll.bind("<Configure>", lambda evento: scroll.itemconfigure(contenido, width=evento.width))

    def desplazar(evento):
        if isinstance(evento.widget, (tk.Text, ttk.Treeview, ttk.Entry, ttk.Combobox, ttk.Spinbox)):
            return
        actual = root.navegador.actual
        canvas = getattr(actual, "scroll_canvas", None)
        if canvas is not None and canvas.winfo_exists() and evento.delta:
            canvas.yview_scroll(-1 if evento.delta > 0 else 1, "units")

    root.bind("<MouseWheel>", desplazar)
    root.bind("<<DatosActualizados>>", home.actualizar)
    root.inicio = home
    root.scroll_inicio = scroll
    root.botones_menu = botones_menu
    direccion_sugerida = [usuario["domicilio"] if usuario else ""]
    def actualizar_usuario():
        nombre_usuario.configure(text=root.usuario["nombre"] if root.usuario else "Invitado")
        avatar.itemconfigure(iniciales,text=''.join(p[0] for p in root.usuario['nombre'].split()[:2]) if root.usuario else 'TU')
        if root.usuario:
            if home.cliente.direccion.get() in ("",direccion_sugerida[0]):
                home.cliente.direccion.set(root.usuario["domicilio"])
            direccion_sugerida[0] = root.usuario["domicilio"]
        home.actualizar()
        actualizar_badge(root._numero_badge)
    def establecer_tema(oscuro,persistir=True):
        if persistir and root.usuario:
            try:
                root.usuario = cuentas.guardar_ajustes(root.usuario["id"],{"oscuro":bool(oscuro)})
            except (ValueError,OSError,cuentas.sqlite3.Error):
                messagebox.showinfo("No se guardó el tema","Se aplicará a esta sesión. Inténtalo de nuevo para guardarlo.",parent=root)
        aplicar_tema(root,oscuro)
        tema_btn.configure(text="Claro" if oscuro else "Oscuro")
    root.actualizar_usuario = actualizar_usuario
    root.establecer_tema = establecer_tema
    if usuario and usuario["domicilio"]:
        home.cliente.direccion.set(usuario["domicilio"])
    root.bind("<Control-k>",lambda evento:(inicio(),home.cliente.selector.focus_set()))
    menu = tk.Menu(root)
    ventanas_menu = tk.Menu(menu, tearoff=False)
    for texto, accion in [("Inicio", inicio), ("Solicitar servicio", lambda: abrir("formulario", open_win_form)),
                           ("Buscar servicio", catalogo), ("Mis solicitudes", solicitudes), ("Seguimiento", seguimiento)]:
        ventanas_menu.add_command(label=texto, command=accion)
    menu.add_cascade(label="Ir a", menu=ventanas_menu)
    ayuda = tk.Menu(menu, tearoff=False)
    ayuda.add_command(label="Cómo usar Ofivanta", command=lambda: messagebox.showinfo("Cómo usar Ofivanta",
        "1. Busca un oficio y elige un trabajador.\n2. Describe el trabajo y envía la solicitud.\n"
        "3. Revisa la cotización en Mis solicitudes.\n4. Consulta el avance en Seguimiento.\n\n"
        "Usa Volver para regresar o el menú lateral para cambiar de sección.\n"
        "Es una demostración local, sin cobros reales.", parent=root))
    menu.add_cascade(label="Ayuda", menu=ayuda)
    root.configure(menu=menu)
    root.menu_ventanas = ventanas_menu
    actualizar_usuario()
    establecer_tema(root._modo_oscuro,persistir=False)
    actualizar_navegacion("Inicio")
    return root


if __name__ == "__main__":
    main()
