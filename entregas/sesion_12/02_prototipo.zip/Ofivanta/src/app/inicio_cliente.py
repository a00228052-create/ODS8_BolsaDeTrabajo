"""Inicio para pedir un oficio, elegir un profesional y retomar un servicio."""
from datetime import date, timedelta
import tkinter as tk
from tkinter import ttk, messagebox

from ..core import datos, perfiles
from .diseno import Boton, Icono, Pasos, Rejilla, Superficie, Texto, fuente, marco, paleta
from .ui import aviso_error, notificar_cambio

# Precios exclusivamente ilustrativos: no se usan para crear cotizaciones.
OFICIOS = {
    "serv-plomeria": ("droplets", "#2563EB", 200, "Fugas y tuberías"),
    "serv-electricidad": ("zap", "#B86D08", 250, "Luz e instalaciones"),
    "serv-limpieza": ("sparkles", "#087F72", 180, "Un espacio más limpio"),
    "serv-reparaciones": ("wrench", "#5465C9", 200, "Arreglos del día a día"),
    "serv-pintura": ("paint-roller", "#A53A82", 300, "Dale vida a tu casa"),
    "serv-carpinteria": ("hammer", "#A65C29", 250, "Muebles y madera"),
    "serv-jardineria": ("leaf", "#25834C", 200, "Cuida tu jardín"),
    "serv-cerrajeria": ("key-round", "#6356C9", 250, "Puertas y cerraduras"),
    "serv-aire-acondicionado": ("sparkles", "#087F92", 350, "Climatización del hogar"),
    "serv-electrodomesticos": ("wrench", "#5369B5", 300, "Revisión y mantenimiento"),
    "serv-albanileria": ("hammer", "#A65C29", 400, "Reparaciones de obra"),
    "serv-impermeabilizacion": ("shield", "#2563EB", 450, "Cuida techos y muros"),
    "serv-mudanzas": ("route", "#6955C7", 500, "Traslados y maniobras"),
    "serv-fumigacion": ("leaf", "#25834C", 350, "Control de plagas"),
    "serv-herreria": ("hammer", "#59677E", 300, "Puertas y estructuras"),
    "serv-vidrieria": ("house", "#087F92", 300, "Cristales y ventanas"),
    "serv-tapiceria": ("sparkles", "#A53A82", 350, "Dale vida a tus muebles"),
    "serv-internet": ("route", "#6955C7", 250, "Conexión y redes"),
    "serv-paneles-solares": ("sun", "#B86D08", 500, "Revisión especializada"),
    "serv-piscinas": ("droplets", "#087F92", 350, "Limpieza y cuidado"),
}


class InicioCliente(tk.Frame):
    def __init__(self, parent, abrir_catalogo, abrir_solicitudes, abrir_seguimiento):
        super().__init__(parent, bg=paleta(parent)["bg"])
        self._color_fondo = "bg"
        self.catalogo, self.solicitudes, self.seguimiento = abrir_catalogo, abrir_solicitudes, abrir_seguimiento
        self.servicios = datos.obtener_servicios()
        self.por_nombre = {s["nombre"]: s for s in self.servicios}
        self.oficio = tk.StringVar(value="Elige un oficio")
        self.direccion = tk.StringVar()
        self.modalidad = tk.StringVar(value="Ahora")
        self.fecha = tk.StringVar(value=(date.today()+timedelta(days=1)).isoformat())
        self.horario = tk.StringVar(value="Por acordar")
        self.tarjetas_profesionales = []
        self.detalles_profesionales = {}
        self._estado_activo = None

        saludo = marco(self)
        saludo.pack(fill="x", pady=(0, 16))
        self.saludo = Texto(saludo, "Tu casa, en buenas manos.", 19, negrita=True)
        self.saludo.pack(side="left")
        Texto(saludo, "CATÁLOGO DE EJEMPLO", 8, "muted", negrita=True).pack(side="right", pady=8)

        principal = Rejilla(self, minimo=400, maximo=2)
        principal.pack(fill="x")
        solicitud = Superficie(principal, padding=20)
        principal.agregar(solicitud)
        self._solicitud_rapida(solicitud.cuerpo)
        self.activa = Superficie(principal, padding=20)
        principal.agregar(self.activa)

        titulo_categorias = self._titulo("Encuentra lo que necesitas", "Servicios para cada rincón de tu hogar")
        self.boton_oficios = Boton(titulo_categorias, "Más oficios", self.alternar_oficios)
        self.boton_oficios.pack(side='right')
        categorias = Rejilla(self, minimo=190, maximo=4)
        categorias.limite = 8
        categorias.pack(fill="x")
        self.categorias = categorias
        ordenados = sorted(self.servicios, key=lambda s: (s['id'] not in list(OFICIOS)[:8], list(OFICIOS).index(s['id']) if s['id'] in OFICIOS else 99))
        self._categorias_pendientes = ordenados[8:]
        for servicio in ordenados[:8]:
            self._agregar_categoria(servicio)

        encabezado = self._titulo("Profesionales para tu hogar", "Perfiles de ejemplo en México. La llegada se acuerda al cotizar.")
        Boton(encabezado, "Ver todos", self.catalogo).pack(side="right")
        self.profesionales = Rejilla(self, minimo=270, maximo=3)
        self.profesionales.pack(fill="x")

        self._titulo("Todo en orden", "Tu actividad en esta computadora")
        self.metricas = Rejilla(self, minimo=190, maximo=4)
        self.metricas.pack(fill="x")
        self.contadores = []
        for icon, titulo, contexto, color, accion in [
            ("user-round", "Disponibles", "En el catálogo de ejemplo", "#2563EB", self.catalogo),
            ("clipboard-list", "Solicitudes abiertas", "Consulta el siguiente paso", "#6955C7", self.solicitudes),
            ("check", "Trabajos finalizados", "Puedes dejar tu opinión", "#087F72", self.solicitudes),
            ("heart", "Favoritos", "Vuelve a tus profesionales", "#A53A82", self.ver_favoritos),
        ]:
            card = Superficie(self.metricas, padding=14)
            body = card.cuerpo
            Icono(body, icon, color, 32).pack(anchor="w")
            contador = Texto(body, "0", 24, negrita=True)
            contador.pack(anchor="w", pady=(8, 0))
            Texto(body, titulo, 9, negrita=True).pack(anchor="w")
            Texto(body, contexto, 8, "muted", wraplength=165).pack(anchor="w", pady=(4, 8))
            Boton(body, "Explorar" if titulo == "Disponibles" else "Ver", accion).pack(fill="x")
            self.contadores.append(contador)
            self.metricas.agregar(card)

        confianza = Superficie(self, padding=16)
        confianza.pack(fill="x", pady=(8, 0))
        fila = Rejilla(confianza.cuerpo, minimo=195, maximo=4)
        fila.pack(fill="x")
        for icon, titulo, descripcion in [
            ("user-round", "Perfiles claros", "Revisa experiencia y opiniones"),
            ("wallet", "Cotización primero", "Conoce el alcance y el precio"),
            ("shield", "Condiciones visibles", "Acuerda materiales y garantías"),
            ("headphones", "Ayuda en la app", "Guarda y consulta un problema"),
        ]:
            item = marco(fila, "surface")
            Icono(item, icon, "#0F1F4D", 32).pack(side="left", padx=(0, 8))
            texto = marco(item, "surface")
            texto.pack(side="left", fill="x", expand=True)
            Texto(texto, titulo, 9, negrita=True).pack(anchor="w")
            Texto(texto, descripcion, 8, "muted", wraplength=150).pack(anchor="w")
            fila.agregar(item)
        Texto(self, "Demostración local. Perfiles y precios ilustrativos; sin verificación de identidad, garantía general ni soporte 24/7.",
              8, "muted", wraplength=940).pack(anchor="w", pady=(12, 4))
        self.actualizar()

    def _agregar_categoria(self, servicio):
        nombre_icono, color, precio, subtitulo = OFICIOS.get(servicio["id"], ("wrench", "#2563EB", 200, "Ayuda para tu hogar"))
        card = Superficie(self.categorias, padding=14, interactiva=True)
        body = card.cuerpo
        Icono(body, nombre_icono, color, 40).pack(anchor="w", pady=(0,8))
        Boton(body, servicio["nombre"], lambda s=servicio: self.ir_categoria(s["id"])).pack(fill="x")
        Texto(body, subtitulo, 9, "muted", wraplength=180).pack(anchor="w", pady=(8, 2))
        Texto(body, f"Desde ${precio} · ejemplo", 8, "accent").pack(anchor="w")
        self.categorias.agregar(card)

    def alternar_oficios(self):
        for servicio in self._categorias_pendientes:
            self._agregar_categoria(servicio)
        self._categorias_pendientes = []
        self.categorias.limite = None if self.categorias.limite else 8
        self.boton_oficios.configure(text='Ver menos' if self.categorias.limite is None else 'Más oficios')
        self.categorias.columnas = 0
        self.categorias.reacomodar()

    def _titulo(self, titulo, subtitulo):
        fila = marco(self)
        fila.pack(fill="x", pady=(12, 12))
        textos = marco(fila)
        textos.pack(side="left", fill="x", expand=True)
        Texto(textos, titulo, 16, negrita=True).pack(anchor="w")
        Texto(textos, subtitulo, 9, "muted", wraplength=640).pack(anchor="w", pady=(4, 0))
        return fila

    def _solicitud_rapida(self, body):
        Texto(body, "¿Qué necesitas hoy?", 24, negrita=True).pack(anchor="w")
        Texto(body, "El cuidado de tu casa, en un solo lugar.", 10, "muted").pack(anchor="w", pady=(4, 16))
        campos = marco(body, "surface")
        campos.pack(fill="x")
        campos.columnconfigure(0, weight=1)
        campos.columnconfigure(1, weight=1)
        Texto(campos, "Servicio para tu hogar", 9, negrita=True).grid(row=0, column=0, sticky="w")
        self.selector = ttk.Combobox(campos, textvariable=self.oficio, values=list(self.por_nombre), state="readonly", width=1)
        self.selector.grid(row=1, column=0, sticky="ew", padx=(0,12), pady=(5, 12))
        etiqueta = marco(campos, "surface")
        etiqueta.grid(row=0, column=1, sticky="ew")
        Texto(etiqueta, "Dirección del servicio", 9, negrita=True).pack(side="left")
        self.entrada_direccion = ttk.Entry(campos, textvariable=self.direccion, width=1)
        self.entrada_direccion.grid(row=1, column=1, sticky="ew", pady=(5, 12))
        self.entrada_direccion.bind("<Return>", lambda e: self.solicitar_rapido())
        opciones = marco(body, "surface")
        opciones.pack(fill="x", pady=(0, 8))
        ttk.Radiobutton(opciones, text="Ahora", variable=self.modalidad, value="Ahora", command=self._programar).pack(side="left", padx=(0, 18))
        ttk.Radiobutton(opciones, text="Programar", variable=self.modalidad, value="Programar", command=self._programar).pack(side="left")
        self.programacion = marco(body, "surface")
        Texto(self.programacion, "Fecha (AAAA-MM-DD)", 8, "muted").pack(anchor="w")
        fila = marco(self.programacion, "surface")
        fila.pack(fill="x", pady=(4, 8))
        ttk.Entry(fila, textvariable=self.fecha, width=12).pack(side="left", padx=(0, 8))
        ttk.Combobox(fila, textvariable=self.horario, values=datos.HORARIOS, state="readonly", width=19).pack(side="left", fill="x", expand=True)
        self.boton_solicitar = Boton(body, "Solicitar servicio", self.solicitar_rapido, principal=True, icon="arrow-right")
        self.boton_solicitar.pack(fill="x", pady=(4, 10))
        Pasos(body, ("Elige oficio", "Conoce a tu profesional", "Revisa la cotización")).pack(fill="x")

    def _programar(self):
        if self.modalidad.get() == "Programar":
            self.programacion.pack(fill="x", before=self.boton_solicitar)
        else:
            self.programacion.pack_forget()

    def solicitar_rapido(self):
        servicio = self.por_nombre.get(self.oficio.get())
        if not servicio:
            messagebox.showinfo("Elige un oficio", "Selecciona el servicio que necesitas.", parent=self.winfo_toplevel())
            self.selector.focus_set()
            return
        if not 5 <= len(self.direccion.get().strip()) <= 300:
            messagebox.showinfo("Agrega una dirección", "Escribe dónde necesitas el servicio (de 5 a 300 caracteres).", parent=self.winfo_toplevel())
            self.entrada_direccion.focus_set()
            return
        try:
            fecha = date.fromisoformat(self.fecha.get()) if self.modalidad.get() == "Programar" else date.today()
            if fecha < date.today():
                raise ValueError("Elige una fecha de hoy en adelante.")
        except ValueError:
            messagebox.showinfo("Revisa la fecha", "Usa una fecha válida de hoy en adelante, con formato AAAA-MM-DD.", parent=self.winfo_toplevel())
            return
        self._root()._solicitud_rapida = {
            "servicio_id": servicio["id"], "domicilio": self.direccion.get().strip(),
            "fecha": fecha.isoformat(), "horario": self.horario.get() if self.modalidad.get() == "Programar" else "Por acordar",
            "urgencia": "Normal" if self.modalidad.get() == "Programar" else "Lo antes posible",
        }
        self.catalogo(servicio["id"])

    def ir_categoria(self, identificador):
        self._root()._solicitud_rapida = None
        return self.catalogo(identificador)

    def ver_favoritos(self):
        vista = self.catalogo()
        if hasattr(vista, "ver_favoritos"):
            vista.ver_favoritos()

    def _profesional(self, trabajador, valoracion, terminados):
        card = Superficie(self.profesionales, padding=18, interactiva=True)
        body = card.cuerpo
        fila = marco(body, "surface")
        fila.pack(fill="x")
        avatar = tk.Canvas(fila, width=48, height=48, bg=paleta(self)["surface"], highlightthickness=0)
        avatar.pack(side="left")
        color = OFICIOS.get(trabajador["servicio_id"], (None, "#2563EB"))[1]
        avatar.create_oval(1, 1, 47, 47, fill=color, outline="")
        avatar.create_text(24, 24, text="".join(p[0] for p in trabajador["nombre"].split()[:2]), fill="white", font=fuente(self, 14, True))
        favorito = Boton(fila, "♥" if trabajador["favorito"] else "♡", lambda: self._favorito(trabajador["id"]), width=3)
        favorito.pack(side="right")
        Texto(body, trabajador["nombre"], 13, negrita=True).pack(anchor="w", pady=(12, 3))
        Texto(body, trabajador["servicio"]+" · "+trabajador["zona"], 9, "muted", wraplength=255).pack(anchor="w")
        clave = "local" if "local" in valoracion else "ejemplo"
        resumen = valoracion.get(clave)
        puntuacion = Texto(body, self.texto_puntuacion(valoracion), 9, "accent", negrita=True)
        puntuacion.pack(anchor="w", pady=(10, 5))
        completados = Texto(body, f"{terminados} trabajos finalizados en esta app", 8, "muted")
        completados.pack(anchor="w")
        Texto(body, "Horario de llegada por acordar", 8, "muted").pack(anchor="w", pady=(4, 8))
        Texto(body, "PERFIL DE EJEMPLO · SIN VERIFICAR", 7, "muted", negrita=True).pack(anchor="w")
        acciones = marco(body, "surface")
        acciones.pack(fill="x", pady=(12, 0))
        Boton(acciones, "Ver perfil", lambda t=trabajador: self.ver_perfil(t)).pack(side="left")
        Boton(acciones, "Contratar", lambda t=trabajador: self.contratar(t), principal=True).pack(side="right")
        self.profesionales.agregar(card)
        self.tarjetas_profesionales.append((trabajador["id"], favorito))
        self.detalles_profesionales[trabajador['id']] = (puntuacion, completados)

    @staticmethod
    def texto_puntuacion(valoracion):
        clave = 'local' if 'local' in valoracion else 'ejemplo'
        resumen = valoracion.get(clave)
        return f"★ {resumen['promedio']:.1f} · {'opiniones locales' if clave == 'local' else 'opiniones de ejemplo'}" if resumen else 'Sin opiniones'

    def _favorito(self, identificador):
        try:
            datos.alternar_favorito(identificador)
        except (ValueError, OSError, datos.sqlite3.Error) as error:
            aviso_error(self, error)
            return
        notificar_cambio(self)

    def ver_perfil(self, trabajador):
        from .win_list import abrir_perfil
        return abrir_perfil(self, trabajador["id"], trabajador["servicio_id"])

    def contratar(self, trabajador):
        from .win_form import open_win_form
        servicio = next(s for s in self.servicios if s["id"] == trabajador["servicio_id"])
        return open_win_form(self, servicio, trabajador, on_submit=getattr(self._root(), "ver_solicitud", None))

    def _mostrar_activa(self, solicitud):
        clave = (solicitud["id"], solicitud["estado"]) if solicitud else None
        if clave == self._estado_activo and self.activa.cuerpo.winfo_children():
            return
        self._estado_activo = clave
        for hijo in self.activa.cuerpo.winfo_children():
            hijo.destroy()
        body = self.activa.cuerpo
        Icono(body, "route" if solicitud else "house", "#0F1F4D", 56).pack(anchor="w")
        Texto(body, "Tu servicio, paso a paso" if solicitud else "Tu siguiente arreglo empieza aquí", 17, negrita=True, wraplength=370).pack(anchor="w", pady=(12, 6))
        if not solicitud:
            Texto(body, "Todavía no hay solicitudes activas. Elige un oficio, revisa un perfil y pide una cotización.", 10, "muted", wraplength=370).pack(anchor="w", pady=(0, 12))
            Boton(body, "Encuentra un profesional", self.catalogo, principal=True).pack(fill="x")
            Texto(body, "Tú decides antes de confirmar.", 9, "muted").pack(anchor="w", pady=(12, 0))
            return
        Texto(body, solicitud["servicio"]+" con "+solicitud["trabajador"], 10, "muted", wraplength=370).pack(anchor="w")
        Texto(body, "#"+solicitud["numero"]+" · "+solicitud["estado_texto"], 10, "accent", negrita=True).pack(anchor="w", pady=(8, 12))
        pasos = [("pendiente", "Solicitado"), ("cotizada", "Cotización"), ("cotizacion_aceptada", "Aceptado"), ("en_proceso", "En trabajo"), ("completada", "Finalizado")]
        indice = next((i for i, (k, _) in enumerate(pasos) if k == solicitud["estado"]), 0)
        Pasos(body, [texto for _, texto in pasos], actual=indice).pack(fill='x',pady=(0,12))
        Texto(body, "El desplazamiento y la llegada aún no se registran como estados.", 8, "muted", wraplength=370).pack(anchor="w", pady=(0, 8))
        Boton(body, "Ver seguimiento", lambda: self._seguir(solicitud["id"]), principal=True).pack(fill="x")
        Boton(body, "Reportar un problema", lambda: self._contacto(solicitud["id"])).pack(fill="x", pady=(8, 0))

    def _seguir(self, sid):
        from .win_canvas import open_win_canvas
        return open_win_canvas(self, sid)

    def _contacto(self, sid):
        from .win_home import abrir_reporte
        return abrir_reporte(self, solicitud_id=sid)

    def actualizar(self):
        usuario = getattr(self._root(), "usuario", None)
        self.saludo.configure(text=("Hola, "+usuario["nombre"].split()[0]+". ¿Qué resolvemos hoy?") if usuario else "Tu casa, en buenas manos.")
        solicitudes = datos.obtener_solicitudes()
        trabajadores = datos.obtener_trabajadores(orden="disponibilidad")
        favoritos = {t["id"] for t in trabajadores if t["favorito"]}
        abiertos = [s for s in solicitudes if s["estado"] not in ("completada", "cancelada")]
        valores = [sum(t["disponible"] for t in trabajadores), len(abiertos), sum(s["estado"] == "completada" for s in solicitudes), len(favoritos)]
        for label, valor in zip(self.contadores, valores):
            label.configure(text=str(valor))
        self._mostrar_activa(abiertos[0] if abiertos else None)
        seleccion = [t for t in trabajadores if t["disponible"]][:3]
        valoraciones = perfiles.resumenes()
        ids = [t["id"] for t in seleccion]
        if ids != [t[0] for t in self.tarjetas_profesionales]:
            for hijo in self.profesionales.winfo_children():
                hijo.destroy()
            self.profesionales.tarjetas.clear()
            self.profesionales.columnas = 0
            self.tarjetas_profesionales.clear()
            self.detalles_profesionales.clear()
            for t in seleccion:
                terminados = sum(s["trabajador_id"] == t["id"] and s["estado"] == "completada" for s in solicitudes)
                self._profesional(t, valoraciones.get(t["id"], {}), terminados)
        for identificador, boton in self.tarjetas_profesionales:
            boton.configure(text="♥" if identificador in favoritos else "♡")
            puntuacion, completados = self.detalles_profesionales[identificador]
            puntuacion.configure(text=self.texto_puntuacion(valoraciones.get(identificador, {})))
            cantidad = sum(s['trabajador_id']==identificador and s['estado']=='completada' for s in solicitudes)
            completados.configure(text=f'{cantidad} trabajos finalizados en esta app')
        if hasattr(self._root(), "actualizar_badge"):
            self._root().actualizar_badge(len(abiertos))
