"""Componentes nativos del Inicio: temas, tarjetas, iconos y rejillas."""
import sys
import time
import tkinter as tk
from pathlib import Path
from tkinter import font as tkfont, ttk

RECURSOS = Path(__file__).resolve().parents[2] / "assets"
CLARO = {
    "bg": "#F3F6FC", "surface": "#FFFFFF", "raised": "#EAF0FB",
    "text": "#14213D", "muted": "#566780", "border": "#DFE7F3",
    "primary": "#2563EB", "accent": "#1D4ED8", "soft": "#EAF1FF",
    "success": "#087F5B", "shadow": "#E7EDF7", "nav": "#0F1F4D",
}
OSCURO = {
    "bg": "#080F20", "surface": "#111D34", "raised": "#1B2B46",
    "text": "#F1F5FF", "muted": "#A9B8D1", "border": "#293C5B",
    "primary": "#2563EB", "accent": "#8AB4FF", "soft": "#192F54",
    "success": "#5EE3B5", "shadow": "#050A16", "nav": "#0B142B",
}


def paleta(widget):
    return OSCURO if getattr(widget._root(), "_modo_oscuro", False) else CLARO


def color_fondo(widget):
    try:
        return str(widget.cget('background'))
    except tk.TclError:
        return paleta(widget)['bg']


def preparar_fuente(root):
    if hasattr(root, "fuente_app"):
        return root.fuente_app
    ruta = RECURSOS / "fonts/Inter.ttf"
    if sys.platform == "win32" and ruta.exists():
        import ctypes
        # FR_PRIVATE: disponible solo para esta app, sin instalarla en Windows.
        ctypes.windll.gdi32.AddFontResourceExW(str(ruta), 0x10, 0)
    familias = tkfont.families(root)
    root.fuente_app = next((f for f in familias if f == "Inter"), "Segoe UI")
    return root.fuente_app


def fuente(widget, tamano=10, negrita=False):
    return (preparar_fuente(widget._root()), tamano, "bold" if negrita else "normal")


def icono(widget, nombre, tamano=24):
    root = widget._root()
    if not hasattr(root, "_iconos_app"):
        root._iconos_app = {}
    clave = (nombre, tamano)
    if clave not in root._iconos_app:
        ruta = RECURSOS / "lucide" / (nombre + ".png")
        original = tk.PhotoImage(master=root, file=str(ruta))
        root._iconos_app[clave] = original.subsample(max(1, 96 // tamano))
    return root._iconos_app[clave]


def mezclar(a, b, fraccion):
    rgb = [round(int(a[i:i+2], 16) * (1-fraccion) + int(b[i:i+2], 16) * fraccion)
           for i in (1, 3, 5)]
    return "#{:02x}{:02x}{:02x}".format(*rgb)


def redondo(canvas, x, y, ancho, alto, radio=16, **kwargs):
    radio = max(1, min(radio, ancho/2, alto/2))
    puntos = [x+radio,y, x+ancho-radio,y, x+ancho,y, x+ancho,y+radio,
              x+ancho,y+alto-radio, x+ancho,y+alto, x+ancho-radio,y+alto,
              x+radio,y+alto, x,y+alto, x,y+alto-radio, x,y+radio, x,y]
    return canvas.create_polygon(puntos, smooth=True, splinesteps=24, **kwargs)


def marco(parent, color="bg", **kwargs):
    widget = tk.Frame(parent, bg=paleta(parent)[color], **kwargs)
    widget._color_fondo = color
    return widget


class Texto(tk.Label):
    def __init__(self, parent, texto="", tamano=10, color="text", negrita=False, **kwargs):
        self.color_semantico = color
        super().__init__(parent, text=texto, font=fuente(parent, tamano, negrita),
                         anchor="w", justify="left", **kwargs)
        self.actualizar_tema()

    def actualizar_tema(self):
        self.configure(bg=color_fondo(self.master), fg=paleta(self).get(self.color_semantico, self.color_semantico))


class Superficie(tk.Frame):
    """Tarjeta con esquinas reales y sombra; los controles mantienen su teclado."""
    def __init__(self, parent, padding=16, interactiva=False, **kwargs):
        super().__init__(parent, highlightthickness=0, bd=0, **kwargs)
        self.padding = padding
        self.fondo = tk.Canvas(self, highlightthickness=0, bd=0)
        self.fondo.place(x=0, y=0, relwidth=1, relheight=1)
        self.cuerpo = marco(self, "surface")
        self.cuerpo.pack(fill='both', expand=True, padx=padding, pady=(padding,padding+6))
        self.hover = 0.0
        self._animacion = None
        self.fondo.bind("<Configure>", lambda e: self.dibujar())
        if interactiva:
            self.bind("<Enter>", lambda e: self.animar(True))
            self.bind("<Leave>", lambda e: self.animar(False))
        self.bind("<Destroy>", self._cerrar, add="+")
        self.actualizar_tema()

    def dibujar(self):
        if not self.winfo_exists():
            return
        p = paleta(self)
        self.fondo.delete("all")
        ancho, alto = self.fondo.winfo_width()-4, self.fondo.winfo_height()-6
        if ancho < 2 or alto < 2:
            return
        redondo(self.fondo, 2, 5, ancho, alto, fill=p["shadow"], outline="")
        redondo(self.fondo, 1, 1, ancho, alto, fill=p["surface"],
                outline=mezclar(p["border"], "#528CFF", self.hover), width=1)

    def animar(self, dentro):
        if getattr(self._root(), "_reducir_movimiento", False):
            self.hover = float(dentro)
            self.dibujar()
            return
        if self._animacion:
            self.after_cancel(self._animacion)
        inicio, destino, reloj = self.hover, float(dentro), time.monotonic()
        def avanzar():
            self._animacion = None
            if not self.winfo_exists():
                return
            t = min(1, (time.monotonic()-reloj)/.16)
            self.hover = inicio+(destino-inicio)*(1-(1-t)**3)
            self.dibujar()
            if t < 1:
                self._animacion = self.after(16, avanzar)
        avanzar()

    def actualizar_tema(self):
        self.configure(bg=color_fondo(self.master))
        self.fondo.configure(bg=color_fondo(self.master))
        self.cuerpo.configure(bg=paleta(self)["surface"])
        self.dibujar()

    def _cerrar(self, event):
        if event.widget is self and self._animacion:
            self.after_cancel(self._animacion)
            self._animacion = None


class Icono(tk.Canvas):
    def __init__(self, parent, nombre, color="#2563EB", tamano=40):
        super().__init__(parent, width=tamano, height=tamano, highlightthickness=0)
        self.nombre, self.color, self.tamano = nombre, color, tamano
        self.imagen = icono(self, nombre, 24 if tamano < 60 else 48)
        self.actualizar_tema()

    def actualizar_tema(self):
        self.configure(bg=color_fondo(self.master))
        self.delete("all")
        redondo(self, 1, 1, self.tamano-2, self.tamano-2, 12, fill=self.color, outline="")
        self.create_image(self.tamano/2, self.tamano/2, image=self.imagen)


class Boton(ttk.Button):
    def __init__(self, parent, texto, comando, principal=False, icon=None, **kwargs):
        estilo = "Primary.TButton" if principal else "TButton"
        super().__init__(parent, text=texto, command=comando, style=estilo, cursor="hand2", **kwargs)
        if icon:
            self.imagen = icono(self, icon, 16)
            self.configure(image=self.imagen, compound="left")


class Pasos(tk.Canvas):
    def __init__(self, parent, etiquetas, actual=0):
        super().__init__(parent, height=64, highlightthickness=0)
        self.etiquetas, self.actual = etiquetas, actual
        self.bind('<Configure>', lambda e: self.actualizar_tema())
        self.actualizar_tema()

    def actualizar_tema(self):
        self.configure(bg=color_fondo(self.master))
        self.delete('all')
        p, ancho = paleta(self), max(120, self.winfo_width())
        separacion = ancho/len(self.etiquetas)
        for i, texto in enumerate(self.etiquetas):
            x = separacion*(i+.5)
            if i < len(self.etiquetas)-1:
                self.create_line(x,16,x+separacion,16,fill=p['primary'] if i < self.actual else p['border'],width=3)
            self.create_oval(x-11,5,x+11,27,fill=p['primary'] if i<=self.actual else p['raised'],outline='')
            self.create_text(x,16,text=str(i+1),fill='white' if i<=self.actual else p['muted'],font=fuente(self,8,True))
            self.create_text(x,43,text=texto,width=max(45,separacion-8),fill=p['text'] if i<=self.actual else p['muted'],font=fuente(self,8,True))


class Rejilla(tk.Frame):
    def __init__(self, parent, minimo=220, maximo=4, **kwargs):
        super().__init__(parent, bg=color_fondo(parent), **kwargs)
        self.minimo, self.maximo = minimo, maximo
        self.tarjetas, self.columnas = [], 0
        self.limite = None
        self.bind("<Configure>", self.reacomodar)

    def agregar(self, tarjeta):
        self.tarjetas.append(tarjeta)
        self.columnas = 0
        self.reacomodar()

    def reacomodar(self, event=None):
        n = max(1, min(self.maximo, max(1, self.winfo_width())//self.minimo))
        if n == self.columnas:
            return
        for i in range(self.maximo):
            self.columnconfigure(i, weight=0, uniform="")
        for i in range(n):
            self.columnconfigure(i, weight=1, uniform="rejilla")
        for i, card in enumerate(self.tarjetas):
            if self.limite is not None and i >= self.limite:
                card.grid_remove()
                continue
            card.grid(row=i//n, column=i % n, sticky="nsew", padx=(0, 12 if i % n != n-1 else 0), pady=(0, 12))
        self.columnas = n


def actualizar_colores(widget):
    """Recolorea controles existentes sin perder formularios ni selecciones."""
    root = widget._root()
    nueva = paleta(root)
    anterior = CLARO if getattr(root,'_modo_oscuro',False) else OSCURO
    reemplazos = {anterior[k]: nueva[k] for k in ("bg", "surface", "raised", "text", "muted", "border", "soft", "nav")}
    reemplazos.update({"#F5F7FB": nueva["bg"], "#111827": nueva["text"],
                       "#64748B": nueva["muted"], "#E2E8F0": nueva["border"],
                       "#DBEAFE": nueva["soft"]})
    def recorrer(w):
        try:
            if getattr(w, '_tema_aplicado', None) == getattr(root, '_modo_oscuro', False):
                for hijo in w.winfo_children():
                    recorrer(hijo)
                return
            if hasattr(w, "_color_fondo"):
                w.configure(background=nueva[w._color_fondo])
            elif not isinstance(w, ttk.Widget):
                for opcion in ("background", "foreground", "insertbackground", "selectbackground", "selectforeground"):
                    if opcion in w.keys():
                        color = str(w.cget(opcion))
                        if opcion=='background' and color in ('white','#FFFFFF','#ffffff'):
                            w.configure(background=nueva['surface'])
                        elif opcion=='background' and color=='#111827':
                            w.configure(background=nueva['nav'])
                        elif opcion in ('foreground','insertbackground') and color in ('black','#000000','SystemWindowText'):
                            w.configure(**{opcion:nueva['text']})
                        elif color in reemplazos:
                            w.configure(**{opcion: reemplazos[color]})
            if hasattr(w, "actualizar_tema"):
                w.actualizar_tema()
            if isinstance(w,ttk.Button) and hasattr(root,'_adaptar_boton'):
                root._adaptar_boton(w)
            w._tema_aplicado = getattr(root, '_modo_oscuro', False)
            for hijo in w.winfo_children():
                recorrer(hijo)
        except tk.TclError:
            pass
    recorrer(widget)
