"""Acceso local y pantallas de perfil y ajustes dentro de la misma ventana."""
from concurrent.futures import ThreadPoolExecutor
import tkinter as tk
from tkinter import ttk, messagebox

from ..core import cuentas, datos
from .diseno import Boton, Icono, Superficie, Texto, fuente, marco, paleta
from .ui import aviso_error, crear_ventana, cerrar_vista, area_desplazable


class Acceso(tk.Frame):
    def __init__(self, root, al_entrar):
        super().__init__(root, bg=paleta(root)["bg"])
        self._color_fondo = "bg"
        self.al_entrar = al_entrar
        self.registro = False
        self.trabajo = None
        self.reloj = None
        self.ejecutor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="acceso_ofivanta")
        self.pack(fill="both", expand=True)
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        marca = tk.Canvas(self, bg="#0F1F4D", highlightthickness=0)
        marca.grid(row=0, column=0, sticky="nsew")
        self.marca = marca
        marca.bind("<Configure>", self._dibujar_marca)
        area = marco(self)
        area.grid(row=0, column=1, sticky="nsew", padx=24, pady=12)
        canvas = tk.Canvas(area, highlightthickness=0, bg=paleta(root)['bg'])
        canvas._color_fondo = 'bg'
        barra = ttk.Scrollbar(area, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=barra.set)
        barra.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        derecha = marco(canvas)
        ventana = canvas.create_window((0, 0), window=derecha, anchor='nw')
        derecha.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(ventana, width=e.width))
        root.bind('<MouseWheel>', lambda e: canvas.yview_scroll(-1 if e.delta>0 else 1,'units'))
        self.scroll_canvas = canvas
        derecha.columnconfigure(0, weight=1)
        derecha.rowconfigure(0, weight=1)
        derecha.rowconfigure(2, weight=1)
        tarjeta = Superficie(derecha, padding=24)
        tarjeta.grid(row=1, column=0, sticky="ew", padx=8, pady=20)
        body = tarjeta.cuerpo
        self.titulo = Texto(body, "Bienvenido a casa.", 24, negrita=True, wraplength=430)
        self.titulo.pack(anchor="w")
        self.subtitulo = Texto(body, "Entra y encuentra ayuda para tu hogar.", 10, "muted", wraplength=430)
        self.subtitulo.pack(anchor="w", pady=(6, 16))
        self.nombre, self.correo, self.clave, self.confirmacion = [tk.StringVar() for _ in range(4)]
        self.ver_clave = tk.BooleanVar(value=False)
        self.acepta = tk.BooleanVar(value=False)
        self.fila_nombre = self._campo(body, "Tu nombre", self.nombre)
        self.fila_nombre.pack_forget()
        self.fila_correo = self._campo(body, "Correo electrónico", self.correo)
        self.fila_clave = self._campo(body, "Contraseña", self.clave, True)
        self.fila_confirmar = self._campo(body, "Repite tu contraseña", self.confirmacion, True)
        self.fila_confirmar.pack_forget()
        self.mostrar = ttk.Checkbutton(body, text="Mostrar contraseña", variable=self.ver_clave, command=self._mostrar_clave)
        self.mostrar.pack(anchor="w", pady=(0, 8))
        self.condiciones = marco(body, "surface")
        ttk.Checkbutton(self.condiciones, text="Leí y acepto las condiciones y la privacidad.", variable=self.acepta).pack(anchor="w")
        Boton(self.condiciones, "Leer condiciones y privacidad", self._aviso).pack(fill="x", pady=(4, 8))
        self.estado = Texto(body, "", 9, "muted", wraplength=410)
        self.estado.pack(anchor="w", pady=(0, 8))
        self.entrar = Boton(body, "Iniciar sesión", self.enviar, principal=True)
        self.entrar.pack(fill="x")
        self.alternar = Boton(body, "Crear una cuenta", self.cambiar_modo)
        self.alternar.pack(fill="x", pady=(8, 12))
        Texto(body, "También podrás entrar con", 9, "muted").pack(anchor="center", pady=(0, 8))
        proveedores = marco(body, "surface")
        proveedores.pack(fill="x")
        for proveedor in ("Google", "Apple"):
            Boton(proveedores, proveedor, lambda p=proveedor: self.proveedor(p)).pack(side="left", fill="x", expand=True, padx=(0, 6))
        Texto(body, "Google y Apple: aún no disponibles.", 8, "muted").pack(anchor="center", pady=(6, 12))
        Boton(body, "Explorar como invitado", lambda: self._invitado()).pack(fill="x")
        Texto(body, "Cuentas de esta computadora · Correo sin verificar", 8, "muted", wraplength=420).pack(anchor="center", pady=(12, 0))
        self.bind("<Configure>", self._adaptar)
        self.bind("<Destroy>", self._cerrar, add="+")
        self.fila_correo.entrada.focus_set()

    def _campo(self, parent, titulo, variable, clave=False):
        fila = marco(parent, "surface")
        fila.pack(fill="x", pady=(0, 10))
        Texto(fila, titulo, 9, negrita=True).pack(anchor="w", pady=(0, 4))
        entrada = ttk.Entry(fila, textvariable=variable, show="•" if clave else "", width=1)
        entrada.pack(fill="x")
        entrada.bind("<Return>", lambda e: self.enviar())
        fila.entrada = entrada
        return fila

    def _dibujar_marca(self, event=None):
        c = self.marca
        c.delete("all")
        w, h = c.winfo_width(), c.winfo_height()
        for r, color in [(220, "#142B62"), (160, "#183875"), (100, "#1E4DA5")]:
            c.create_oval(w*.65-r, h*.38-r, w*.65+r, h*.38+r, fill=color, outline="")
        c.create_text(40, 40, text="Ofivanta", fill="white", font=fuente(self, 27, True), anchor="nw")
        c.create_text(40, h*.52, text="Tu hogar.\nTu tranquilidad.", fill="white", font=fuente(self, 32, True), anchor="nw", width=max(180, w-70))
        c.create_text(40, h*.76, text="Encuentra un oficio, conoce a tu profesional\ny acuerda el trabajo antes de confirmar.", fill="#CFDEFF", font=fuente(self, 11), anchor="nw", width=max(180, w-80))
        c.create_text(40, h-45, text="SERVICIOS PARA TU HOGAR", fill="#B7CCFA", font=fuente(self, 9, True), anchor="w")

    def _adaptar(self, event=None):
        if event and event.widget is not self:
            return
        if self.winfo_width() < 850:
            self.marca.grid_remove()
            self.columnconfigure(0, weight=0)
        else:
            self.marca.grid()
            self.columnconfigure(0, weight=1)

    def _mostrar_clave(self):
        for fila in (self.fila_clave, self.fila_confirmar):
            fila.entrada.configure(show="" if self.ver_clave.get() else "•")

    def cambiar_modo(self):
        if self.trabajo:
            return
        self.registro = not self.registro
        self.estado.configure(text="")
        self.clave.set("")
        self.confirmacion.set("")
        self.acepta.set(False)
        if self.registro:
            self.titulo.configure(text="Haz espacio para lo fácil.")
            self.subtitulo.configure(text="Crea tu cuenta local. Usa una contraseña de 15 caracteres o más.")
            self.fila_nombre.pack(fill="x", before=self.fila_correo, pady=(0, 10))
            self.fila_confirmar.pack(fill="x", before=self.mostrar, pady=(0, 10))
            self.condiciones.pack(fill="x", before=self.estado)
        else:
            self.titulo.configure(text="Bienvenido a casa.")
            self.subtitulo.configure(text="Entra y encuentra ayuda para tu hogar.")
            self.fila_nombre.pack_forget()
            self.fila_confirmar.pack_forget()
            self.condiciones.pack_forget()
        self.entrar.configure(text="Crear cuenta" if self.registro else "Iniciar sesión")
        self.alternar.configure(text="Ya tengo una cuenta" if self.registro else "Crear una cuenta")

    def enviar(self):
        if self.trabajo:
            return
        nombre, correo, clave, confirmacion = self.nombre.get(), self.correo.get(), self.clave.get(), self.confirmacion.get()
        try:
            cuentas.correo_valido(correo)
            if self.registro:
                cuentas.validar_clave(clave)
                if clave != confirmacion:
                    raise ValueError("Las contraseñas no coinciden.")
                if not self.acepta.get():
                    raise ValueError("Lee y acepta las condiciones y la privacidad.")
        except ValueError as error:
            self.estado.configure(text=str(error))
            return
        self.entrar.state(["disabled"])
        self.alternar.state(["disabled"])
        self.estado.configure(text="Creando tu cuenta…" if self.registro else "Comprobando tu acceso…")
        self.trabajo = (self.ejecutor.submit(cuentas.crear_cuenta, nombre, correo, clave, True)
                        if self.registro else self.ejecutor.submit(cuentas.iniciar_sesion, correo, clave))
        self._esperar()

    def _esperar(self):
        self.reloj = None
        if not self.trabajo.done():
            self.reloj = self.after(50, self._esperar)
            return
        trabajo, self.trabajo = self.trabajo, None
        self.entrar.state(["!disabled"])
        self.alternar.state(["!disabled"])
        try:
            usuario = trabajo.result()
        except (ValueError, OSError, cuentas.sqlite3.Error) as error:
            self.estado.configure(text=str(error) if isinstance(error, ValueError) else "No pudimos abrir tus datos. Inténtalo de nuevo.")
            self.clave.set("")
            self.confirmacion.set("")
            return
        self.clave.set("")
        self.confirmacion.set("")
        self.al_entrar(usuario)

    def _invitado(self):
        if not self.trabajo:
            self.al_entrar(None)

    def proveedor(self, nombre):
        messagebox.showinfo(nombre+" aún no disponible", "Por ahora puedes crear una cuenta local con tu correo o explorar como invitado. Esta opción todavía no conecta tu cuenta de "+nombre+".", parent=self.winfo_toplevel())

    def _aviso(self):
        from ..core import politicas
        panel = Superficie(self, padding=24)
        panel.place(relx=.5, rely=.5, anchor="center", width=min(760, self.winfo_width()-60))
        Texto(panel.cuerpo, "Condiciones y privacidad", 18, negrita=True).pack(anchor="w", pady=(0, 10))
        from tkinter.scrolledtext import ScrolledText
        texto = ScrolledText(panel.cuerpo, height=15, wrap="word", font=fuente(self, 10))
        texto.pack(fill="both", expand=True)
        texto.insert("1.0", "\n\n".join(politicas.DOCUMENTOS[k][1] for k in ("condiciones", "privacidad")))
        texto.configure(state="disabled")
        Boton(panel.cuerpo, "Volver", panel.destroy, principal=True).pack(fill="x", pady=(12, 0))

    def _cerrar(self, event):
        if event.widget is self:
            if self.reloj:
                self.after_cancel(self.reloj)
            self.ejecutor.shutdown(wait=False, cancel_futures=True)


def abrir_perfil_usuario(parent):
    root = parent._root()
    win = crear_ventana(parent, "Mi perfil")
    body, canvas = area_desplazable(win)
    win.scroll_canvas = canvas
    usuario = getattr(root, "usuario", None)
    card = Superficie(body, padding=24)
    card.pack(fill="x", padx=24, pady=24)
    contenido = card.cuerpo
    Icono(contenido, "user-round", "#2563EB", 64).pack(anchor="w")
    Texto(contenido, "Mi perfil", 25, negrita=True).pack(anchor="w", pady=(12, 4))
    if not usuario:
        Texto(contenido, "Estás explorando como invitado. Crea una cuenta para tener tu perfil y tus propios datos locales.", 11, "muted", wraplength=700).pack(anchor="w", pady=(8, 16))
        Boton(contenido, "Entrar o crear cuenta", root.cerrar_sesion, principal=True).pack(anchor="w")
        return win
    Texto(contenido, usuario["correo"]+" · Correo sin verificar", 10, "muted").pack(anchor="w", pady=(0, 16))
    variables = {}
    for clave, titulo in [("nombre", "Tu nombre"), ("telefono", "Teléfono (opcional)"), ("domicilio", "Dirección de casa (opcional)")]:
        Texto(contenido, titulo, 10, negrita=True).pack(anchor="w", pady=(8, 4))
        var = tk.StringVar(value=usuario.get(clave, ""))
        ttk.Entry(contenido, textvariable=var).pack(fill="x")
        variables[clave] = var
    estado = Texto(contenido, "La dirección guardada se puede usar al preparar tu solicitud rápida.", 9, "muted", wraplength=700)
    estado.pack(anchor="w", pady=12)
    def guardar():
        try:
            root.usuario = cuentas.guardar_perfil(usuario["id"], *(variables[k].get() for k in ("nombre", "telefono", "domicilio")))
        except (ValueError, OSError, cuentas.sqlite3.Error) as error:
            aviso_error(win, error)
            return
        root.actualizar_usuario()
        estado.configure(text="Tus cambios quedaron guardados en esta computadora.")
    Boton(contenido, "Guardar cambios", guardar, principal=True).pack(anchor="w", pady=(4, 12))
    Boton(contenido, "Cerrar sesión", root.cerrar_sesion).pack(anchor="w")
    win.campos = variables
    return win


def abrir_ajustes(parent):
    root = parent._root()
    win = crear_ventana(parent, "Ajustes")
    body, canvas = area_desplazable(win)
    win.scroll_canvas = canvas
    card = Superficie(body, padding=24)
    card.pack(fill="x", padx=24, pady=24)
    contenido = card.cuerpo
    Icono(contenido, "sun", "#2563EB", 56).pack(anchor="w")
    Texto(contenido, "Hazla tuya", 25, negrita=True).pack(anchor="w", pady=(12, 4))
    Texto(contenido, "Apariencia, movimiento y privacidad.", 11, "muted").pack(anchor="w", pady=(0, 20))
    oscuro = tk.BooleanVar(value=getattr(root, "_modo_oscuro", False))
    reducido = tk.BooleanVar(value=getattr(root, "_reducir_movimiento", False))
    avisos = tk.BooleanVar(value=getattr(root, "_avisos", True))
    estado = Texto(contenido, "", 9, "muted")
    def guardar():
        cambios = {"oscuro": oscuro.get(), "reducir_movimiento": reducido.get(), "avisos": avisos.get()}
        try:
            if getattr(root, "usuario", None):
                root.usuario = cuentas.guardar_ajustes(root.usuario["id"], cambios)
        except (ValueError, OSError, cuentas.sqlite3.Error) as error:
            aviso_error(win, error)
            return
        root._reducir_movimiento, root._avisos = reducido.get(), avisos.get()
        root.establecer_tema(oscuro.get(), persistir=False)
        root.actualizar_usuario()
        estado.configure(text="Ajustes guardados." if root.usuario else "Ajustes aplicados para esta sesión de invitado.")
    for texto, variable in [("Usar modo oscuro", oscuro), ("Reducir animaciones", reducido), ("Mostrar avisos dentro de la app", avisos)]:
        ttk.Checkbutton(contenido, text=texto, variable=variable, command=guardar).pack(anchor="w", pady=10)
    Texto(contenido, "Los avisos son locales; no envían notificaciones a otros dispositivos.", 9, "muted", wraplength=700).pack(anchor="w", pady=(4, 20))
    estado.pack(anchor="w", pady=(0, 16))
    from .win_home import abrir_centro_ayuda
    Boton(contenido, "Privacidad y datos de mis servicios", lambda: abrir_centro_ayuda(win, "datos")).pack(anchor="w", pady=(0, 10))
    Boton(contenido, "Volver", lambda: cerrar_vista(win)).pack(anchor="w")
    win.oscuro, win.reducido, win.avisos = oscuro, reducido, avisos
    return win
