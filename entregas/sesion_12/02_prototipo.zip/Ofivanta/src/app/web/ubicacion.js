'use strict';
const sesion=new URLSearchParams(location.hash.slice(1)).get('sesion')||'';
history.replaceState(null,'','/ubicacion');
const estado=document.getElementById('estado');
const iniciar=document.getElementById('iniciar');
const detener=document.getElementById('detener');
let activo=false,temporizador=null,ocupado=false;
async function api(ruta,datos){
  const respuesta=await fetch(ruta,{method:datos?'POST':'GET',headers:{'X-Ofivanta-Sesion':sesion,...(datos?{'Content-Type':'application/json'}:{})},body:datos?JSON.stringify(datos):undefined,cache:'no-store',credentials:'omit'});
  if(!respuesta.ok)throw new Error('No se pudo actualizar. La sesión pudo caducar o el servicio pudo terminar.');
  return respuesta.json();
}
function apagarLocal(){activo=false;clearInterval(temporizador);temporizador=null;iniciar.disabled=false;detener.disabled=true;ocupado=false;}
function medir(){
  if(!activo||ocupado)return;
  ocupado=true;
  navigator.geolocation.getCurrentPosition(async p=>{
    if(!activo){ocupado=false;return;}
    try{
      await api('/api/posicion',{latitud:p.coords.latitude,longitud:p.coords.longitude,precision:p.coords.accuracy,medida_en:p.timestamp/1000});
      if(activo)estado.textContent='Compartiendo. Precisión aproximada: '+Math.round(p.coords.accuracy)+' metros. El mapa de Ofivanta se actualiza automáticamente.';
    }catch(e){estado.textContent=e.message;apagarLocal();}
    finally{ocupado=false;}
  },error=>{
    ocupado=false;
    estado.textContent=error.code===1?'No autorizaste la ubicación. Puedes seguir usando Ofivanta sin compartirla.':'No se obtuvo GPS. Comprueba el permiso, la conexión y la ubicación del dispositivo.';
    if(error.code===1){apagarLocal();iniciar.disabled=true;api('/api/detener',{}).catch(()=>{});}
  },{enableHighAccuracy:true,maximumAge:5000,timeout:12000});
}
iniciar.addEventListener('click',()=>{
  if(!navigator.geolocation){estado.textContent='Este navegador no admite ubicación.';return;}
  activo=true;iniciar.disabled=true;detener.disabled=false;estado.textContent='Esperando tu permiso del navegador...';medir();temporizador=setInterval(medir,10000);
});
detener.addEventListener('click',async()=>{
  apagarLocal();iniciar.disabled=true;
  try{await api('/api/detener',{});estado.textContent='Ubicación detenida y retirada del mapa. Cierra esta pestaña. Para compartir otra vez, abre un permiso nuevo desde la app.';}
  catch(e){estado.textContent='No se pudo contactar la app. El punto caduca en 90 segundos como máximo o al cerrarla.';}
});
api('/api/sesion').then(info=>{document.getElementById('solicitud').textContent='Solicitud #'+info.numero+'. Modo '+(info.rol==='cliente'?'cliente':'prestador de ejemplo')+'.';iniciar.disabled=false;}).catch(()=>{estado.textContent='Este permiso no es válido. Vuelve a abrirlo desde el mapa de Ofivanta.';});
