"""Mosaicos de OpenStreetMap para el Canvas. Solo descarga el área visible."""
import json
import math
import re
import struct
import time
from email.utils import parsedate_to_datetime
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request,urlopen

ATRIBUCION='© OpenStreetMap contributors'
URL_MAPA='https://tile.openstreetmap.org/{z}/{x}/{y}.png'
AGENTE='Ofivanta-prototipo/1.0 (+https://github.com/a00228052-create/ODS8_BolsaDeTrabajo)'


def validar_png(bruto):
    if len(bruto)>300000 or len(bruto)<24 or not bruto.startswith(b'\x89PNG\r\n\x1a\n') or bruto[12:16]!=b'IHDR' or struct.unpack('>II',bruto[16:24])!=(256,256):
        raise ValueError('El mosaico no es un PNG de 256 píxeles.')
    return bruto


def vencimiento(headers):
    edad=re.search(r'max-age=(\d+)',headers.get('Cache-Control',''))
    if edad:return time.time()+int(edad.group(1))
    try:return parsedate_to_datetime(headers['Expires']).timestamp()
    except (ValueError,TypeError,KeyError):return time.time()+7*86400


def proyectar(latitud,longitud,zoom):
    latitud=max(-85.05112878,min(85.05112878,latitud))
    escala=256*2**zoom
    seno=math.sin(math.radians(latitud))
    return (longitud+180)/360*escala,(.5-math.log((1+seno)/(1-seno))/(4*math.pi))*escala


def coordenadas(x,y,zoom):
    escala=256*2**zoom
    return math.degrees(math.atan(math.sinh(math.pi*(1-2*y/escala)))),(x%escala)/escala*360-180


class CacheMapa:
    def __init__(self,carpeta):self.carpeta=Path(carpeta)
    def obtener(self,z,x,y):
        if type(z) is not int or not 2<=z<=18 or not all(type(n) is int and 0<=n<2**z for n in (x,y)):
            raise ValueError('Mosaico fuera del mapa.')
        self.carpeta.mkdir(parents=True,exist_ok=True)
        nombre=f'{z}_{x}_{y}'
        imagen=self.carpeta/(nombre+'.png');metadatos=self.carpeta/(nombre+'.json')
        try:
            meta=json.loads(metadatos.read_text(encoding='utf-8'))
            if not isinstance(meta,dict) or type(meta.get('vence')) not in (int,float):meta={}
        except (OSError,ValueError):meta={}
        try:
            with imagen.open('rb') as archivo:guardada=validar_png(archivo.read(300001))
        except (OSError,ValueError):guardada=None
        if guardada is not None and meta.get('vence',0)>time.time():return guardada
        headers={'User-Agent':AGENTE,'Accept':'image/png'}
        if guardada is not None:
            if isinstance(meta.get('etag'),str):headers['If-None-Match']=meta['etag']
            if isinstance(meta.get('modificado'),str):headers['If-Modified-Since']=meta['modificado']
        try:
            with urlopen(Request(URL_MAPA.format(z=z,x=x,y=y),headers=headers),timeout=5) as respuesta:
                bruto=validar_png(respuesta.read(300001))
                meta={'vence':vencimiento(respuesta.headers),'etag':respuesta.headers.get('ETag',''),'modificado':respuesta.headers.get('Last-Modified','')}
            temporal=imagen.with_suffix('.png.tmp');temporal.write_bytes(bruto);temporal.replace(imagen)
            metadatos.write_text(json.dumps(meta),encoding='utf-8')
            return bruto
        except HTTPError as error:
            if error.code==304 and guardada is not None:
                meta['vence']=vencimiento(error.headers)
                metadatos.write_text(json.dumps(meta),encoding='utf-8')
                return guardada
            if guardada is not None:return guardada
            raise
        except (OSError,ValueError):
            if guardada is not None:return guardada
            raise
