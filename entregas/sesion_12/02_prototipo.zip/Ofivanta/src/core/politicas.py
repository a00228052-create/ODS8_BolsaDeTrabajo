"""Textos del prototipo y versión de las condiciones mostradas al usuario."""
from hashlib import sha256

VERSION = "2026-11-20.1"
ESTADOS_MEXICO = (
    "Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas",
    "Chihuahua", "Ciudad de México", "Coahuila", "Colima", "Durango", "Estado de México",
    "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "Michoacán", "Morelos", "Nayarit",
    "Nuevo León", "Oaxaca", "Puebla", "Querétaro", "Quintana Roo", "San Luis Potosí",
    "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz", "Yucatán", "Zacatecas",
)
MOTIVOS = ("Calidad del servicio", "Daño a la propiedad", "Cobro o cancelación", "Fraude o suplantación",
           "Seguridad o acoso", "Opinión inapropiada", "Privacidad y datos personales", "Otro")
DOCUMENTOS = {
    "privacidad": ("Privacidad y ubicación", """Ofivanta es un proyecto escolar del equipo Ofivanta. Esta instalación funciona en una computadora y permite crear cuentas locales con nombre, correo y contraseña, o explorar como invitado. El correo y la identidad no se verifican. Google y Apple todavía no están conectados. No hay atención remota. Usa datos ficticios para probarla. No escribas identificaciones, datos bancarios, información médica ni contraseñas en solicitudes, opiniones o reportes.

El acceso local compara una derivación de la contraseña con una sal distinta por cuenta; no guarda la contraseña en texto. El perfil puede guardar nombre, teléfono y dirección de casa, además de los ajustes de apariencia, movimiento y avisos. No se envía un correo de verificación ni se sincronizan estos datos con una cuenta de Google o Apple.

El formulario guarda nombre, contacto, domicilio, descripción del trabajo y preferencias de atención para gestionar la solicitud. También conserva cotizaciones, movimientos, opiniones y reportes. Cada cuenta local abre una base de servicios separada. El modo invitado usa otra base compartida por quienes elijan ese modo en esta computadora. Cerrar sesión vuelve al acceso y no permite continuar consultando una cuenta registrada desde la interfaz de invitado.

Las bases de datos y las copias de seguridad no están cifradas. Quien pueda leer o modificar los archivos del equipo podría consultar o alterar su contenido. La separación en la interfaz y la contraseña local no protegen frente a ese acceso al sistema ni equivalen a cuentas verificadas o a un servidor con permisos por usuario.

La ubicación precisa es opcional y está apagada por defecto. Solo se solicita al pulsar Compartir ubicación y autorizar el navegador. Se utiliza para el seguimiento de la solicitud elegida. Puedes detenerla y borrar el punto en cualquier momento. No se guarda un historial de recorridos: las posiciones quedan en memoria, caducan y desaparecen al cerrar la app. Si el navegador deja de actualizar, el mapa lo indica.

OpenStreetMap recibe la IP y el área del mapa consultada al cargar sus imágenes. Ofivanta no envía nombre, contacto, domicilio escrito ni descripción a ese proveedor. Los mosaicos del mapa se guardan como caché, separados de las solicitudes.

La sección Datos de esta computadora permite exportar o borrar con confirmación los datos de servicios de la cuenta abierta o del modo invitado. No exporta ni borra la cuenta, el nombre y correo de acceso, la derivación de contraseña, el perfil, los ajustes o la aceptación del registro. Tampoco elimina copias que hayas hecho o compartido. Un reporte de privacidad de esta versión queda en el equipo y no llega automáticamente a una oficina ni inicia un trámite ARCO externo.

Antes de operar con público, el responsable deberá indicar su nombre o razón social, domicilio y medio real para ejercer acceso, rectificación, cancelación y oposición, además de explicar conservación, transferencias y cambios del aviso. Este texto del prototipo no sustituye ese aviso completo ni autoriza usos de publicidad."""),
    "condiciones": ("Condiciones de uso", """Esta versión demuestra cómo buscar un oficio, solicitar un servicio y revisar una cotización. Los trabajadores y los recorridos de ejemplo son ficticios. No hay contratación comercial ni pagos reales, seguro contratado, garantía general o revisión de identidad en esta instalación.

Antes de confirmar un trabajo, revisa al prestador, el alcance, el domicilio, la fecha, los materiales y el precio total. La solicitud inicial no asegura atención inmediata. Una estrella es una opinión y no prueba una licencia, certificación o ausencia de riesgos.

El plan Básico propone una comisión del 10 % al finalizar el trabajo. Pro propone $149 por 30 días y 7 % en nuevas cotizaciones. Son importes de demostración. No se pide tarjeta ni se renueva automáticamente. El precio de cada cotización conserva su porcentaje original. No se agregan cargos ocultos al cliente.

No uses la app para actividades ilegales, amenazas, discriminación, suplantación, trabajos sin autorización del propietario o tareas para las que se requieran permisos que el prestador no tenga. El acceso a un inmueble debe ser acordado por una persona autorizada. La contratación comercial futura deberá realizarla una persona mayor de edad con capacidad para contratar.

No existe una renuncia general de derechos ni una liberación de responsabilidad por daños, fraude o negligencia. Las obligaciones de Ofivanta, del prestador y del cliente dependerán de los hechos, de los contratos válidos y de las leyes aplicables. Llamarse intermediario no elimina por sí solo obligaciones laborales, fiscales o frente al consumidor.

Antes de ofrecer servicios comerciales de reparación o mantenimiento, se debe revisar la NOM-174-SCFI-2007. Cuando el servicio entre en su ámbito y se utilicen contratos de adhesión de los tipos indicados en la norma, corresponde revisar su registro ante Profeco y la información mínima del servicio. La casilla de esta demostración no sustituye ese contrato ni su registro.

Las bases federales se aplican en todo México. Los permisos del oficio, las reglas de construcción, protección civil y responsabilidad civil deben revisarse también en el estado y municipio del servicio. Antes de abrir al público faltan operador legal, canales de atención, cuentas verificadas y compartidas en un servidor, permisos, seguridad, revisión profesional y contratos completos."""),
    "cancelaciones": ("Cancelaciones y desacuerdos", """En el prototipo puedes cancelar una solicitud pendiente, cotizada o confirmada, antes de que comience el trabajo. No se cobra penalización porque no se procesan pagos.

Si un trabajo ya comenzó, registra el desacuerdo en Ayuda y seguridad. Conserva la cotización, las condiciones y la descripción de lo ocurrido. Reportar no significa que el caso ya fue atendido o que se autorizó una devolución. Los reportes de esta versión son locales.

Para una operación real deberán definirse cancelaciones antes y después de la visita, materiales comprados, anticipos, inasistencias, reprogramación, garantías, reclamaciones y devoluciones. Los cargos y las condiciones deben informarse antes de contratar. Las políticas no pueden eliminar derechos irrenunciables del consumidor ni sustituir la reparación de daños que corresponda.

El plan Pro no tiene renovación automática en esta versión. Una suscripción comercial futura necesitará autorización informada y mecanismos accesibles de cancelación conforme a la ley aplicable. Ofivanta no decide automáticamente un conflicto ni impide acudir a las autoridades competentes."""),
    "seguridad": ("Seguridad durante el servicio", """Ofivanta no atiende emergencias. En México, si hay peligro inmediato, incendio, olor a gas, violencia o una persona en riesgo, aléjate si puedes hacerlo con seguridad y llama al 911. Un reporte dentro de esta app no avisa a emergencias ni a una central de vigilancia.

Antes de permitir el acceso a tu casa, confirma quién llegará y revisa los datos del trabajo. No entregues claves, documentos de identidad, contraseñas o datos de tarjeta en comentarios. No aceptes cambios de precio sin revisar una nueva propuesta.

Los trabajos de electricidad, altura, gas, estructura o instalaciones especiales pueden necesitar formación, equipos, permisos y seguros específicos. El catálogo de este prototipo no demuestra esas habilitaciones. No se debe iniciar una tarea peligrosa o para la que falten autorizaciones.

Un prestador también puede detenerse y reportar si encuentra condiciones inseguras, amenazas o un trabajo distinto del acordado. No hay sanción automática por reportar un riesgo. Antes de operar deben existir atención real de incidentes, procedimientos de investigación, asesoría sobre seguros y reglas contra el acoso y la discriminación."""),
    "opiniones": ("Estrellas y opiniones", """Las opiniones del catálogo que dicen De ejemplo son ficticias y su promedio aparece separado. No son reseñas de clientes reales ni acreditan que una persona haya contratado a ese perfil.

Puedes registrar una opinión por solicitud local finalizada, con una calificación de 1 a 5. La app obtiene al trabajador de esa solicitud para evitar valorar a otro por error. Una solicitud local no demuestra identidad ni una compra real. Esta versión no tiene cuentas verificadas.

Cuenta tu experiencia con respeto. No publiques teléfonos, correos, domicilios, amenazas, acusaciones sin sustento, datos sensibles o contenido discriminatorio. El reporte de una opinión la manda a una lista local de revisión; no borra críticas negativas automáticamente.

Antes de abrir al público se necesitan identificación de cuentas, reglas contra opiniones falsas, revisión humana, posibilidad de respuesta y apelación. Las estrellas no son una garantía de seguridad ni una comprobación de licencias."""),
    "prestadores": ("Reglas para prestadores", """El perfil debe describir de forma cierta el oficio, la zona, la experiencia y la disponibilidad. No se mostrará una persona como verificada ni asegurada sin un proceso documentado que lo respalde. En esta entrega todos los perfiles son ficticios.

El prestador debe explicar qué incluye la cotización, qué materiales considera y qué actividades no hará. Antes de una tarea regulada deberán revisarse los permisos y requisitos aplicables al oficio y al lugar. Ofivanta no emite certificaciones profesionales.

La clasificación laboral no se resuelve con una casilla de trabajador independiente. En México debe revisarse cómo opera realmente la plataforma, incluido el mando o supervisión, asignación de tareas, remuneración, seguridad social y el régimen de trabajo en plataformas digitales cuando corresponda.

También deben revisarse facturación, impuestos y posibles retenciones con una persona profesional en materia fiscal. La comisión mostrada en la app no calcula IVA, ISR ni otras obligaciones. No constituye una liquidación fiscal."""),
    "datos": ("Datos de esta computadora", """Las solicitudes, opiniones y reportes se guardan en la base de servicios de la cuenta local abierta. Cada cuenta tiene su propia base. En modo invitado se usa una base compartida por quienes entren como invitados en este equipo. No hay sincronización con otros dispositivos. Usa ejemplos y protege el acceso a los archivos de la computadora, porque no están cifrados.

Puedes exportar los datos de servicios de la cuenta abierta como un archivo JSON o borrarlos desde esta sección. En modo invitado la acción corresponde a la base de invitado. La eliminación requiere escribir BORRAR y confirmarla. La app conservará el catálogo y los perfiles ficticios, pero quitará las solicitudes, cotizaciones, opiniones asociadas, favoritos, planes y reportes de esa base. No afecta las bases de otras cuentas, los archivos ya exportados, las capturas ni los respaldos.

Esta herramienta no exporta ni elimina la cuenta de acceso. El nombre y correo, el teléfono y la dirección guardados en Mi perfil, los ajustes, la derivación de contraseña y la aceptación del registro siguen en la base de cuentas. Puedes modificar el nombre, teléfono y dirección desde Mi perfil. Todavía falta un procedimiento completo para exportar o eliminar los datos de la cuenta y atender los derechos correspondientes; borrar servicios no equivale a borrar tu cuenta.

En un servicio comercial no bastará con esta herramienta: deberán autenticarse las solicitudes de derechos, definirse plazos y conservarse los registros que exija la ley. El responsable tendrá que explicar cuándo procede borrar, bloquear o conservar información. No se promete eliminación inmediata de cualquier registro legalmente necesario."""),
}


def huella():
    contenido=VERSION+'\n'+'\n'.join(titulo+'\n'+texto for titulo,texto in DOCUMENTOS.values())
    return sha256(contenido.encode('utf-8')).hexdigest()
