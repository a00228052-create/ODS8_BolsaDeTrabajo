"""Puente GPS opcional del navegador. Escucha solo en esta computadora."""
import json
import math
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from . import datos

CADUCIDAD_POSICION=90
CADUCIDAD_SESION=1800
ROLES=('cliente','prestador')
ACTIVOS=('cotizacion_aceptada','en_proceso')


def validar_posicion(valor):
    if not isinstance(valor,dict):raise ValueError('Posición no válida.')
    for campo in ('latitud','longitud','precision','medida_en'):
        if type(valor.get(campo)) not in (int,float) or not math.isfinite(valor[campo]):
            raise ValueError('Las coordenadas deben ser números finitos.')
    if not -85.05112878<=valor['latitud']<=85.05112878 or not -180<=valor['longitud']<=180:
        raise ValueError('Coordenadas fuera del mapa.')
    if not 0<=valor['precision']<=100000:raise ValueError('Precisión no válida.')
    if not -5<=time.time()-valor['medida_en']<=CADUCIDAD_POSICION:
        raise ValueError('La ubicación es antigua. Actualiza el permiso del navegador.')
    return {k:float(valor[k]) for k in ('latitud','longitud','precision','medida_en')}


class ServicioUbicaciones:
    def __init__(self,db_path=None):
        self.db_path=db_path or datos.DB_path
        self.sesiones={}
        self.puntos={}
        self.lock=threading.Lock()
        self.server=None
        self.hilo=None

    def iniciar(self):
        if self.server:return
        servicio=self
        carpeta=Path(__file__).resolve().parents[1]/'app/web'
        class Servidor(ThreadingHTTPServer):
            daemon_threads=True
            block_on_close=False
        class Manejador(BaseHTTPRequestHandler):
            server_version='OfivantaLocal'
            sys_version=''
            def setup(self):
                super().setup();self.connection.settimeout(5)
            def log_message(self,*args):pass
            def responder(self,codigo,contenido,tipo='application/json; charset=utf-8'):
                bruto=contenido.encode('utf-8') if isinstance(contenido,str) else contenido
                self.send_response(codigo)
                self.send_header('Content-Type',tipo)
                self.send_header('Content-Length',str(len(bruto)))
                self.send_header('Cache-Control','no-store')
                self.send_header('X-Content-Type-Options','nosniff')
                self.send_header('Referrer-Policy','strict-origin-when-cross-origin')
                self.send_header('Permissions-Policy','geolocation=(self), microphone=(), camera=()')
                self.send_header('Content-Security-Policy',"default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
                self.end_headers();self.wfile.write(bruto)
            def origen_valido(self,escritura=False):
                host=f'127.0.0.1:{self.server.server_port}'
                if self.headers.get('Host')!=host:return False
                if self.headers.get('Sec-Fetch-Site') not in (None,'none','same-origin'):return False
                origen=self.headers.get('Origin')
                return origen=='http://'+host if escritura else origen in (None,'http://'+host)
            def token(self):return self.headers.get('X-Ofivanta-Sesion','')
            def do_GET(self):
                if not self.origen_valido():self.responder(403,'{}');return
                ruta=urlsplit(self.path).path
                archivos={'/ubicacion':('ubicacion.html','text/html; charset=utf-8'),
                          '/ubicacion.js':('ubicacion.js','text/javascript; charset=utf-8'),
                          '/ubicacion.css':('ubicacion.css','text/css; charset=utf-8')}
                if ruta in archivos:
                    nombre,tipo=archivos[ruta]
                    self.responder(200,(carpeta/nombre).read_bytes(),tipo);return
                if ruta=='/api/sesion':
                    try:sesion=servicio.obtener_sesion(self.token())
                    except ValueError:self.responder(403,'{}');return
                    self.responder(200,json.dumps({'rol':sesion['rol'],'numero':sesion['solicitud_id'][:8].upper()}));return
                self.responder(404,'{}')
            def do_POST(self):
                if not self.origen_valido(True):self.responder(403,'{}');return
                if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':self.responder(415,'{}');return
                try:
                    largo=int(self.headers.get('Content-Length','0'))
                    if not 1<=largo<=2048:raise ValueError('Mensaje demasiado grande.')
                    valor=json.loads(self.rfile.read(largo))
                    ruta=urlsplit(self.path).path
                    if ruta=='/api/posicion':servicio.actualizar(self.token(),valor)
                    elif ruta=='/api/detener':servicio.detener(self.token())
                    else:self.responder(404,'{}');return
                    self.responder(200,'{"ok":true}')
                except (ValueError,TypeError,UnicodeDecodeError):self.responder(400,'{"error":"Ubicación o sesión no válida. Vuelve a abrir el permiso desde Ofivanta."}')
                except (OSError,datos.sqlite3.Error):self.responder(503,'{"error":"No se pudo actualizar. Detén el permiso e inténtalo de nuevo."}')
        self.server=Servidor(('127.0.0.1',0),Manejador)
        self.hilo=threading.Thread(target=self.server.serve_forever,kwargs={'poll_interval':.1},daemon=True)
        self.hilo.start()

    def crear_sesion(self,solicitud_id,rol):
        if rol not in ROLES:raise ValueError('Elige cliente o prestador de ejemplo.')
        solicitud=datos.obtener_solicitud(solicitud_id,self.db_path)
        if not solicitud or solicitud['estado'] not in ACTIVOS:
            raise ValueError('Comparte ubicación solo en una solicitud confirmada o en proceso.')
        self.iniciar()
        with self.lock:
            self.sesiones={k:s for k,s in self.sesiones.items() if time.time()-s['creada_en']<CADUCIDAD_SESION}
            if len(self.sesiones)>=20:raise ValueError('Cierra los permisos anteriores antes de abrir más.')
            token=secrets.token_urlsafe(32)
            self.sesiones[token]={'solicitud_id':solicitud_id,'rol':rol,'creada_en':time.time()}
        return f'http://127.0.0.1:{self.server.server_port}/ubicacion#sesion={token}'

    def obtener_sesion(self,token):
        with self.lock:
            sesion=self.sesiones.get(token)
            if not sesion or time.time()-sesion['creada_en']>=CADUCIDAD_SESION:raise ValueError('La sesión caducó.')
            return dict(sesion)

    def actualizar(self,token,valor):
        sesion=self.obtener_sesion(token)
        solicitud=datos.obtener_solicitud(sesion['solicitud_id'],self.db_path)
        if not solicitud or solicitud['estado'] not in ACTIVOS:
            self.detener(token);raise ValueError('El seguimiento terminó.')
        punto=validar_posicion(valor)
        with self.lock:
            if self.sesiones.get(token)!=sesion:raise ValueError('El permiso fue revocado.')
            self.puntos[(sesion['solicitud_id'],sesion['rol'])]=punto

    def detener(self,token):
        with self.lock:
            sesion=self.sesiones.pop(token,None)
            if sesion:self.puntos.pop((sesion['solicitud_id'],sesion['rol']),None)

    def posiciones(self,solicitud_id):
        solicitud=datos.obtener_solicitud(solicitud_id,self.db_path) if solicitud_id else None
        with self.lock:
            ahora=time.time()
            self.puntos={k:p for k,p in self.puntos.items() if ahora-p['medida_en']<=CADUCIDAD_POSICION}
            if not solicitud or solicitud['estado'] not in ACTIVOS:
                self.puntos={k:p for k,p in self.puntos.items() if k[0]!=solicitud_id}
                return {}
            return {rol:dict(p) for (sid,rol),p in self.puntos.items() if sid==solicitud_id}

    def revocar_todo(self):
        with self.lock:self.sesiones.clear();self.puntos.clear()

    def cerrar(self):
        self.revocar_todo()
        if self.server:self.server.shutdown();self.server.server_close();self.server=None
