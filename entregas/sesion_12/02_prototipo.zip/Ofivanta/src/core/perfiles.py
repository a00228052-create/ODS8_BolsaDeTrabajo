"""Perfiles, opiniones y ayuda locales. Los ejemplos nunca cuentan como compras reales."""
import re
from uuid import uuid4
from . import datos, politicas

EXPERIENCIA={"1":8,"2":6,"3":7,"4":10,"5":5,"6":4,"7":9,"8":12,"9":6,"10":8}
EJEMPLOS={
    "1":((5,"Explicó la reparación de la fuga antes de empezar."),(4,"El trabajo quedó bien y explicó los materiales.")),
    "2":((5,"Revisó la tubería y dejó limpia el área."),(4,"Fue claro con lo que incluía la revisión.")),
    "3":((5,"Explicó qué fallaba en los contactos."),(5,"Acordamos el alcance antes del trabajo.")),
    "4":((4,"Respondió las dudas sobre el mantenimiento."),),
    "5":((5,"La limpieza coincidió con lo que acordamos."),),
    "6":((4,"Resolvió los arreglos que se habían descrito."),),
    "7":((5,"Cuidó los muebles al pintar."),),
    "8":((5,"La puerta volvió a cerrar correctamente."),),
    "9":((4,"Explicó cómo cuidar las plantas después."),),
    "10":((5,"Explicó las opciones de cerradura."),),
}


def preparar(db_path=None):
    datos.inicializar_base(db_path)
    with datos.conexion(db_path) as con:
        con.executescript('''
            CREATE TABLE IF NOT EXISTS resenas (
                id TEXT PRIMARY KEY, trabajador_id TEXT NOT NULL REFERENCES trabajadores(id),
                solicitud_id TEXT UNIQUE REFERENCES solicitudes(id),
                alias TEXT NOT NULL, estrellas INTEGER NOT NULL CHECK(estrellas BETWEEN 1 AND 5),
                comentario TEXT NOT NULL, ejemplo INTEGER NOT NULL CHECK(ejemplo IN (0,1)),
                creada_en TEXT NOT NULL,
                CHECK((ejemplo=1 AND solicitud_id IS NULL) OR (ejemplo=0 AND solicitud_id IS NOT NULL)));
            CREATE TABLE IF NOT EXISTS reportes (
                id TEXT PRIMARY KEY, solicitud_id TEXT REFERENCES solicitudes(id),
                trabajador_id TEXT REFERENCES trabajadores(id), resena_id TEXT REFERENCES resenas(id),
                motivo TEXT NOT NULL, descripcion TEXT NOT NULL, creada_en TEXT NOT NULL,
                estado TEXT NOT NULL DEFAULT 'Guardado local');
            CREATE TABLE IF NOT EXISTS aceptaciones (
                solicitud_id TEXT PRIMARY KEY REFERENCES solicitudes(id), version TEXT NOT NULL,
                huella TEXT NOT NULL, fecha TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS idx_resenas_trabajador ON resenas(trabajador_id,ejemplo);
        ''')
        for tid,opiniones in EJEMPLOS.items():
            if not con.execute('SELECT 1 FROM trabajadores WHERE id=?',(tid,)).fetchone():continue
            for i,(valor,comentario) in enumerate(opiniones):
                con.execute('''INSERT OR IGNORE INTO resenas
                    (id,trabajador_id,solicitud_id,alias,estrellas,comentario,ejemplo,creada_en)
                    VALUES (?,?,NULL,?,?,?,1,?)''',
                    (f'ejemplo-{tid}-{i}',tid,'Cliente de ejemplo',valor,comentario,'2026-11-20T00:00:00+00:00'))


def resumenes(db_path=None):
    preparar(db_path)
    with datos.conexion(db_path) as con:
        filas=con.execute('''SELECT trabajador_id,ejemplo,COUNT(*) AS cantidad,AVG(estrellas) AS promedio
            FROM resenas GROUP BY trabajador_id,ejemplo''').fetchall()
    resultado={}
    for fila in filas:
        clave='ejemplo' if fila['ejemplo'] else 'local'
        resultado.setdefault(fila['trabajador_id'],{})[clave]={'cantidad':fila['cantidad'],'promedio':round(fila['promedio'],1)}
    return resultado


def obtener_perfil(trabajador_id,db_path=None):
    preparar(db_path)
    trabajadores=[t for t in datos.obtener_trabajadores(db_path=db_path) if t['id']==str(trabajador_id)]
    if not trabajadores:raise ValueError('No se encontró al trabajador.')
    perfil=dict(trabajadores[0])
    perfil['oficios']=[t['servicio'] for t in trabajadores]
    perfil['experiencia']=EXPERIENCIA.get(str(trabajador_id),0)
    perfil['verificacion']='Identidad y licencias sin verificar'
    perfil['es_ejemplo']=True
    with datos.conexion(db_path) as con:
        perfil['resenas']=[dict(r) for r in con.execute('SELECT * FROM resenas WHERE trabajador_id=? ORDER BY ejemplo,creada_en DESC,id', (str(trabajador_id),))]
        perfil['trabajos_locales']=con.execute("SELECT COUNT(*) FROM solicitudes WHERE trabajador_id=? AND estado='completada'",(str(trabajador_id),)).fetchone()[0]
    perfil['valoraciones']=resumenes(db_path).get(str(trabajador_id),{})
    return perfil


def texto_valoracion(resumen):
    if not resumen:return 'Sin opiniones'
    partes=[]
    for clave,etiqueta in [('local','locales'),('ejemplo','de ejemplo')]:
        if clave in resumen:
            r=resumen[clave]
            tipo='local' if clave=='local' and r['cantidad']==1 else etiqueta
            partes.append(f"{r['promedio']:.1f}/5 ({r['cantidad']} {tipo})")
    return ' · '.join(partes)


def validar_opinion(texto):
    if not isinstance(texto,str) or not 5<=len(texto.strip())<=1500:
        raise ValueError('Escribe una opinión de 5 a 1500 caracteres.')
    if re.search(r'[^\s@]+@[^\s@]+\.[^\s@]+',texto) or re.search(r'(?:\+?\d[\s().-]*){10,}',texto):
        raise ValueError('Quita los teléfonos y correos de la opinión. No publiques datos personales.')
    if any(ord(c)<32 and c not in '\n\t' for c in texto):raise ValueError('La opinión contiene caracteres no válidos.')


def guardar_resena(solicitud_id,estrellas,comentario,db_path=None):
    if type(estrellas) is not int or not 1<=estrellas<=5:raise ValueError('Elige de 1 a 5 estrellas.')
    validar_opinion(comentario)
    preparar(db_path)
    with datos.conexion(db_path) as con:
        con.execute('BEGIN IMMEDIATE')
        solicitud=con.execute('SELECT estado,trabajador_id FROM solicitudes WHERE id=?',(solicitud_id,)).fetchone()
        if not solicitud or solicitud['estado']!='completada':raise ValueError('Solo puedes opinar sobre una solicitud finalizada.')
        if con.execute('SELECT 1 FROM resenas WHERE solicitud_id=?',(solicitud_id,)).fetchone():raise ValueError('Esta solicitud ya tiene una opinión.')
        rid=str(uuid4())
        con.execute('INSERT INTO resenas VALUES (?,?,?,?,?,?,0,?)',
                    (rid,solicitud['trabajador_id'],solicitud_id,'Cliente de solicitud local',estrellas,comentario.strip(),datos.ahora()))
    return rid


def guardar_reporte(motivo,descripcion,solicitud_id=None,trabajador_id=None,resena_id=None,db_path=None):
    if motivo not in politicas.MOTIVOS:raise ValueError('Elige un motivo de las opciones disponibles.')
    if not isinstance(descripcion,str) or not 10<=len(descripcion.strip())<=3000:raise ValueError('Describe lo ocurrido en 10 a 3000 caracteres.')
    preparar(db_path)
    with datos.conexion(db_path) as con:
        if solicitud_id:
            s=con.execute('SELECT trabajador_id FROM solicitudes WHERE id=?',(solicitud_id,)).fetchone()
            if not s:raise ValueError('No se encontró la solicitud.')
            trabajador_id=s['trabajador_id']
        if resena_id:
            r=con.execute('SELECT trabajador_id FROM resenas WHERE id=?',(resena_id,)).fetchone()
            if not r:raise ValueError('No se encontró la opinión.')
            if trabajador_id and str(trabajador_id)!=r['trabajador_id']:raise ValueError('La opinión no pertenece a este perfil.')
            trabajador_id=r['trabajador_id']
        if trabajador_id and not con.execute('SELECT 1 FROM trabajadores WHERE id=?',(str(trabajador_id),)).fetchone():raise ValueError('No se encontró al trabajador.')
        rid=str(uuid4())
        con.execute('''INSERT INTO reportes(id,solicitud_id,trabajador_id,resena_id,motivo,descripcion,creada_en)
            VALUES (?,?,?,?,?,?,?)''',(rid,solicitud_id,str(trabajador_id) if trabajador_id else None,resena_id,motivo,descripcion.strip(),datos.ahora()))
    return rid


def obtener_reportes(db_path=None):
    preparar(db_path)
    with datos.conexion(db_path) as con:return [dict(r) for r in con.execute('SELECT * FROM reportes ORDER BY creada_en DESC')]


def exportar_datos(db_path=None):
    preparar(db_path)
    tablas=('solicitudes','cotizaciones','movimientos','resenas','reportes','aceptaciones','documentos_legales','favoritos','suscripciones_demo')
    with datos.conexion(db_path) as con:
        return {t:[dict(r) for r in con.execute('SELECT * FROM '+t)] for t in tablas}


def borrar_datos(confirmacion,db_path=None):
    if confirmacion!='BORRAR':raise ValueError('Escribe BORRAR para confirmar la eliminación local.')
    preparar(db_path)
    with datos.conexion(db_path) as con:
        con.execute('BEGIN IMMEDIATE')
        for tabla in ('reportes','aceptaciones','resenas','movimientos','cotizaciones','solicitudes','favoritos','suscripciones_demo'):
            con.execute('DELETE FROM '+tabla)
