"""Cuentas locales. Contraseñas derivadas; datos de servicio separados por cuenta."""
from contextlib import closing, contextmanager
from hashlib import pbkdf2_hmac
from hmac import compare_digest
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import time
from uuid import UUID, uuid4

DB_CUENTAS = Path(os.environ.get("OFIVANTA_CUENTAS_PATH", Path(__file__).resolve().parents[2]/"data/cuentas.sqlite3"))
ITERACIONES = 600_000
AJUSTES = {"oscuro": False, "reducir_movimiento": False, "avisos": True}


@contextmanager
def conexion(ruta=None):
    destino = Path(ruta or DB_CUENTAS)
    destino.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(destino, timeout=8)) as con:
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        with con:
            yield con


def inicializar(ruta=None):
    with conexion(ruta) as con:
        con.execute('''CREATE TABLE IF NOT EXISTS cuentas (
            id TEXT PRIMARY KEY, correo TEXT UNIQUE NOT NULL, nombre TEXT NOT NULL,
            sal BLOB NOT NULL, clave BLOB NOT NULL, iteraciones INTEGER NOT NULL,
            telefono TEXT NOT NULL DEFAULT '', domicilio TEXT NOT NULL DEFAULT '',
            ajustes TEXT NOT NULL DEFAULT '{}', fallos INTEGER NOT NULL DEFAULT 0,
            bloqueada_hasta REAL NOT NULL DEFAULT 0, creada_en REAL NOT NULL)''')


def correo_valido(correo):
    correo = correo.strip().casefold() if isinstance(correo, str) else ""
    if len(correo) > 254 or any(ord(c) < 32 or ord(c) == 127 for c in correo) or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", correo):
        raise ValueError("Escribe un correo válido.")
    return correo


def texto_valido(valor, nombre, minimo, maximo):
    if not isinstance(valor, str) or not minimo <= len(valor.strip()) <= maximo or any(ord(c) < 32 for c in valor):
        raise ValueError(f"Revisa {nombre}: debe tener de {minimo} a {maximo} caracteres.")
    return valor.strip()


def validar_clave(clave):
    if not isinstance(clave, str) or not 15 <= len(clave) <= 128 or not clave.strip():
        raise ValueError("Usa una frase de contraseña de 15 a 128 caracteres.")


def _derivar(clave, sal, iteraciones=ITERACIONES):
    return pbkdf2_hmac("sha256", clave.encode("utf-8"), sal, iteraciones)


def _publica(fila):
    if not fila:
        raise ValueError("No se encontró la cuenta.")
    resultado = {k: fila[k] for k in ("id", "correo", "nombre", "telefono", "domicilio")}
    try:
        ajustes = json.loads(fila["ajustes"])
        if not isinstance(ajustes, dict):
            ajustes = {}
    except (ValueError, TypeError):
        ajustes = {}
    resultado["ajustes"] = {k: ajustes.get(k, v) if type(ajustes.get(k, v)) is bool else v for k, v in AJUSTES.items()}
    return resultado


def crear_cuenta(nombre, correo, clave, acepta=False, ruta=None):
    nombre = texto_valido(nombre, "tu nombre", 2, 70)
    correo = correo_valido(correo)
    validar_clave(clave)
    if acepta is not True:
        raise ValueError("Lee y acepta las condiciones y el aviso antes de crear la cuenta.")
    inicializar(ruta)
    identificador, sal = str(uuid4()), secrets.token_bytes(16)
    derivada = _derivar(clave, sal)
    from . import politicas
    with conexion(ruta) as con:
        try:
            con.execute("INSERT INTO cuentas (id,correo,nombre,sal,clave,iteraciones,creada_en) VALUES (?,?,?,?,?,?,?)",
                        (identificador, correo, nombre, sal, derivada, ITERACIONES, time.time()))
        except sqlite3.IntegrityError:
            raise ValueError("No se pudo crear la cuenta. Si ya tienes una, inicia sesión.") from None
        con.execute('''CREATE TABLE IF NOT EXISTS aceptaciones_cuenta (
            usuario_id TEXT PRIMARY KEY REFERENCES cuentas(id), version TEXT NOT NULL,
            huella TEXT NOT NULL, contenido TEXT NOT NULL, fecha REAL NOT NULL)''')
        contenido = "\n\n".join(t+"\n"+c for t, c in politicas.DOCUMENTOS.values())
        con.execute("INSERT INTO aceptaciones_cuenta VALUES (?,?,?,?,?)",
                    (identificador, politicas.VERSION, politicas.huella(), contenido, time.time()))
        return _publica(con.execute("SELECT * FROM cuentas WHERE id=?", (identificador,)).fetchone())


def iniciar_sesion(correo, clave, ruta=None):
    correo = correo_valido(correo)
    if not isinstance(clave, str) or len(clave) > 128:
        raise ValueError("El correo o la contraseña no coinciden.")
    inicializar(ruta)
    error = None
    with conexion(ruta) as con:
        con.execute("BEGIN IMMEDIATE")
        fila = con.execute("SELECT * FROM cuentas WHERE correo=?", (correo,)).fetchone()
        if fila and fila["bloqueada_hasta"] > time.time():
            raise ValueError("Hubo varios intentos. Espera 15 minutos antes de volver a entrar.")
        sal = fila["sal"] if fila else b"ofivanta-no-user!"
        iteraciones = fila["iteraciones"] if fila and 100_000 <= fila["iteraciones"] <= 1_200_000 else ITERACIONES
        derivada = _derivar(clave, sal, iteraciones)
        correcta = bool(fila) and compare_digest(derivada, fila["clave"])
        if not correcta:
            if fila:
                fallos = fila["fallos"]+1
                con.execute("UPDATE cuentas SET fallos=?,bloqueada_hasta=? WHERE id=?",
                            (0 if fallos >= 5 else fallos, time.time()+900 if fallos >= 5 else 0, fila["id"]))
            error = ValueError("El correo o la contraseña no coinciden.")
        else:
            con.execute("UPDATE cuentas SET fallos=0,bloqueada_hasta=0 WHERE id=?", (fila["id"],))
            usuario = _publica(fila)
    # Los intentos fallidos se confirman antes de propagar el error.
    if error:
        raise error
    return usuario


def guardar_perfil(identificador, nombre, telefono, domicilio, ruta=None):
    nombre = texto_valido(nombre, "tu nombre", 2, 70)
    telefono = texto_valido(telefono, "el teléfono", 0, 25)
    if telefono and (not re.fullmatch(r"[+\d ()-]+", telefono) or not 10 <= len(re.sub(r"\D", "", telefono)) <= 15):
        raise ValueError("Escribe un teléfono de 10 a 15 dígitos, o déjalo vacío.")
    domicilio = texto_valido(domicilio, "la dirección", 0, 300)
    inicializar(ruta)
    with conexion(ruta) as con:
        if not con.execute("UPDATE cuentas SET nombre=?,telefono=?,domicilio=? WHERE id=?", (nombre, telefono, domicilio, identificador)).rowcount:
            raise ValueError("No se encontró la cuenta.")
        return _publica(con.execute("SELECT * FROM cuentas WHERE id=?", (identificador,)).fetchone())


def guardar_ajustes(identificador, ajustes, ruta=None):
    if not isinstance(ajustes, dict) or any(k not in AJUSTES or type(v) is not bool for k, v in ajustes.items()):
        raise ValueError("Los ajustes no son válidos.")
    inicializar(ruta)
    with conexion(ruta) as con:
        fila = con.execute("SELECT * FROM cuentas WHERE id=?", (identificador,)).fetchone()
        usuario = _publica(fila)
        usuario["ajustes"].update(ajustes)
        con.execute("UPDATE cuentas SET ajustes=? WHERE id=?", (json.dumps(usuario["ajustes"]), identificador))
        return usuario


def ruta_servicios(identificador, ruta=None):
    # El nombre no usa correo ni dirección; solo identificadores UUID validados.
    identificador = str(UUID(identificador))
    return Path(ruta or DB_CUENTAS).parent / "perfiles" / identificador / "ofivanta.sqlite3"
